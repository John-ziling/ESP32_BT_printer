import os, io

base = r"C:\ESP\ESP32_BT_printer_exp"
out = []
for root, dirs, files in os.walk(base):
    if ".pio" in root or ".git" in root:
        continue
    for f in files:
        out.append(os.path.join(root, f))
io.open(r"C:\Users\31796\Desktop\blt_code\esplist.txt", "w", encoding="utf-8").write("\n".join(out))
print(len(out))
