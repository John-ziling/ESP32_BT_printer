import pymupdf, io, os

src = os.path.join(r"C:\ESP\ESP32_BT_printer_exp\文档\资料", "SCH_Schematic4_6_2025-10-17.pdf")
d = pymupdf.open(src)
t = "".join(p.get_text() for p in d)
io.open(r"C:\Users\31796\Desktop\blt_code\sch.txt", "w", encoding="utf-8").write(t)
print("chars", len(t), "pages", d.page_count)
