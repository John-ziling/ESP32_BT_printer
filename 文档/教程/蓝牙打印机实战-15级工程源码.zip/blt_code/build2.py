# -*- coding: utf-8 -*-
"""把 md/*.md 组装成排版良好的中文 DOCX。"""
import os, re, sys, glob
import io
from docx import Document
from docx.shared import Pt, Cm, RGBColor, Emu
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING, WD_BREAK
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.section import WD_SECTION
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

BASE = r"C:\Users\31796\Desktop\blt_code"
MD = os.path.join(BASE, "md")
OUT = os.path.join(BASE, "build", "蓝牙打印机实战-手把手敲代码.docx")

CJK = "宋体"
CJK_H = "黑体"
CJK_K = "楷体"
EN = "Times New Roman"
MONO = "Consolas"
ACCENT = RGBColor(0x1F, 0x4E, 0x79)
GRAY = RGBColor(0x59, 0x59, 0x59)

# ---------------------------------------------------------------- helpers
def set_run_font(run, cjk=CJK, en=EN, size=10.5, bold=None, color=None, italic=None):
    run.font.name = en
    run.font.size = Pt(size)
    rPr = run._element.get_or_add_rPr()
    rFonts = rPr.find(qn('w:rFonts'))
    if rFonts is None:
        rFonts = OxmlElement('w:rFonts'); rPr.append(rFonts)
    rFonts.set(qn('w:ascii'), en)
    rFonts.set(qn('w:hAnsi'), en)
    rFonts.set(qn('w:eastAsia'), cjk)
    if bold is not None:  run.font.bold = bold
    if italic is not None: run.font.italic = italic
    if color is not None: run.font.color.rgb = color

def shade(el, fill):
    pr = el.get_or_add_pPr() if hasattr(el, 'get_or_add_pPr') else el.get_or_add_tcPr()
    shd = OxmlElement('w:shd')
    shd.set(qn('w:val'), 'clear'); shd.set(qn('w:color'), 'auto'); shd.set(qn('w:fill'), fill)
    pr.append(shd)

def shade_cell(cell, fill):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement('w:shd')
    shd.set(qn('w:val'), 'clear'); shd.set(qn('w:color'), 'auto'); shd.set(qn('w:fill'), fill)
    tcPr.append(shd)

def para_bottom_border(p, color="1F4E79", sz="8"):
    pPr = p._p.get_or_add_pPr()
    pbdr = OxmlElement('w:pBdr')
    b = OxmlElement('w:bottom')
    b.set(qn('w:val'), 'single'); b.set(qn('w:sz'), sz)
    b.set(qn('w:space'), '3'); b.set(qn('w:color'), color)
    pbdr.append(b); pPr.append(pbdr)

def para_left_border(p, color="2E7D6B", sz="18"):
    pPr = p._p.get_or_add_pPr()
    pbdr = OxmlElement('w:pBdr')
    b = OxmlElement('w:left')
    b.set(qn('w:val'), 'single'); b.set(qn('w:sz'), sz)
    b.set(qn('w:space'), '10'); b.set(qn('w:color'), color)
    pbdr.append(b); pPr.append(pbdr)

def table_borders(tbl, color="C9D3DC", sz="4"):
    tblPr = tbl._tbl.tblPr
    borders = OxmlElement('w:tblBorders')
    for edge in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV'):
        e = OxmlElement('w:' + edge)
        e.set(qn('w:val'), 'single'); e.set(qn('w:sz'), sz)
        e.set(qn('w:space'), '0'); e.set(qn('w:color'), color)
        borders.append(e)
    tblPr.append(borders)

def cell_margins(tbl, top=60, bottom=60, left=110, right=110):
    tblPr = tbl._tbl.tblPr
    mar = OxmlElement('w:tblCellMar')
    for k, v in (('top', top), ('left', left), ('bottom', bottom), ('right', right)):
        e = OxmlElement('w:' + k)
        e.set(qn('w:w'), str(v)); e.set(qn('w:type'), 'dxa')
        mar.append(e)
    tblPr.append(mar)

def repeat_header(row):
    trPr = row._tr.get_or_add_trPr()
    h = OxmlElement('w:tblHeader'); h.set(qn('w:val'), 'true')
    trPr.append(h)

def add_field(paragraph, instr):
    r = paragraph.add_run()
    f1 = OxmlElement('w:fldChar'); f1.set(qn('w:fldCharType'), 'begin')
    it = OxmlElement('w:instrText'); it.set(qn('xml:space'), 'preserve'); it.text = instr
    f2 = OxmlElement('w:fldChar'); f2.set(qn('w:fldCharType'), 'separate')
    t = OxmlElement('w:t'); t.text = "1"
    f3 = OxmlElement('w:fldChar'); f3.set(qn('w:fldCharType'), 'end')
    r._r.append(f1); r._r.append(it); r._r.append(f2); r._r.append(t); r._r.append(f3)
    return r

TOKEN = re.compile(r'(\*\*.+?\*\*|`[^`]+`)')

def add_inline(p, text, size=10.5, cjk=CJK, color=None):
    for part in TOKEN.split(text):
        if not part:
            continue
        if part.startswith('**') and part.endswith('**') and len(part) > 4:
            r = p.add_run(part[2:-2]); set_run_font(r, cjk=cjk, size=size, bold=True, color=color)
        elif part.startswith('`') and part.endswith('`') and len(part) > 2:
            r = p.add_run(part[1:-1]); set_run_font(r, cjk="等线", en=MONO, size=size - 0.7, color=RGBColor(0xA3, 0x1D, 0x1D))
        else:
            r = p.add_run(part); set_run_font(r, cjk=cjk, size=size, color=color)

# ---------------------------------------------------------------- document setup
doc = Document()
sec = doc.sections[0]
sec.page_width, sec.page_height = Cm(21.0), Cm(29.7)
sec.top_margin, sec.bottom_margin = Cm(2.4), Cm(2.2)
sec.left_margin, sec.right_margin = Cm(2.5), Cm(2.3)
CONTENT_W = 21.0 - 2.5 - 2.3

st = doc.styles['Normal']
st.font.name = EN
st.font.size = Pt(10.5)
st.element.rPr.rFonts.set(qn('w:eastAsia'), CJK)
st.paragraph_format.line_spacing = 1.5
st.paragraph_format.space_after = Pt(3)

for name, size, color, before, after in (
    ('Heading 1', 20, ACCENT, 0, 14),
    ('Heading 2', 14.5, ACCENT, 16, 6),
    ('Heading 3', 12, RGBColor(0x2E, 0x5C, 0x8A), 11, 4),
):
    h = doc.styles[name]
    h.font.name = EN
    h.font.size = Pt(size)
    h.font.bold = True
    h.font.color.rgb = color
    rPr = h.element.get_or_add_rPr()
    rFonts = rPr.find(qn('w:rFonts'))
    if rFonts is None:
        rFonts = OxmlElement('w:rFonts'); rPr.append(rFonts)
    rFonts.set(qn('w:eastAsia'), CJK_H)
    h.paragraph_format.space_before = Pt(before)
    h.paragraph_format.space_after = Pt(after)
    h.paragraph_format.keep_with_next = True
    h.paragraph_format.line_spacing = 1.25

doc.core_properties.title = "蓝牙打印机实战：手把手敲代码"
doc.core_properties.subject = "ESP32 热敏打印机 15 级台阶实战教程"
doc.core_properties.author = "技术文档"
doc.core_properties.keywords = "ESP32, 热敏打印机, 蓝牙, SPP, 步进电机, PlatformIO, STM32 对比"

# ---------------------------------------------------------------- cover
def cover():
    for _ in range(3):
        doc.add_paragraph()
    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run("蓝 牙 打 印 机 实 战"); set_run_font(r, cjk=CJK_H, size=34, bold=True, color=ACCENT)
    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run("手 把 手 敲 代 码"); set_run_font(r, cjk=CJK_H, size=34, bold=True, color=ACCENT)

    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(10)
    r = p.add_run("—— 会 STM32 的人，15 级台阶写出 ESP32 打印机 ——")
    set_run_font(r, cjk=CJK_K, size=13, color=GRAY)

    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(24)
    para_bottom_border(p, "1F4E79", "12")

    for _ in range(2):
        doc.add_paragraph()

    info = [
        ("适用硬件", "ESP32-WROOM-32E + JX-2R-01/JX-700-48 兼容打印头"),
        ("软件框架", "Arduino-ESP32 3.3.12（PlatformIO espressif32@8.0.0）"),
        ("通信方式", "经典蓝牙 SPP，兼容喵喵机公版 App"),
        ("文档版本", "v2.0"),
        ("编写日期", "2026-11"),
    ]
    for k, v in info:
        p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.space_after = Pt(2)
        r = p.add_run(k + "："); set_run_font(r, cjk=CJK_H, size=10.5, color=GRAY)
        r = p.add_run(v); set_run_font(r, cjk=CJK, size=10.5)

    for _ in range(3):
        doc.add_paragraph()
    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run("15 个分级工程均在本机实测编译通过，\n书中的 RAM / Flash 占用与耗时都是真实构建结果，可直接对照。")
    set_run_font(r, cjk=CJK_K, size=9.5, color=GRAY)

# ---------------------------------------------------------------- TOC
def toc_page():
    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(16)
    r = p.add_run("目　　录"); set_run_font(r, cjk=CJK_H, size=20, bold=True, color=ACCENT)
    para_bottom_border(p, "C9D3DC", "6")

    p = doc.add_paragraph()
    r = p.add_run()
    f1 = OxmlElement('w:fldChar'); f1.set(qn('w:fldCharType'), 'begin')
    it = OxmlElement('w:instrText'); it.set(qn('xml:space'), 'preserve')
    it.text = r'TOC \o "1-2" \h \z \u'
    f2 = OxmlElement('w:fldChar'); f2.set(qn('w:fldCharType'), 'separate')
    t = OxmlElement('w:t'); t.text = "（目录将在打开文档时自动更新）"
    f3 = OxmlElement('w:fldChar'); f3.set(qn('w:fldCharType'), 'end')
    r._r.append(f1); r._r.append(it); r._r.append(f2); r._r.append(t); r._r.append(f3)

# ---------------------------------------------------------------- body renderer
def add_code(lines):
    if not lines:
        return
    tbl = doc.add_table(rows=1, cols=1)
    tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
    table_borders(tbl, "DDE3E8", "4")
    cell_margins(tbl, 80, 80, 140, 140)
    cell = tbl.cell(0, 0)
    shade_cell(cell, "F7F8FA")
    first = True
    for line in lines:
        p = cell.paragraphs[0] if first else cell.add_paragraph()
        first = False
        pf = p.paragraph_format
        pf.space_before = Pt(0); pf.space_after = Pt(0); pf.line_spacing = 1.05
        r = p.add_run(line if line.strip() else " ")
        set_run_font(r, cjk="等线", en=MONO, size=8.8, color=RGBColor(0x1A, 0x1A, 0x1A))
    # spacing after table
    sp = doc.add_paragraph(); sp.paragraph_format.space_after = Pt(4)
    sp.paragraph_format.line_spacing = 1.0
    for r in sp.runs: pass

def add_table(rows):
    if not rows:
        return
    header = rows[0]
    body = rows[1:]
    n = len(header)
    tbl = doc.add_table(rows=1, cols=n)
    tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
    tbl.autofit = True
    table_borders(tbl)
    cell_margins(tbl)
    hdr = tbl.rows[0]
    repeat_header(hdr)
    for i, txt in enumerate(header):
        c = hdr.cells[i]
        c.text = ""
        p = c.paragraphs[0]
        p.paragraph_format.space_before = Pt(0); p.paragraph_format.space_after = Pt(0)
        p.paragraph_format.line_spacing = 1.15
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        add_inline(p, txt, size=9, cjk=CJK_H)
        for r in p.runs: r.font.bold = True
        shade_cell(c, "E8EEF5")
    for ridx, row in enumerate(body):
        cells = tbl.add_row().cells
        for i in range(n):
            txt = row[i] if i < len(row) else ""
            c = cells[i]
            c.text = ""
            p = c.paragraphs[0]
            p.paragraph_format.space_before = Pt(0); p.paragraph_format.space_after = Pt(0)
            p.paragraph_format.line_spacing = 1.15
            add_inline(p, txt, size=9)
            if ridx % 2 == 1:
                shade_cell(c, "FAFBFC")
    sp = doc.add_paragraph(); sp.paragraph_format.space_after = Pt(4)
    sp.paragraph_format.line_spacing = 1.0

def add_figure(path, caption, width_cm):
    full = os.path.join(BASE, path.replace('/', os.sep))
    if not os.path.exists(full):
        p = doc.add_paragraph()
        r = p.add_run(f"[缺图：{path}]"); set_run_font(r, size=9, color=RGBColor(0xCC, 0x00, 0x00))
        return
    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(6); p.paragraph_format.space_after = Pt(2)
    p.paragraph_format.keep_with_next = True
    p.add_run().add_picture(full, width=Cm(width_cm))
    cp = doc.add_paragraph(); cp.alignment = WD_ALIGN_PARAGRAPH.CENTER
    cp.paragraph_format.space_after = Pt(8)
    r = cp.add_run(caption); set_run_font(r, cjk=CJK, size=9, color=GRAY)

def add_quote(lines):
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.left_indent = Cm(0.35); pf.right_indent = Cm(0.2)
    pf.space_before = Pt(6); pf.space_after = Pt(6)
    pf.line_spacing = 1.35
    para_left_border(p)
    shade(p._p, "F2F7F5")
    for i, line in enumerate(lines):
        if i:
            p.add_run().add_break()
        add_inline(p, line, size=9.5, cjk=CJK_K)

def add_list_item(text, level, bullet_char="•"):
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.left_indent = Cm(0.6 + 0.7 * level)
    pf.first_line_indent = Cm(-0.55)
    pf.space_before = Pt(1); pf.space_after = Pt(1)
    pf.line_spacing = 1.4
    marker = bullet_char if not re.match(r'^\d+\.', text) else ""
    if marker:
        r = p.add_run(marker + " "); set_run_font(r, size=10, color=ACCENT)
        add_inline(p, text, size=10.5)
    else:
        add_inline(p, text, size=10.5)

def render_md(path):
    with open(path, encoding='utf-8') as f:
        lines = f.read().split('\n')
    i = 0
    n = len(lines)
    while i < n:
        line = lines[i]
        s = line.strip()

        if s == '[[PB]]':
            doc.add_page_break(); i += 1; continue

        # 水平分隔线：markdown 的 --- / *** / ___ 只是章节分隔，DOCX 里不排版
        if s in ('---', '***', '___'):
            i += 1; continue

        if not s:
            i += 1; continue

        # code fence
        if s.startswith('```'):
            i += 1
            buf = []
            while i < n and not lines[i].strip().startswith('```'):
                buf.append(lines[i].rstrip())
                i += 1
            i += 1
            add_code(buf)
            continue

        # source include:  <<<stages/s10/src/frame.cpp>>>
        m = re.match(r'^<<<(.+?)>>>$', s)
        if m:
            inc = os.path.join(BASE, m.group(1).replace('/', os.sep))
            if os.path.exists(inc):
                with io.open(inc, encoding='utf-8', errors='replace') as g:
                    add_code([l.rstrip('\n') for l in g.readlines()])
            else:
                pr = doc.add_paragraph()
                rr = pr.add_run('[缺文件: ' + m.group(1) + ']')
                set_run_font(rr, size=9, color=RGBColor(0xCC, 0, 0))
            i += 1; continue

        # image
        m = re.match(r'^!\[\[(.+?)\]\]$', s)
        if m:
            parts = [x.strip() for x in m.group(1).split('|')]
            path = parts[0]
            cap = parts[1] if len(parts) > 1 else ""
            w = float(parts[2]) if len(parts) > 2 else 13.0
            add_figure(path, cap, w)
            i += 1; continue

        # heading
        m = re.match(r'^(#{1,4})\s+(.*)$', s)
        if m:
            level = len(m.group(1))
            text = m.group(2).strip()
            if level == 1:
                p = doc.add_paragraph(style='Heading 1')
                p.paragraph_format.page_break_before = True
                r = p.add_run(text); set_run_font(r, cjk=CJK_H, en=EN, size=20, bold=True, color=ACCENT)
                para_bottom_border(p, "1F4E79", "8")
            elif level == 2:
                p = doc.add_paragraph(style='Heading 2')
                r = p.add_run(text); set_run_font(r, cjk=CJK_H, en=EN, size=14.5, bold=True, color=ACCENT)
            else:
                p = doc.add_paragraph(style='Heading 3')
                r = p.add_run(text); set_run_font(r, cjk=CJK_H, en=EN, size=12, bold=True,
                                                  color=RGBColor(0x2E, 0x5C, 0x8A))
            i += 1; continue

        # table
        if s.startswith('|'):
            rows = []
            while i < n and lines[i].strip().startswith('|'):
                raw = lines[i].strip()
                if re.match(r'^\|[\s:\-\|]+\|$', raw):
                    i += 1; continue
                cells = [c.strip() for c in raw.strip('|').split('|')]
                rows.append(cells)
                i += 1
            add_table(rows)
            continue

        # blockquote
        if s.startswith('>'):
            buf = []
            while i < n and lines[i].strip().startswith('>'):
                buf.append(lines[i].strip()[1:].strip())
                i += 1
            add_quote(buf)
            continue

        # list
        m = re.match(r'^(\s*)-\s+(.*)$', line)
        if m:
            level = len(m.group(1)) // 2
            add_list_item(m.group(2).strip(), level)
            i += 1; continue

        m = re.match(r'^(\s*)(\d+)\.\s+(.*)$', line)
        if m:
            add_list_item(f"{m.group(2)}. {m.group(3).strip()}", 0)
            i += 1; continue

        # paragraph (join consecutive non-empty lines)
        buf = [s]
        i += 1
        while i < n:
            nxt = lines[i].strip()
            if (not nxt or nxt.startswith('#') or nxt.startswith('|') or nxt.startswith('>')
                    or nxt.startswith('```') or nxt.startswith('![[') or nxt == '[[PB]]'
                    or re.match(r'^\s*-\s+', lines[i]) or re.match(r'^\s*\d+\.\s+', lines[i])):
                break
            buf.append(nxt)
            i += 1
        p = doc.add_paragraph()
        p.paragraph_format.first_line_indent = Cm(0.74)
        p.paragraph_format.space_after = Pt(4)
        add_inline(p, ''.join(buf) if len(buf) > 1 and not buf[0].endswith(('：', '。')) else ' '.join(buf))

# ---------------------------------------------------------------- assemble
cover()

# section 2: TOC + body, own footer starting at 1
sec2 = doc.add_section(WD_SECTION.NEW_PAGE)
sec2.page_width, sec2.page_height = Cm(21.0), Cm(29.7)
sec2.top_margin, sec2.bottom_margin = Cm(2.4), Cm(2.2)
sec2.left_margin, sec2.right_margin = Cm(2.5), Cm(2.3)
sec2.footer.is_linked_to_previous = False
sec2.header.is_linked_to_previous = False

# page numbering restart
pgNum = OxmlElement('w:pgNumType'); pgNum.set(qn('w:start'), '1')
sec2._sectPr.append(pgNum)

# footer: centered page number
fp = sec2.footer.paragraphs[0]
fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = fp.add_run("— "); set_run_font(r, size=9, color=GRAY)
fr = add_field(fp, " PAGE ")
set_run_font(fr, size=9, color=GRAY)
r = fp.add_run(" —"); set_run_font(r, size=9, color=GRAY)

# header
hp = sec2.header.paragraphs[0]
hp.alignment = WD_ALIGN_PARAGRAPH.RIGHT
r = hp.add_run("蓝牙打印机实战：手把手敲代码"); set_run_font(r, cjk=CJK, size=8.5, color=GRAY)
para_bottom_border(hp, "C9D3DC", "4")

toc_page()

for f in sorted(glob.glob(os.path.join(MD, 'p*.md')), key=lambda x: int(re.search(r'p(\d+)\.md$', x).group(1))):
    print("render", f)
    render_md(f)


def drop_spacers_before_headings():
    """删除紧邻标题之前的空段落，避免标题的前置分页把它顶成一张空白页。"""
    body = doc.element.body
    removed = 0
    for child in list(body):
        if child.tag != qn('w:p'):
            continue
        nxt = child.getnext()
        if nxt is None or nxt.tag != qn('w:p'):
            continue
        style = nxt.find(qn('w:pPr'))
        sty = None
        if style is not None:
            el = style.find(qn('w:pStyle'))
            if el is not None:
                sty = el.get(qn('w:val'))
        if not sty or not sty.lower().startswith('heading'):
            continue
        has_run = child.find(qn('w:r')) is not None
        has_text = ''.join(t.text or '' for t in child.iter(qn('w:t'))).strip()
        if has_run and not has_text:
            body.remove(child)
            removed += 1
    print("dropped spacers:", removed)

drop_spacers_before_headings()
doc.save(OUT)
print("saved", OUT, os.path.getsize(OUT))
