# -*- coding: utf-8 -*-
import glob
import re
import pymupdf

pdf = glob.glob(r"C:\Users\31796\Desktop\blt_code\build\*.pdf")[0]
doc = pymupdf.open(pdf)

toc_txt = "".join(doc[i].get_text() for i in range(2, 5))
entries = []
for line in toc_txt.split("\n"):
    m = re.match(r"^(第 \d+ 章[^.]*)\.{3,}\s*(\d+)\s*$", line.strip())
    if m:
        entries.append((m.group(1).strip(), int(m.group(2))))
print("entries:", len(entries))
for name, pg in entries[:6]:
    print("  ", name, pg)

# 正文里每章标题所在页
found = {}
for i, p in enumerate(doc):
    t = p.get_text()
    for name, _ in entries:
        num = re.match(r"第 (\d+) 章", name).group(1)
        if name[:12] in t and num not in found:
            found[num] = i + 1
bad = 0
for name, pg in entries:
    num = re.match(r"第 (\d+) 章", name).group(1)
    body = found.get(num)
    # TOC 页码是页脚编号，正文页 = 页脚 + 1（封面无页码）
    if body is not None and body - 1 != pg:
        print("MISMATCH", name, "toc", pg, "body", body)
        bad += 1
print("mismatch:", bad)
