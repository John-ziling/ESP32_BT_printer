# -*- coding: utf-8 -*-
"""用 ch11_new.md 替换 book_v2.md 的第 11 章。"""
import io
import re

BASE = r"C:\Users\31796\Desktop\blt_code\md"
book = io.open(BASE + r"\book_v2.md", encoding="utf-8").read().split("\n")
new = io.open(BASE + r"\ch11_new.md", encoding="utf-8").read()

i0 = next(i for i, l in enumerate(book) if l.startswith("# 第 11 章"))
i1 = next(i for i, l in enumerate(book) if l.startswith("# 第 12 章"))
print("replace lines", i0 + 1, "..", i1, "->", len(new.split("\n")), "new lines")

out = book[:i0] + new.split("\n") + book[i1:]
io.open(BASE + r"\book_v3.md", "w", encoding="utf-8", newline="\n").write("\n".join(out))
print("wrote book_v3.md lines", len(out))
