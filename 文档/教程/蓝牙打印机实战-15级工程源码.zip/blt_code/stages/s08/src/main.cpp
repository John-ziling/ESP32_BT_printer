// =====================================================
//  S08 · 三个传感器：缺纸、电池、打印头温度
//  目标：让机器知道"有没有纸、还有多少电、头烫不烫"
//  验证：抽纸时串口 2 秒内报 paper removed；电压与万用表差 <0.1V
// =====================================================
#include <Arduino.h>
#include "config.h"
#include "sensors.h"
#include "printer.h"
#include "printhead.h"
#include "motor.h"
#include "canvas.h"
#include "shell.h"

static PrintCfg s_cfg = {800, 500, 4};
static uint32_t s_last_poll = 0;
static bool     s_last_paper = true;

static void print_all() {
  bool     paper = paper_present();
  uint16_t mv = batt_mv();
  float    c = head_celsius();
  Serial.printf("paper=%s  batt=%umV (%u%%)  head=%.1fC (raw %d)\n",
                paper ? "OK" : "OUT", mv, batt_percent(mv), c, temp_raw());
}

static void cmd_sens(int, char **) { print_all(); }

static void cmd_paper(int, char **) {
  Serial.printf("PHINT=%d  paper=%s\n", digitalRead(PIN_PHINT),
                paper_present() ? "OK" : "OUT");
}

static void cmd_batt(int, char **) {
  uint16_t mv = batt_mv();
  Serial.printf("batt %umV  %u%%  (raw %u)\n", mv, batt_percent(mv), batt_raw());
}

static void cmd_ntc(int argc, char **argv) {
  // 不带参数：只打印反推阻值（标定 R25 用）
  if (argc < 2) {
    Serial.printf("R=%.0f ohm   raw=%d   T=%.1fC\n", head_ohm(), temp_raw(), head_celsius());
    return;
  }
  // 带参数：把当前读数当作真实温度，做单点偏移校准
  sensors_cal_ntc(atof(argv[1]));
}

static void cmd_calbatt(int argc, char **argv) {
  if (argc < 2) { Serial.println("usage: calbatt <real_mV>  例：calbatt 3980"); return; }
  sensors_cal_batt((uint16_t)atoi(argv[1]));
}

static void cmd_calntc(int argc, char **argv) {
  if (argc < 2) { Serial.println("usage: calntc <real_C>  例：calntc 25.5"); return; }
  sensors_cal_ntc(atof(argv[1]));
}

// 打印一页传感器读数，顺便验证"边读边打"会不会互相干扰
static void cmd_page(int, char **) {
  Canvas cv;
  if (!canvas_alloc(cv, 160)) return;
  canvas_text(cv, 0, 4,  "SENSOR REPORT");
  canvas_hline(cv, 0, 24, ROW_DOTS);
  char buf[64];
  uint16_t mv = batt_mv();
  snprintf(buf, sizeof(buf), "BATT %umV  %u%%", mv, batt_percent(mv));
  canvas_text(cv, 0, 32, buf);
  snprintf(buf, sizeof(buf), "HEAD %.1fC", head_celsius());
  canvas_text(cv, 0, 56, buf);
  canvas_text(cv, 0, 80, paper_present() ? "PAPER OK" : "PAPER OUT");
  canvas_print(cv, 0, 160, s_cfg);
  canvas_free(cv);
}

void setup() {
  Serial.begin(115200);
  delay(200);
  Serial.println();
  Serial.println("=== STAGE 08 · sensors ===");
  Serial.println("抽纸/塞纸看串口；电压用万用表对比后 calbatt 校准");

  sensors_init();
  printer_init();

  shell_init(Serial);
  shell_add("sens",    cmd_sens,    "print all sensor values");
  shell_add("paper",   cmd_paper,   "paper pin state");
  shell_add("batt",    cmd_batt,    "battery mV + percent");
  shell_add("calbatt", cmd_calbatt, "calbatt <real_mV>");
  shell_add("ntc",     cmd_ntc,     "ntc [real_C]  R 值标定/温度校准");
  shell_add("calntc",  cmd_calntc,  "calntc <real_C>");
  shell_add("page",    cmd_page,    "print a sensor report page");
  Serial.print("> ");
}

void loop() {
  shell_poll();

  // 每 500ms 巡检一次；状态变化才打印，避免刷屏
  if (millis() - s_last_poll >= 500) {
    s_last_poll = millis();
    bool paper = paper_present();
    if (paper != s_last_paper) {
      s_last_paper = paper;
      Serial.printf("\n[EVENT] paper %s\n", paper ? "inserted" : "removed");
      Serial.print("> ");
    }
  }
}
