# -*- coding: utf-8 -*-
import glob
import pymupdf

pdf = glob.glob(r"C:\Users\31796\Desktop\blt_code\build\*.pdf")[0]
doc = pymupdf.open(pdf)
print("pages:", doc.page_count)

imgs = 0
pages_with_img = []
empty = []
for i, p in enumerate(doc):
    il = p.get_images(full=True)
    if il:
        imgs += len(il)
        pages_with_img.append(i + 1)
    txt = p.get_text().strip()
    if len(txt) < 40:
        empty.append((i + 1, len(txt)))

print("images:", imgs, "on", len(pages_with_img), "pages")
print("near-empty:", empty)
print("img pages:", pages_with_img)

full = "".join(p.get_text() for p in doc)
for k in ["30142", "R25", "B 值", "镜像", "0.806", "23000", "图 6-2", "图 11"]:
    print(k, "->", full.count(k))

# 目录页码检查
for i in range(1, 4):
    t = doc[i].get_text()
    if "第 11 章" in t:
        print("TOC page", i + 1)
        for line in t.splitlines():
            if "第 1" in line or "第 6" in line or "附录" in line:
                print("   ", line.strip())
