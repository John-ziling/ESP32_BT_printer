# -*- coding: utf-8 -*-
"""重画第二本教程的全部示意图（PIL，2x 超采样）。"""
import os
from PIL import Image, ImageDraw, ImageFont

OUT = r"C:\Users\31796\Desktop\blt_code\figs"
os.makedirs(OUT, exist_ok=True)
S = 2

MSYH = r"C:\Windows\Fonts\msyh.ttc"
MSYHB = r"C:\Windows\Fonts\msyhbd.ttc"
MONO = r"C:\Windows\Fonts\consola.ttf"

INK = (34, 40, 49)
GRAY = (110, 118, 128)
LGRAY = (170, 178, 188)
LINE = (70, 80, 92)
BLUE = (31, 78, 121)
LBLUE = (226, 236, 246)
GREEN = (28, 110, 90)
LGREEN = (226, 242, 236)
ORANGE = (176, 96, 24)
LORANGE = (252, 238, 222)
RED = (168, 40, 40)
LRED = (250, 230, 228)
WHITE = (255, 255, 255)
BG = (255, 255, 255)


def F(sz, bold=False, mono=False):
    if mono:
        return ImageFont.truetype(MONO, int(sz * S))
    return ImageFont.truetype(MSYHB if bold else MSYH, int(sz * S))


def T(d, x, y, s, sz=18, color=INK, anchor="la", bold=False, mono=False):
    d.text((x * S, y * S), s, font=F(sz, bold, mono), fill=color, anchor=anchor)


def RBOX(d, x, y, w, h, fill=WHITE, edge=LINE, r=10, width=2, dash=False):
    if dash:
        # 手绘虚线圆角：用直线段拼
        step = 9
        pts = [(x, y), (x + w, y), (x + w, y + h), (x, y + h), (x, y)]
        for i in range(len(pts) - 1):
            (x1, y1), (x2, y2) = pts[i], pts[i + 1]
            ln = ((x2 - x1) ** 2 + (y2 - y1) ** 2) ** 0.5
            n = max(1, int(ln // step))
            for k in range(n):
                a = k / n
                b = (k + 0.5) / n
                d.line([((x1 + (x2 - x1) * a) * S, (y1 + (y2 - y1) * a) * S),
                        ((x1 + (x2 - x1) * b) * S, (y1 + (y2 - y1) * b) * S)],
                       fill=edge, width=int(width * S))
        return
    d.rounded_rectangle([x * S, y * S, (x + w) * S, (y + h) * S],
                        radius=r * S, fill=fill, outline=edge, width=int(width * S))


def BOX(d, x, y, w, h, title, sub=None, fill=LBLUE, edge=BLUE, sz=20, subsz=15, bold=True):
    RBOX(d, x, y, w, h, fill=fill, edge=edge)
    if sub:
        T(d, x + w / 2, y + h / 2 - 12, title, sz, INK, "mm", bold)
        T(d, x + w / 2, y + h / 2 + 12, sub, subsz, GRAY, "mm")
    else:
        T(d, x + w / 2, y + h / 2, title, sz, INK, "mm", bold)


def LIN(d, x1, y1, x2, y2, color=LINE, w=2, dash=False, step=10):
    if not dash:
        d.line([(x1 * S, y1 * S), (x2 * S, y2 * S)], fill=color, width=int(w * S))
        return
    ln = ((x2 - x1) ** 2 + (y2 - y1) ** 2) ** 0.5
    n = max(1, int(ln // step))
    for k in range(n):
        a, b = k / n, (k + 0.6) / n
        d.line([((x1 + (x2 - x1) * a) * S, (y1 + (y2 - y1) * a) * S),
                ((x1 + (x2 - x1) * b) * S, (y1 + (y2 - y1) * b) * S)],
               fill=color, width=int(w * S))


def HEAD(d, x, y, ang, color=LINE, size=11):
    import math
    a = math.radians(ang)
    p1 = (x * S, y * S)
    p2 = ((x - size * math.cos(a - 0.4)) * S, (y - size * math.sin(a - 0.4)) * S)
    p3 = ((x - size * math.cos(a + 0.4)) * S, (y - size * math.sin(a + 0.4)) * S)
    d.polygon([p1, p2, p3], fill=color)


def ARR(d, x1, y1, x2, y2, color=LINE, w=2, dash=False, both=False, size=11):
    import math
    LIN(d, x1, y1, x2, y2, color, w, dash)
    ang = math.degrees(math.atan2(y2 - y1, x2 - x1))
    HEAD(d, x2, y2, ang, color, size)
    if both:
        HEAD(d, x1, y1, ang + 180, color, size)


def NEW(w, h):
    im = Image.new("RGB", (w * S, h * S), BG)
    return im, ImageDraw.Draw(im)


def SAVE(im, name, w, h):
    im = im.resize((w, h), Image.LANCZOS)
    p = os.path.join(OUT, name)
    im.save(p)
    print("saved", p, im.size)


# ---------------------------------------------------------------- 图 0-1 系统框图
def fig_system():
    W, H = 1440, 900
    im, d = NEW(W, H)
    T(d, 40, 26, "整机系统框图", 30, INK, "la", True)
    T(d, 40, 68, "信号只走五条通道：蓝牙进数据、SPI 出点阵、四路 IO 驱动电机、两根线读传感器、一条电源链供电。", 16, GRAY)

    # 手机
    BOX(d, 1080, 150, 300, 120, "手机 / 喵喵机 App", "把图片转成点阵再分包发送", LBLUE, BLUE, 22, 15)
    # ESP32
    BOX(d, 590, 300, 330, 180, "ESP32-WROOM-32E", "240MHz 双核 · 4MB Flash · 520KB RAM", LBLUE, BLUE, 22, 15)
    # 打印头
    BOX(d, 70, 140, 400, 170, "热敏打印头 JX-2R-01", "384 点/行 · 48 字节/行 · 6 段 STB", LGREEN, GREEN, 22, 15)
    # 电机
    BOX(d, 70, 430, 400, 110, "两相四线步进电机", "9°/整步 · 减速后 0.0625mm/步", LGREEN, GREEN, 22, 15)
    # 驱动
    BOX(d, 150, 620, 320, 100, "TC1508S 双 H 桥", "IN1~IN4 → M_A± / M_B±", LGREEN, GREEN, 22, 15)
    # USB
    BOX(d, 1080, 470, 300, 120, "USB 串口（CH340C）", "115200 日志 + 命令行 shell", LORANGE, ORANGE, 22, 15)
    # 电源
    BOX(d, 590, 640, 330, 120, "电源链（见图 0-2）", "18650 → 升压 8.4V / LDO 3.3V", LORANGE, ORANGE, 22, 15)
    # 传感器
    BOX(d, 1080, 690, 300, 120, "传感器", "缺纸 PHINT · 电池 ADC · 头温 NTC", LORANGE, ORANGE, 22, 15)

    # 蓝牙
    ARR(d, 1080, 210, 925, 330, BLUE, 2, both=True)
    T(d, 1000, 232, "经典蓝牙 SPP", 16, BLUE, "mm", True)
    T(d, 1000, 254, "MaoPaperang", 14, BLUE, "mm")
    # SPI
    ARR(d, 590, 360, 472, 245, GREEN, 2, both=True)
    T(d, 520, 268, "SPI + 6×STB", 16, GREEN, "mm", True)
    T(d, 520, 290, "CLK/DI/LAT", 14, GREEN, "mm")
    # 电机
    ARR(d, 590, 440, 472, 470, GREEN, 2)
    T(d, 528, 442, "IN1~IN4", 15, GREEN, "mm", True)
    ARR(d, 310, 620, 310, 545, GREEN, 2)
    T(d, 320, 582, "M_A± / M_B±", 15, GREEN, "rm")
    # USB
    ARR(d, 1080, 530, 925, 450, ORANGE, 2, both=True)
    T(d, 1000, 500, "UART0", 15, ORANGE, "mm", True)
    # 电源到各块
    LIN(d, 640, 640, 640, 490, ORANGE, 2, dash=True)
    HEAD(d, 640, 486, -90, ORANGE, 10)
    T(d, 648, 560, "3.3V", 14, ORANGE, "la", True)
    LIN(d, 755, 640, 300, 320, ORANGE, 2, dash=True)
    HEAD(d, 296, 316, 200, ORANGE, 10)
    T(d, 620, 610, "VH 8.4V", 14, ORANGE, "mm", True)
    # 传感器
    ARR(d, 1080, 750, 925, 700, ORANGE, 2)
    T(d, 1000, 712, "IO35/34/36", 15, ORANGE, "mm", True)
    SAVE(im, "fig_system.png", W, H)


# ---------------------------------------------------------------- 图 0-2 电源树
def fig_power():
    W, H = 1300, 760
    im, d = NEW(W, H)
    T(d, 40, 26, "电源树：一颗电池，三条轨", 30, INK, "la", True)
    T(d, 40, 68, "打印头要 8.4V 大电流，逻辑要干净 3.3V，电机直接吃电池——三条轨各管一摊。", 16, GRAY)

    BOX(d, 60, 300, 190, 130, "USB 5V", "Type-C 供电/充电", LORANGE, ORANGE, 20, 14)
    BOX(d, 300, 300, 190, 130, "ME4054", "线性充电 1A", LORANGE, ORANGE, 20, 14)
    BOX(d, 540, 300, 220, 130, "18650 锂电池", "3.0~4.2V (VBAT)", LORANGE, ORANGE, 20, 14)
    ARR(d, 250, 365, 300, 365, ORANGE)
    ARR(d, 490, 365, 540, 365, ORANGE)
    T(d, 515, 340, "4.2V", 13, ORANGE, "mm", True)

    # 三条支路
    BOX(d, 900, 110, 300, 110, "升压 AP2005 → VH", "8.4V · 峰值 3A · 打印头加热", LGREEN, GREEN, 19, 14)
    BOX(d, 900, 300, 300, 110, "直连 VBAT", "3.0~4.2V · 电机 TC1508S", LGREEN, GREEN, 19, 14)
    BOX(d, 900, 490, 300, 110, "LDO XC6210 → 3V3", "3.3V · 300mA · ESP32 + 打印头逻辑", LGREEN, GREEN, 19, 14)

    ARR(d, 760, 340, 860, 165, GREEN)
    ARR(d, 760, 365, 860, 355, GREEN, both=False)
    ARR(d, 760, 395, 860, 545, GREEN)
    T(d, 800, 220, "升压比\n1:2", 13, GRAY, "mm")
    T(d, 800, 430, "H 桥\n直驱", 13, GRAY, "mm")

    # 说明
    T(d, 60, 560, "电流预算（实测口径）", 20, INK, "la", True)
    rows = [
        ("打印头加热（6 段全开，占空比 ~50%）", "1.5 ~ 3.2 A"),
        ("步进电机（两相同时通电）", "0.4 ~ 0.8 A"),
        ("ESP32 + 蓝牙发射峰值", "120 ~ 250 mA"),
        ("待机（深睡 + 蓝牙断开）", "~45 mA"),
    ]
    y = 600
    for a, b in rows:
        T(d, 60, y, "· " + a, 15, INK)
        T(d, 700, y, b, 15, GRAY, "ra", True)
        y += 30
    T(d, 60, 726, "结论：电池端峰值 ~3A，18650 必须选 10A 以上放电倍率的电芯，且走线要粗。", 15, RED, "la", True)
    SAVE(im, "fig_power.png", W, H)


# ---------------------------------------------------------------- 图 6-2 384 点打包
def fig_bitmap():
    W, H = 1600, 980
    im, d = NEW(W, H)
    T(d, 40, 24, "384 个点怎么变成 48 个字节", 30, INK, "la", True)
    T(d, 40, 66, "一行 384 个加热点 → 每 8 个点打包成 1 字节 → 48 字节，按 MSB 优先串行送出。", 16, GRAY)

    # 一行 48 个字节格
    bx, by, bw, bh = 60, 140, 30, 64
    for i in range(48):
        x = bx + i * bw
        fill = LBLUE if i % 2 == 0 else WHITE
        d.rectangle([x * S, by * S, (x + bw) * S, (by + bh) * S], fill=fill, outline=LGRAY, width=int(1 * S))
        if i in (0, 1, 23, 46, 47):
            T(d, x + bw / 2, by + bh / 2, str(i), 13, INK, "mm", True)
    T(d, bx, by - 26, "字节 0", 14, BLUE, "la", True)
    T(d, bx + 46 * bw, by - 26, "字节 47", 14, BLUE, "ra", True)
    T(d, bx + 24 * bw, by - 26, "…… 共 48 字节 = 384 点 ……", 14, GRAY, "ma")
    T(d, bx, by + bh + 10, "← 第 0 点（最左）", 13, GRAY)
    T(d, bx + 48 * bw, by + bh + 10, "第 383 点（最右）→", 13, GRAY, "ra")

    # 放大一个字节
    zx, zy, cell = 60, 300, 78
    T(d, zx, zy - 34, "放大「字节 0」：8 个点 = 8 个 bit", 19, INK, "la", True)
    for k in range(8):
        x = zx + k * cell
        d.rectangle([x * S, zy * S, (x + cell - 4) * S, (zy + cell - 4) * S], fill=WHITE, outline=LINE, width=int(2 * S))
        T(d, x + (cell - 4) / 2, zy + (cell - 4) / 2, str(7 - k), 26, BLUE, "mm", True)
        T(d, x + (cell - 4) / 2, zy + cell + 4, "第%d点" % k, 13, GRAY, "ma")
    T(d, zx + 8 * cell + 12, zy + 18, "bit 号 = 7 - (点号 % 8)", 15, GRAY)
    T(d, zx + 8 * cell + 12, zy + 44, "bit=1 → 该点加热变黑", 15, RED, "la", True)

    # 数值示例
    ex_y = 470
    T(d, zx, ex_y, "例：只打印最左边一个点 → 字节 0 = 0b1000_0000 = 0x80，其余 47 字节全 0", 17, INK, "la", True)
    T(d, zx, ex_y + 34, "{ 0x80, 0x00, 0x00, ... , 0x00 }", 18, GREEN, "la", False, mono=True)
    T(d, zx, ex_y + 70, "例：打印最右一个点 → 0b0000_0001 = 0x01，其余 47 字节全 0", 17, INK, "la", True)
    T(d, zx, ex_y + 104, "{ 0x00, 0x00, ... , 0x00, 0x01 }", 18, GREEN, "la", False, mono=True)

    # 移位方向
    sy = 640
    RBOX(d, zx, sy, 1480, 120, LORANGE, ORANGE, 12, 2)
    T(d, zx + 20, sy + 14, "串行移位方向（务必记住这一条）", 18, ORANGE, "la", True)
    T(d, zx + 20, sy + 46, "第一个 bit 先送 → 走完全部 384 个时钟后停在移位链的最末端 → 也就是最右边；", 15, INK)
    T(d, zx + 20, sy + 74, "最后一个 bit 后送 → 停在最左边。所以「先发的字节 = 最左边的 8 个点」只是参数约定，", 15, INK)
    T(d, zx + 20, sy + 100, "真实方向取决于打印头内部移位链与加热点的相对连接顺序。", 15, INK)

    # 镜像排查
    my = 790
    RBOX(d, zx, my, 1480, 160, LRED, RED, 12, 2)
    T(d, zx + 20, my + 14, "打出来是镜像的？按症状判断，不要乱试", 18, RED, "la", True)
    T(d, zx + 20, my + 48, "症状 A：整行左右颠倒（文字反了）        → 送数前把 48 字节的顺序整段反转", 15, INK)
    T(d, zx + 20, my + 78, "症状 B：每 8 个点内部左右颠倒（字变瘦且错位）→ 每个字节的 bit 序反转（x 换成 7-x）", 15, INK)
    T(d, zx + 20, my + 108, "症状 C：整页上下颠倒                    → 行序反转（最后一行先送），或电机方向反了", 15, INK)
    T(d, zx + 20, my + 134, "自查工具：S06 的 bar 命令 + 一张 5mm 网格纸，先看线是不是直的，再看方向。", 15, GRAY)
    SAVE(im, "fig_bitmap.png", W, H)


# ---------------------------------------------------------------- 图 6-3 时序
def fig_timing():
    W, H = 1500, 860
    im, d = NEW(W, H)
    T(d, 40, 24, "一次送数与一次加热的完整时序", 30, INK, "la", True)
    T(d, 40, 66, "CLK 打 384 个脉冲把 48 字节移进去 → LAT 拉低锁存 → STB 拉高 T 微秒加热 → 走纸。", 16, GRAY)

    x0, x1 = 200, 1400
    lanes = [
        ("CLK", 140, 0),
        ("DI", 240, 0),
        ("LAT", 340, 0),
        ("STB1", 440, 0),
        ("STB2..6", 540, 0),
    ]
    for name, y, _ in lanes:
        T(d, 60, y - 12, name, 18, BLUE, "la", True)
        LIN(d, x0, y, x1, y, LGRAY, 1)
    T(d, x0 - 10, 120, "高", 13, GRAY, "ra")

    # CLK 脉冲串
    y = 380 if False else 140
    cx = 260
    pulse = 9
    for i in range(46):
        x = cx + i * 8
        LIN(d, x, y, x + 4, y, GREEN, 2)
        LIN(d, x + 4, y, x + 4, y - 34, GREEN, 2)
        LIN(d, x + 4, y - 34, x + 8, y - 34, GREEN, 2)
        LIN(d, x + 8, y - 34, x + 8, y, GREEN, 2)
    T(d, 300, y - 52, "384 个时钟（图只画一部分）", 14, GREEN, "la")
    T(d, 700, y + 10, "…", 26, GRAY)
    T(d, 780, y - 52, "时钟频率 1MHz → 一位 1µs，384 位 ≈ 384µs", 14, GRAY, "la")

    # DI
    y = 240
    bits = "1 0 1 1 0 0 1 0"
    T(d, 300, y - 6, "MSB 优先送出：bit7 … bit0，再下一个字节", 14, GREEN, "la")
    LIN(d, 300, y + 24, 760, y + 24, GREEN, 2)
    T(d, 300, y + 34, "0b10110010 = 0xB2（示意）", 13, GRAY)

    # LAT
    y = 340
    lx = 900
    LIN(d, x0, y, lx, y, GREEN, 2)
    LIN(d, lx, y, lx, y + 30, GREEN, 2)
    LIN(d, lx, y + 30, lx + 26, y + 30, GREEN, 2)
    LIN(d, lx + 26, y + 30, lx + 26, y, GREEN, 2)
    LIN(d, lx + 26, y, x1, y, GREEN, 2)
    T(d, lx + 13, y + 40, "≥1µs", 13, GRAY, "ma", True)
    T(d, lx + 60, y - 26, "全部 384 位移完后，LAT 拉低 ≥1µs 再拉高：把移位寄存器灌进加热锁存器", 14, GREEN, "la")

    # STB
    y = 440
    sx = lx + 70
    LIN(d, x0, y, sx, y, GREEN, 2)
    LIN(d, sx, y, sx, y - 40, GREEN, 2)
    LIN(d, sx, y - 40, sx + 210, y - 40, GREEN, 2)
    LIN(d, sx + 210, y - 40, sx + 210, y, GREEN, 2)
    LIN(d, sx + 210, y, x1, y, GREEN, 2)
    T(d, sx + 105, y - 60, "T = 加热时间（0.3~1.2ms）", 15, RED, "ma", True)
    T(d, sx + 105, y - 84, "T 越长越黑，也越容易糊纸、越费电", 13, GRAY, "ma")

    # STB2..6
    y = 540
    for k in range(3):
        sx2 = lx + 70 + k * 120
        LIN(d, x0, y, sx2, y, LGRAY, 1)
        LIN(d, sx2, y, sx2, y - 30, GREEN, 2)
        LIN(d, sx2, y - 30, sx2 + 90, y - 30, GREEN, 2)
        LIN(d, sx2 + 90, y - 30, sx2 + 90, y, GREEN, 2)
    T(d, lx + 70, y + 10, "可以 6 段同时开（最黑），也可以一段一段轮流开（省电、温度更均匀）", 14, GRAY, "la")

    # 注释框
    RBOX(d, 60, 600, 1380, 100, LGREEN, GREEN, 12, 2)
    T(d, 80, 614, "三个时间参数的经验值", 17, GREEN, "la", True)
    T(d, 80, 646, "① 时钟 1MHz（再快打印头跟不上）  ② LAT 低脉冲 ≥1µs（短了锁存不稳定）  ③ 加热 T 600~1000µs，视电压与纸种调",
      15, INK)

    RBOX(d, 60, 720, 1380, 110, LRED, RED, 12, 2)
    T(d, 80, 734, "两条会烧头的规则", 17, RED, "la", True)
    T(d, 80, 766, "① STB 为高时不允许改 DI/CLK——先关 STB 再换数据，否则加热区会“拖尾”。", 15, INK)
    T(d, 80, 794, "② 停止打印必须先把 6 路 STB 拉低、再关 VH；反过来做会留下一条黑边，甚至烧断加热点。", 15, INK)
    SAVE(im, "fig_timing.png", W, H)


# ---------------------------------------------------------------- 图 13-1 帧结构
def fig_frame():
    W, H = 1500, 720
    im, d = NEW(W, H)
    T(d, 40, 24, "协议帧：一个字节都不能错", 30, INK, "la", True)
    T(d, 40, 66, "数据帧 = 起始 + 类型 + 序号 + 长度(小端) + 载荷 + CRC32(只算载荷，小端) + 结束", 16, GRAY)

    fields = [
        ("起始", "0x02", 1, LBLUE),
        ("类型", "0x00~0x7F", 1, LBLUE),
        ("序号", "0x00", 1, LBLUE),
        ("长度 L", "低字节", 1, LGREEN),
        ("长度 H", "高字节", 1, LGREEN),
        ("载荷 payload", "0 ~ 1920 字节", 8, LORANGE),
        ("CRC32", "4 字节小端", 4, LRED),
        ("结束", "0x03", 1, LBLUE),
    ]
    x = 60
    y = 140
    unit = 74
    total = sum(f[2] for f in fields)
    scale = 1380 / total
    for name, note, n, fill in fields:
        w = n * scale
        d.rectangle([x * S, y * S, (x + w) * S, (y + 52) * S], fill=fill, outline=LINE, width=int(2 * S))
        T(d, x + w / 2, y + 26, name, 14 if w > 90 else 12, INK, "mm", True)
        T(d, x + w / 2, y + 66, note, 12, GRAY, "ma")
        x += w

    # 实例
    T(d, 60, 280, "实例：查版本 GET_VERSION，没有载荷", 19, INK, "la", True)
    hexs = "02  04  00  00  00  00  00  00  00  03"
    T(d, 60, 316, hexs, 22, GREEN, "la", False, mono=True)
    T(d, 60, 352, "起始 类型4 序号 长度=0        载荷为空  CRC32=00 00 00 00  结束", 14, GRAY)

    T(d, 60, 400, "实例：回版本 SENT_VERSION，载荷 3 字节", 19, INK, "la", True)
    T(d, 60, 436, "02  05  00  03  00  01 00 02  09 D2 8D 10  03", 22, GREEN, "la", False, mono=True)
    T(d, 60, 472, "起始 类型5    长度=3  载荷=版本2.0.1   CRC32(载荷)     结束", 14, GRAY)

    # ACK
    T(d, 60, 530, "ACK 只有 11 字节，而且 CRC 算的是「前 6 字节」——这是全协议最反直觉的一处", 18, RED, "la", True)
    ack = "02 04 00 01 00 00 5F CC 48 08 03"
    T(d, 60, 566, ack, 22, RED, "la", False, mono=True)
    T(d, 60, 602, "起始 类型4 序号0 长度=1 数据=0x00  CRC32(前6字节)   结束", 14, GRAY)
    T(d, 60, 640, "核对：crc32([02,04,00,01,00,00]) = 0x0848CC5F → 小端写成 5F CC 48 08。", 15, INK, "la", True)
    T(d, 60, 672, "所以写固件时：数据帧算载荷，ACK 帧算前 6 字节，两条路不要共用一个入口。", 15, RED, "la", True)
    SAVE(im, "fig_frame.png", W, H)


# ---------------------------------------------------------------- 图 13-2 状态机
def fig_state():
    W, H = 1500, 780
    im, d = NEW(W, H)
    T(d, 40, 24, "八状态解析器：一个字节决定下一步", 30, INK, "la", True)
    T(d, 40, 66, "字节流没有“包”的概念，只能靠状态记住“我现在期待什么”。", 16, GRAY)

    states = [
        ("S_START", "等 0x02", 120, 150),
        ("S_TYPE", "收类型", 400, 150),
        ("S_INDEX", "收序号", 680, 150),
        ("S_LENL", "长度低", 960, 150),
        ("S_LENH", "长度高", 1240, 150),
        ("S_DATA", "收载荷", 1240, 400),
        ("S_CRC", "收 4 字节 CRC", 740, 400),
        ("S_END", "等 0x03", 260, 400),
    ]
    for name, note, x, y in states:
        fill = LORANGE if name in ("S_CRC", "S_END") else LBLUE
        edge = ORANGE if name in ("S_CRC", "S_END") else BLUE
        RBOX(d, x, y, 210, 96, fill, edge, 12, 2)
        T(d, x + 105, y + 34, name, 19, INK, "mm", True)
        T(d, x + 105, y + 64, note, 14, GRAY, "mm")

    ARR(d, 330, 198, 396, 198, BLUE)
    ARR(d, 610, 198, 676, 198, BLUE)
    ARR(d, 890, 198, 956, 198, BLUE)
    ARR(d, 1170, 198, 1236, 198, BLUE)
    # 下折
    LIN(d, 1345, 246, 1345, 400, BLUE)
    HEAD(d, 1345, 398, 90, BLUE)
    ARR(d, 1240, 448, 954, 448, ORANGE)
    ARR(d, 740, 448, 474, 448, ORANGE)
    # 回到起点
    LIN(d, 365, 448, 225, 448, ORANGE)
    LIN(d, 225, 448, 225, 250, ORANGE)
    HEAD(d, 225, 248, -90, ORANGE)

    T(d, 470, 420, "长度用完了", 13, ORANGE, "la")
    T(d, 470, 600, "校验通过 + 结束字节正确 → 交给上层处理", 15, RED, "la", True)

    RBOX(d, 60, 640, 1380, 110, LRED, RED, 12, 2)
    T(d, 80, 654, "四个最容易写错的地方", 17, RED, "la", True)
    T(d, 80, 686, "① 长度是小端：先到的低字节 + 后到的高字节 << 8。  ② 载荷长度上限 1920，超了要丢弃整帧而不是截断。", 14, INK)
    T(d, 80, 714, "③ CRC 跨越 4 个字节，收的过程中不能复位计数。  ④ S_END 收到非 0x03 → 整帧作废，但已收的字节不能回吐。", 14, INK)
    SAVE(im, "fig_state.png", W, H)


# ---------------------------------------------------------------- 图 14-1 握手
def fig_handshake():
    W, H = 1500, 900
    im, d = NEW(W, H)
    T(d, 40, 24, "十步握手：App 一步步问，设备一句句答", 30, INK, "la", True)
    T(d, 40, 66, "每条 GET 都必须回一条同类型的 ACK，否则 App 会一直重发到超时。", 16, GRAY)

    lx, rx = 330, 1150
    RBOX(d, lx - 120, 110, 240, 60, LBLUE, BLUE, 10, 2)
    T(d, lx, 140, "手机 App", 20, INK, "mm", True)
    RBOX(d, rx - 120, 110, 240, 60, LGREEN, GREEN, 10, 2)
    T(d, rx, 140, "打印机固件", 20, INK, "mm", True)
    LIN(d, lx, 170, lx, 830, LGRAY, 2, dash=True)
    LIN(d, rx, 170, rx, 830, LGRAY, 2, dash=True)

    steps = [
        ("设置 CRC 密钥 0x35769521", "24", "→", "← ACK"),
        ("取序列号 SN", "10", "→", "← P1001705253855 + ACK"),
        ("取硬件信息（私有）", "66", "→", "← \"BK3432\" + ACK"),
        ("取固件信息", "127", "→", "← \"v3.38.19\" + ACK"),
        ("设打印浓度 25", "→", "← ACK"),
        ("取设备名", "48", "→", "← \"P1\" + ACK"),
        ("取电池电量", "16", "→", "← 百分比 + ACK"),
        ("取/设自动关机时间", "30/31", "→", "← 分钟数 + ACK"),
        ("取版本", "4", "→", "← 2.0.1 + ACK"),
        ("设纸张类型", "44", "→", "← ACK"),
    ]
    y = 210
    for i, s in enumerate(steps, 1):
        label = s[0]
        T(d, 60, y - 8, "%02d" % i, 15, GRAY, "la", True)
        T(d, lx + 30, y - 8, label, 15, INK, "la")
        ARR(d, lx + 40, y + 14, rx - 40, y + 14, BLUE)
        T(d, (lx + rx) / 2, y + 2, "type=" + (s[1] if len(s) > 1 else ""), 12, BLUE, "ma")
        ARR(d, rx - 40, y + 34, lx + 40, y + 34, GREEN)
        T(d, (lx + rx) / 2, y + 24, "ACK + 数据", 12, GREEN, "ma")
        y += 62

    RBOX(d, 60, 840, 1380, 46, LORANGE, ORANGE, 8, 2)
    T(d, 80, 852, "顺序不能乱：第 1 步的 CRC 密钥会改变后面所有帧的 CRC 初值（示例固件里只做记录，公版 App 不校验）。",
      14, ORANGE, "la", True)
    SAVE(im, "fig_handshake.png", W, H)


if __name__ == "__main__":
    fig_system()
    fig_power()
    fig_bitmap()
    fig_timing()
    fig_frame()
    fig_state()
    fig_handshake()
