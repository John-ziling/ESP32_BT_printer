# -*- coding: utf-8 -*-
import os
import pymupdf

src = os.path.join(r"C:\ESP\ESP32_BT_printer_exp\文档\教程", "蓝牙打印机开发资料-仅供参考.pdf")
outdir = r"C:\Users\31796\Desktop\blt_code\figs"
doc = pymupdf.open(src)

for pno in (21, 25):  # 0-based → 第 22、26 页
    page = doc[pno]
    infos = page.get_image_info(xrefs=True)
    print("page", pno + 1, "images:", [(i["xref"], i["width"], i["height"]) for i in infos])
    best = max(infos, key=lambda i: i["width"] * i["height"])
    xref = best["xref"]
    d = doc.extract_image(xref)
    name = "p%02d_x%d.%s" % (pno + 1, xref, d["ext"])
    with open(os.path.join(outdir, name), "wb") as f:
        f.write(d["image"])
    print("saved", name, d["width"], d["height"])
