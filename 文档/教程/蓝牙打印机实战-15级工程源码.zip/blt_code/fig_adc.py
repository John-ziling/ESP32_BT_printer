# -*- coding: utf-8 -*-
"""第 11 章配图：三路传感器电路（分压 / NTC / 光电比较器）。"""
import os
from PIL import Image, ImageDraw, ImageFont

OUT = r"C:\Users\31796\Desktop\blt_code\figs"
S = 2
MSYH = r"C:\Windows\Fonts\msyh.ttc"
MSYHB = r"C:\Windows\Fonts\msyhbd.ttc"

INK = (34, 40, 49)
GRAY = (110, 118, 128)
LINE = (70, 80, 92)
BLUE = (31, 78, 121)
LBLUE = (226, 236, 246)
GREEN = (28, 110, 90)
LGREEN = (226, 242, 236)
ORANGE = (176, 96, 24)
LORANGE = (252, 238, 222)
RED = (168, 40, 40)
WHITE = (255, 255, 255)


def F(sz, bold=False):
    return ImageFont.truetype(MSYHB if bold else MSYH, int(sz * S))


def T(d, x, y, s, sz=16, color=INK, anchor="la", bold=False):
    d.text((x * S, y * S), s, font=F(sz, bold), fill=color, anchor=anchor)


def L(d, x1, y1, x2, y2, color=LINE, w=2):
    d.line([(x1 * S, y1 * S), (x2 * S, y2 * S)], fill=color, width=int(w * S))


def BOXR(d, x, y, w, h, fill=WHITE, edge=LINE, r=8, width=2):
    d.rounded_rectangle([x * S, y * S, (x + w) * S, (y + h) * S], radius=r * S,
                        fill=fill, outline=edge, width=int(width * S))


def RES(d, x, y, w=44, h=18, fill=WHITE, edge=LINE, label=None, lx=0, ly=-24):
    """水平电阻符号"""
    d.rectangle([x * S, (y - h / 2) * S, (x + w) * S, (y + h / 2) * S], fill=fill, outline=edge, width=int(2 * S))
    if label:
        T(d, x + w / 2 + lx, y + ly, label, 14, GRAY, "ma", True)


def DOT(d, x, y, r=4, color=LINE):
    d.ellipse([(x - r) * S, (y - r) * S, (x + r) * S, (y + r) * S], fill=color)


def NEW(w, h):
    im = Image.new("RGB", (w * S, h * S), WHITE)
    return im, ImageDraw.Draw(im)


def SAVE(im, name, w, h):
    im = im.resize((w, h), Image.LANCZOS)
    p = os.path.join(OUT, name)
    im.save(p)
    print("saved", p, im.size)


W, H = 1560, 980
im, d = NEW(W, H)
T(d, 40, 24, "三路传感器：一个分压、一个 NTC、一个比较器", 30, INK, "la", True)
T(d, 40, 66, "三张子图对应 11.3~11.5 的三个公式；照着量一遍，比读十遍公式管用。", 16, GRAY)

# ---------------- (a) 电池分压 ----------------
BOXR(d, 40, 110, 480, 380, WHITE, BLUE, 12, 2)
T(d, 60, 126, "（a）电池分压 → IO34", 19, BLUE, "la", True)

cx = 150
# VBAT
T(d, cx, 168, "VBAT_OUT", 15, INK, "ma", True)
T(d, cx, 190, "3.0~4.2V", 13, GRAY, "ma")
L(d, cx, 205, cx, 240)
RES(d, cx - 22, 250, 44, 18, label="R1 = 10kΩ")
L(d, cx, 260, cx, 330)
DOT(d, cx, 330)
L(d, cx, 330, cx + 120, 330, GREEN, 3)
T(d, cx + 130, 318, "POWER_ADC", 15, GREEN, "la", True)
T(d, cx + 130, 342, "→ IO34（ADC1）", 13, GRAY, "la")
RES(d, cx - 22, 400, 44, 18, label="R2 = 10kΩ")
L(d, cx, 330, cx, 390)
L(d, cx, 410, cx, 440)
L(d, cx - 26, 440, cx + 26, 440, LINE, 2)
L(d, cx - 16, 448, cx + 16, 448, LINE, 2)
L(d, cx - 6, 456, cx + 6, 456, LINE, 2)
T(d, cx, 470, "GND", 13, GRAY, "ma")

T(d, 300, 250, "V_pin = V_bat × R2/(R1+R2)", 15, INK, "la", True)
T(d, 300, 280, "1:1 → V_pin = V_bat / 2", 15, GREEN, "la")
T(d, 300, 310, "满电 4.2V → 引脚 2.10V", 14, GRAY, "la")
T(d, 300, 336, "→ raw ≈ 2606", 14, GRAY, "la")
T(d, 300, 372, "静态耗流 4.2V/20k = 210µA", 13, ORANGE, "la", True)
T(d, 300, 398, "（比深睡电流大 20 倍）", 13, ORANGE, "la")
T(d, 300, 436, "1 LSB = 0.806mV × 2", 13, INK, "la")
T(d, 300, 458, "      ≈ 1.61mV 电池电压", 13, INK, "la")

# ---------------- (b) NTC ----------------
BOXR(d, 540, 110, 480, 380, WHITE, GREEN, 12, 2)
T(d, 560, 126, "（b）打印头 NTC → IO36", 19, GREEN, "la", True)
cx = 650
T(d, cx, 158, "3V3", 15, INK, "ma", True)
L(d, cx, 175, cx, 205)
RES(d, cx - 22, 215, 44, 18, fill=WHITE, edge=LINE, label="R_pull 10kΩ")
L(d, cx, 225, cx, 300)
DOT(d, cx, 300)
L(d, cx, 300, cx + 120, 300, ORANGE, 3)
T(d, cx + 130, 288, "THER", 15, ORANGE, "la", True)
T(d, cx + 130, 312, "→ IO36（ADC1）", 13, GRAY, "la")
# NTC 用带斜线的方块表示
d.rectangle([(cx - 24) * S, 360 * S, (cx + 24) * S, 412 * S], fill=LORANGE, outline=ORANGE, width=int(2 * S))
L(d, cx - 24, 412, cx + 24, 360, ORANGE, 2)
L(d, cx, 300, cx, 360)
L(d, cx, 412, cx, 440)
L(d, cx - 26, 440, cx + 26, 440, LINE, 2)
L(d, cx - 16, 448, cx + 16, 448, LINE, 2)
L(d, cx - 6, 456, cx + 6, 456, LINE, 2)
T(d, cx, 470, "GND", 13, GRAY, "ma")
T(d, cx + 40, 380, "NTC", 14, ORANGE, "la", True)

T(d, 800, 215, "R_ntc = R_pull × raw/(4095−raw)", 14, INK, "la", True)
T(d, 800, 245, "1/T = 1/T25 + ln(R/R25)/B", 14, INK, "la", True)
T(d, 800, 275, "T = 1/( … ) − 273.15", 14, INK, "la", True)
T(d, 800, 320, "25°C 时引脚约 2.48V", 13, GRAY, "la")
T(d, 800, 344, "（R25=30k 的那批头）", 13, GRAY, "la")
T(d, 800, 380, "灵敏度约 4.45%/°C", 13, GREEN, "la", True)
T(d, 800, 404, "→ 中段 0.026°C/LSB", 13, GREEN, "la")
T(d, 800, 440, "误差主要是 R25/B 容差", 13, ORANGE, "la")

# ---------------- (c) 光电 + 比较器 ----------------
BOXR(d, 1040, 110, 480, 380, WHITE, ORANGE, 12, 2)
T(d, 1060, 126, "（c）缺纸光电 + 比较器 → IO35", 19, ORANGE, "la", True)
T(d, 1060, 166, "打印头 FPC 上的红外对管：", 14, INK, "la")
T(d, 1060, 190, "  发射管 PHE ⟶ 纸面反射 ⟶ 接收管", 14, INK, "la")
T(d, 1060, 214, "  LM393 整形后输出到 PHINT", 14, INK, "la")

# 简化：纸 + 反射
L(d, 1090, 300, 1250, 300, GRAY, 2)          # 纸
T(d, 1170, 306, "纸", 14, GRAY, "ma")
L(d, 1110, 260, 1110, 296, RED, 3)
T(d, 1110, 246, "发射", 12, RED, "ma")
L(d, 1110, 304, 1110, 340, RED, 3)
T(d, 1110, 344, "接收", 12, RED, "ma")
d.arc([(1100) * S, (270) * S, (1130) * S, (330) * S], 300, 60, fill=RED, width=int(2 * S))

T(d, 1270, 250, "有纸 → 接收管导通", 14, GREEN, "la", True)
T(d, 1270, 274, "比较器输出 LOW", 14, GREEN, "la")
T(d, 1270, 300, "无纸 → 截止", 14, RED, "la", True)
T(d, 1270, 324, "比较器输出 HIGH", 14, RED, "la")
T(d, 1270, 360, "R32 10k 上拉稳定高电平", 13, GRAY, "la")
T(d, 1270, 384, "R35/R36/R31 定比较阈值", 13, GRAY, "la")

T(d, 1060, 420, "代码：paper_present() = (digitalRead(PIN_PHINT) == LOW)", 14, INK, "la", True)
T(d, 1060, 444, "去抖：状态连续 30ms 不变才采纳", 13, GRAY, "la")

# ---------------- 底部：一句话对照 ----------------
BOXR(d, 40, 520, 1480, 200, LGREEN, GREEN, 12, 2)
T(d, 60, 536, "三个公式放在一起记", 19, GREEN, "la", True)
T(d, 60, 574, "①  电池：V_bat = raw × 3300/4095 × (R1+R2)/R2        —— 别忘了乘分压比，这是原示例最常错的地方", 15, INK)
T(d, 60, 606, "②  温度：R_ntc = R_pull × raw/(4095 − raw)，再代 B 方程  —— 分压公式与 R25 无关，R25 只影响 B 方程", 15, INK)
T(d, 60, 638, "③  缺纸：数字量，别过 ADC；有纸=LOW，无纸=HIGH，去抖 30ms", 15, INK)
T(d, 60, 676, "三个量都先跑一次 raw 值，和万用表/温度计对一遍，再谈“准不准”。", 15, RED, "la", True)
T(d, 60, 700, "raw 合理区间：电池 2100~2600、NTC 1400~3700、PHINT 只有 0/1。", 14, GRAY, "la")

BOXR(d, 40, 750, 1480, 190, LORANGE, ORANGE, 12, 2)
T(d, 60, 766, "上电自检的三条判据（写进出厂自检页）", 19, ORANGE, "la", True)
T(d, 60, 804, "· 电池 raw < 1900（<3.1V）或 > 4090（开路）→ FAIL，提示接电池", 15, INK)
T(d, 60, 836, "· NTC raw < 100 或 > 4050 → FAIL，提示打印头排线没插好", 15, INK)
T(d, 60, 868, "· 缺纸脚读数在 10 秒内跳变超过 20 次 → 提示清洁检测窗（积灰会导致误判）", 15, INK)

SAVE(im, "fig_adc.png", W, H)
