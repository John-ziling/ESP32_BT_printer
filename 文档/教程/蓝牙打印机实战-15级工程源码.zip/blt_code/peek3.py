# -*- coding: utf-8 -*-
import glob
import sys
import pymupdf

pdf = glob.glob(r"C:\Users\31796\Desktop\blt_code\build\*.pdf")[0]
doc = pymupdf.open(pdf)
out = []
for pno in (4, 5, 6, 7, 8):
    t = doc[pno - 1].get_text()
    out.append("=== page %d (%d chars) ===\n%s\n" % (pno, len(t), t[:500]))
open(r"C:\Users\31796\Desktop\blt_code\peek_out.txt", "w", encoding="utf-8").write("".join(out))
print("ok")
