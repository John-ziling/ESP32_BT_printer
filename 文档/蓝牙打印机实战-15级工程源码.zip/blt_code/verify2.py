import fitz, glob, os, sys

d = r"C:\Users\31796\Desktop\blt_code\build"
pdf = [p for p in glob.glob(os.path.join(d, "*.pdf"))][0]
doc = fitz.open(pdf)
print("PAGES", doc.page_count)

imgs = 0
pages_with_img = []
for i, p in enumerate(doc):
    n = len(p.get_images(full=True))
    imgs += n
    if n:
        pages_with_img.append(i + 1)
print("IMAGES", imgs, "on pages", pages_with_img)

empty = [i + 1 for i, p in enumerate(doc) if len(p.get_text().strip()) < 12]
print("NEAR-EMPTY", empty)

txt = "".join(p.get_text() for p in doc)
for s in ["S00", "S14", "FrameParser", "crc32", "MaoPaperang", "heat_mask",
          "printpipe", "esp_deep_sleep_start", "esp_task_wdt", "附录 D"]:
    print(f"  {s:22s} {txt.count(s)}")

# TOC pages: find lines with leader dots on page 2-3
for i in (1, 2):
    t = doc[i].get_text()
    print("---- page", i + 1, "----")
    print(t[:900])
