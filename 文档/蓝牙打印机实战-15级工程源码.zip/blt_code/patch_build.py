import io, re
p = r"C:\Users\31796\Desktop\blt_code\build2.py"
s = io.open(p, encoding="utf-8").read()

s = s.replace('BASE = r"C:\\Users\\31796\\Desktop\\blt_work"',
              'BASE = r"C:\\Users\\31796\\Desktop\\blt_code"')
s = s.replace('OUT = os.path.join(BASE, "蓝牙热敏打印机开发教程.docx")',
              'OUT = os.path.join(BASE, "build", "蓝牙打印机实战-手把手敲代码.docx")')

anchor = "        # image\n        m = re.match(r'^!\\[\\[(.+?)\\]\\]$', s)"
inc = ("        # source include:  <<<stages/s10/src/frame.cpp>>>\n"
       "        m = re.match(r'^<<<(.+?)>>>$', s)\n"
       "        if m:\n"
       "            inc = os.path.join(BASE, m.group(1).replace('/', os.sep))\n"
       "            if os.path.exists(inc):\n"
       "                with io.open(inc, encoding='utf-8', errors='replace') as g:\n"
       "                    add_code([l.rstrip('\\n') for l in g.readlines()])\n"
       "            else:\n"
       "                pr = doc.add_paragraph()\n"
       "                rr = pr.add_run('[缺文件: ' + m.group(1) + ']')\n"
       "                set_run_font(rr, size=9, color=RGBColor(0xCC, 0, 0))\n"
       "            i += 1; continue\n\n")
assert anchor in s, "anchor missing"
s = s.replace(anchor, inc + anchor, 1)
if "import io" not in s.split("\n")[2]:
    s = s.replace("import os, re, sys, glob", "import os, re, sys, glob\nimport io", 1)
io.open(p, "w", encoding="utf-8", newline="\n").write(s)
print("patched")
