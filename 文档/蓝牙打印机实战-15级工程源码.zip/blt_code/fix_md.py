import io

p0 = r"C:\Users\31796\Desktop\blt_code\md\p0.md"
s = io.open(p0, encoding="utf-8").read()
s = s.replace("## 1.5 内存分三块，`malloc` 可能失败", "## 1.5 内存分三块，malloc 可能失败")
s = s.replace("## 1.11 低功耗不是 `WFI`，是 `deep sleep`", "## 1.11 低功耗不是 WFI，是 deep sleep")
io.open(p0, "w", encoding="utf-8").write(s)

p8 = r"C:\Users\31796\Desktop\blt_code\md\p8.md"
t = io.open(p8, encoding="utf-8").read()
old = "---\n\n**本教程配套代码：`C:\\Users\\31796\\Desktop\\blt_code\\`，15 个可编译工程 + final。**"
new = "**本教程配套代码位于 `C:\\Users\\31796\\Desktop\\blt_code\\`，共 15 个可编译工程，另附 final 整机工程。**"
assert old in t, t[-300:]
t = t.replace(old, new)
io.open(p8, "w", encoding="utf-8").write(t)
print("ok")
print(repr(t[-140:]))
