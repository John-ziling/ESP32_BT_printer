#include <Arduino.h>
#include <BluetoothSerial.h>
BluetoothSerial SerialBT;
void setup(){ Serial.begin(115200); SerialBT.begin("TestBT"); }
void loop(){ if(SerialBT.available()) Serial.write(SerialBT.read()); delay(1); }
