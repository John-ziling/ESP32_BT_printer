$ErrorActionPreference = 'Stop'
$dir = 'C:\Users\31796\Desktop\blt_code\build'
$docx = Get-ChildItem -Path $dir -Filter *.docx | Select-Object -First 1
if (-not $docx) { Write-Output 'NO DOCX'; exit 1 }
$pdf = [System.IO.Path]::ChangeExtension($docx.FullName, '.pdf')
Write-Output ("DOCX: " + $docx.FullName)
$word = New-Object -ComObject Word.Application
$word.Visible = $false
$word.DisplayAlerts = 0
try {
  $doc = $word.Documents.Open($docx.FullName, $false, $false)

  # 1) first update: creates TOC 1 / TOC 2 styles
  $doc.Fields.Update() | Out-Null
  if ($doc.TablesOfContents.Count -gt 0) { $doc.TablesOfContents.Item(1).Update() }

  # 2) tighten TOC styles so the TOC does not eat 6 pages
  foreach ($nm in @('TOC 1', 'TOC 2')) {
    try {
      $st = $doc.Styles.Item($nm)
      $st.Font.Size = 9
      $st.Font.Name = 'DengXian'
      $st.Font.NameFarEast = 'DengXian'
      $st.ParagraphFormat.SpaceBefore = 0
      $st.ParagraphFormat.SpaceAfter = 0
      $st.ParagraphFormat.LineSpacingRule = 0
    } catch {
      Write-Output ("skip style: " + $nm)
    }
  }

  # 3) repaginate then update again so page numbers match the tightened layout
  $doc.Repaginate()
  if ($doc.TablesOfContents.Count -gt 0) { $doc.TablesOfContents.Item(1).Update() }
  foreach ($s in $doc.Sections) {
    foreach ($h in $s.Headers) { $h.Range.Fields.Update() | Out-Null }
    foreach ($f in $s.Footers) { $f.Range.Fields.Update() | Out-Null }
  }
  $doc.Repaginate()
  $pages = $doc.ComputeStatistics(2)
  Write-Output ("PAGES: " + $pages)
  $doc.Save()
  $doc.ExportAsFixedFormat($pdf, 17, $false, 0, 0, 0, 0, 0, $true, $true, 2, $true, $true, $false)
  $doc.Close(0)
  Write-Output ("PDF: " + $pdf)
} finally {
  $word.Quit()
  [System.Runtime.InteropServices.Marshal]::ReleaseComObject($word) | Out-Null
}
