# -*- coding: utf-8 -*-
"""生成 8x16 点阵 ASCII 字库 font8x16.h（0x20~0x7E，95 个字符）
用宋体 16px 直接渲染（8 像素宽正好一格，宽度 8.0），阈值 100 二值化。
基线：大写字母底边落在第 13 行，下面 2 行留给 g/j/p/q/y 的尾巴。
"""
import os
from PIL import Image, ImageDraw, ImageFont

OUT = r"C:\Users\31796\Desktop\blt_code\stages\s07\include\font8x16.h"
FONT_PATH = r"C:\Windows\Fonts\simsun.ttc"
BASELINE = 13
THRESH = 100

font = ImageFont.truetype(FONT_PATH, 16, index=0)
ascent, descent = font.getmetrics()
dy = BASELINE - ascent

def bitmap(ch):
    if ch == " ":
        return [0] * 16
    img = Image.new("L", (8, 16), 0)
    ImageDraw.Draw(img).text((0, dy), ch, font=font, fill=255)
    px = img.load()
    return [sum((0x80 >> x) for x in range(8) if px[x, y] >= THRESH)
            for y in range(16)]

glyphs = [bitmap(chr(c)) for c in range(0x20, 0x7F)]

lines = [
    "// =====================================================",
    "//  font8x16.h —— 8x16 点阵 ASCII 字库（0x20~0x7E）",
    "//  每个字符 16 行，每行 1 字节，bit7 = 最左边那个点",
    "//  由 gen_font.py 生成；想改字形直接改十六进制即可",
    "// =====================================================",
    "#pragma once",
    "#include <stdint.h>",
    "",
    "#define FONT8X16_FIRST 0x20",
    "#define FONT8X16_LAST  0x7E",
    "",
    "static const uint8_t FONT8X16[%d][16] = {" % len(glyphs),
]
for i, rows in enumerate(glyphs):
    code = 0x20 + i
    hexs = ", ".join("0x%02X" % b for b in rows)
    lines.append("  { %s },  // %d 0x%02X" % (hexs, i, code))
lines += ["};", ""]

os.makedirs(os.path.dirname(OUT), exist_ok=True)
with open(OUT, "w", encoding="utf-8", newline="\n") as f:
    f.write("\n".join(lines))

def show(code):
    print("char %r" % chr(code))
    for r in glyphs[code - 0x20]:
        print("   |" + "".join("#" if (r >> (7 - x)) & 1 else "." for x in range(8)) + "|")

for c in (ord("A"), ord("g"), ord("0"), ord("M"), ord("W"), ord("@")):
    show(c)
print("total ink bytes:", sum(1 for g in glyphs for b in g if b))
print("wrote", OUT, len(glyphs), "glyphs")
