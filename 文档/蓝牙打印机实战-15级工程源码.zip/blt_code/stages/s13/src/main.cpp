// =====================================================
//  S13 · 可靠性：看门狗、自动关机、低压保护、过热降速
//  目标：扔在包里一小时不会跑光电，卡死能自己起来
//  验证：hang 5 → 5 秒后看到 "rst:0x8 (TG1WDT_SYS_RST)" 重启日志
//        power 60 → 一分钟后自动休眠
// =====================================================
#include <Arduino.h>
#include "config.h"
#include "bt.h"
#include "shell.h"
#include "frame.h"
#include "proto.h"
#include "printer.h"
#include "printhead.h"
#include "printpipe.h"
#include "canvas.h"
#include "sensors.h"
#include "power.h"

static FrameParser s_parser;
static Frame       s_frame;

static void on_bt(uint8_t b) {
  power_touch();                     // 有数据往来就不关机
  int r = s_parser.feed(b, s_frame);
  if (r == 1) proto_handle(s_frame);
}

static void cmd_page(int, char **) {
  if (!paper_present()) { Serial.println("no paper"); return; }
  if (power_low_batt()) {
    Serial.printf("battery low (%umV), refuse to print\n", batt_mv());
    return;
  }
  const uint16_t rows = 300;
  Canvas c;
  if (!canvas_alloc(c, rows)) { Serial.println("alloc failed"); return; }
  canvas_clear(c);
  canvas_rect(c, 2, 2, 380, rows - 4, false);
  canvas_text(c, 8, 8,  "S13 RELIABILITY PAGE");
  canvas_text(c, 8, 26, "wdt / sleep / thermal guard");
  canvas_hline(c, 8, 42, 368);
  canvas_text(c, 8, 52, "head temp and battery are guarded");
  canvas_text(c, 8, rows - 28, "END");

  pipe_init();
  printhead_vh(true);
  uint32_t t0 = millis();
  pipe_push(c.buf, rows * ROW_BYTES);
  pipe_flush();
  Serial.printf("page: %u rows in %lu ms\n", rows, (unsigned long)(millis() - t0));
  canvas_free(c);
}

static void cmd_status(int, char **) {
  Serial.printf("uptime=%lus idle=%lus timeout=%lus\n",
                (unsigned long)(millis() / 1000), (unsigned long)power_idle_s(),
                (unsigned long)0);
  Serial.printf("bt=%s paper=%d batt=%umV(%u%%) head=%dC\n",
                bt_connected() ? "UP" : "down", (int)paper_present(),
                batt_mv(), batt_percent(batt_mv()), head_celsius());
  Serial.printf("heap=%u bytes\n", (unsigned)ESP.getFreeHeap());
}

static void cmd_power(int argc, char **argv) {
  if (argc >= 2) power_set_timeout((uint32_t)strtoul(argv[1], nullptr, 0));
  Serial.printf("idle timeout = %lus (0 = never)\n", (unsigned long)0);
}

static void cmd_sleep(int, char **) { power_sleep(); }

// 故意卡死，用来演示看门狗：5 秒后芯片自己复位
static void cmd_hang(int argc, char **argv) {
  int s = (argc >= 2) ? atoi(argv[1]) : 5;
  Serial.printf("hanging %d s on purpose (wdt will reset)\n", s);
  delay(s * 1000);
  Serial.println("if you see this, wdt is NOT working");
}

void setup() {
  Serial.begin(115200);
  delay(200);
  Serial.println();
  Serial.println("=== STAGE 13 · reliability ===");
  Serial.printf("reset reason = %d\n", (int)esp_reset_reason());

  printer_init();
  sensors_init();
  pipe_init();
  proto_init();
  s_parser.reset();
  bt_set_rx_hook(on_bt);
  bt_start();
  wdt_begin();
  power_init(3600);          // 一小时无操作休眠；调试时改成 0

  shell_init(Serial);
  shell_add("page",   cmd_page,   "print reliability test page");
  shell_add("status", cmd_status, "system status");
  shell_add("power",  cmd_power,  "power <idle_seconds>");
  shell_add("sleep",  cmd_sleep,  "enter deep sleep now");
  shell_add("hang",   cmd_hang,   "hang <s> : demo watchdog");
  Serial.print("> ");
}

void loop() {
  bt_poll();
  shell_poll();
  power_tick();
  wdt_feed();                // 只要 loop 在转就喂狗
}
