// =====================================================
//  proto.cpp —— 命令分发：一条命令 = 一个 ACK + 可能的应答
//  顺序很重要：公版 App 收到 ACK 才认为这条指令成功，
//  收不到会重发，重发到超时就直接报"连接失败"。
// =====================================================
#include "proto.h"
#include "bt.h"
#include "printer.h"
#include "sensors.h"
#include <Arduino.h>

uint32_t g_crc_key = 0;
uint8_t  g_density = 64;
uint32_t g_powerdown_s = 3600;

static const char DEV_SN[]      = "P1001705253855";
static const char DEV_NAME[]    = "P1";
static const char COUNTRY[]     = "CN";
static const uint8_t DEV_VER[3] = {0x01, 0x00, 0x02};      // 2.0.1
static const uint8_t FW_TAG[12] = {0x76, 0x33, 0x2e, 0x33,  // "v3.38.19"
                                   0x38, 0x2e, 0x31, 0x39, 0, 0, 0, 0};
static const char MCU_TAG[]     = "BK3432";                 // 厂商蓝牙芯片型号
static const char BOARD_TAG[]   = "HME230_P2";

static uint8_t s_tx[FRAME_MAX_PAYLOAD + 16];
static PrintCfg  s_cfg = {800, 500, 4};   // 与 s06 默认一致

static void out(const uint8_t *d, size_t n) {
  if (bt_write(d, n) == 0) {          // 没连手机时打到串口，方便桌面验证
    Serial.print("  [tx] ");
    hexdump(d, n);
  }
}

void proto_send_frame(uint8_t type, const uint8_t *payload, uint16_t len) {
  uint16_t n = frame_build(type, 0x00, payload, len, s_tx, sizeof(s_tx));
  if (n) out(s_tx, n);
}

void proto_send_ack(uint8_t type) {
  uint8_t ack[ACK_LEN];
  ack_build(type, ack);
  out(ack, ACK_LEN);
}

void proto_init() {
  g_crc_key = 0;
  g_density = 64;
  g_powerdown_s = 3600;
}

void proto_handle(const Frame &f) {
  switch (f.type) {
    case CMD_GET_VERSION:
      proto_send_ack(f.type);
      proto_send_frame(CMD_SENT_VERSION, DEV_VER, sizeof(DEV_VER));
      break;

    case CMD_GET_MODEL:
      proto_send_ack(f.type);
      proto_send_frame(CMD_SENT_MODEL, (const uint8_t *)DEV_NAME, strlen(DEV_NAME));
      break;

    case CMD_GET_SN:
      proto_send_ack(f.type);
      proto_send_frame(CMD_SENT_SN, (const uint8_t *)DEV_SN, strlen(DEV_SN));
      break;

    case CMD_GET_DEV_NAME:
      proto_send_ack(f.type);
      proto_send_frame(CMD_SENT_DEV_NAME, (const uint8_t *)DEV_NAME, strlen(DEV_NAME));
      break;

    case CMD_GET_COUNTRY_NAME:
      proto_send_ack(f.type);
      proto_send_frame(CMD_SENT_COUNTRY_NAME, (const uint8_t *)COUNTRY, strlen(COUNTRY));
      break;

    case CMD_GET_BAT_STATUS: {
      proto_send_ack(f.type);
      uint8_t pct = batt_percent(batt_mv());
      proto_send_frame(CMD_SENT_BAT_STATUS, &pct, 1);
      break;
    }

    case CMD_GET_TEMP: {
      proto_send_ack(f.type);
      int16_t t = head_celsius();
      uint8_t v = (t < 0) ? 0 : (uint8_t)t;     // 负值/开路当 0 上报
      proto_send_frame(CMD_SENT_TEMP, &v, 1);
      break;
    }

    case CMD_SET_HEAT_DENSITY:
      if (f.len >= 1) g_density = f.payload[0];
      proto_send_ack(f.type);
      break;

    case CMD_GET_HEAT_DENSITY:
      proto_send_ack(f.type);
      proto_send_frame(CMD_SENT_HEAT_DENSITY, &g_density, 1);
      break;

    case CMD_SET_CRC_KEY:
      if (f.len >= 4) {
        g_crc_key = (uint32_t)f.payload[0] | ((uint32_t)f.payload[1] << 8) |
                    ((uint32_t)f.payload[2] << 16) | ((uint32_t)f.payload[3] << 24);
      }
      proto_send_ack(f.type);
      break;

    case CMD_SET_POWER_DOWN_TIME:
      if (f.len >= 2) g_powerdown_s = (uint32_t)f.payload[0] | ((uint32_t)f.payload[1] << 8);
      if (g_powerdown_s > 86400UL) g_powerdown_s = 86400UL;   // 上限 24h，防溢出
      proto_send_ack(f.type);
      break;

    case CMD_GET_POWER_DOWN_TIME: {
      proto_send_ack(f.type);
      uint8_t b[2] = {(uint8_t)(g_powerdown_s & 0xFF), (uint8_t)(g_powerdown_s >> 8)};
      proto_send_frame(CMD_SENT_POWER_DOWN_TIME, b, 2);
      break;
    }

    case CMD_GET_PAPER_TYPE:
      proto_send_ack(f.type);
      { uint8_t t = 0x00; proto_send_frame(CMD_SENT_PAPER_TYPE, &t, 1); }
      break;

    case CMD_SET_PAPER_TYPE:
      proto_send_ack(f.type);
      break;

    case CMD_FEED_LINE:
      proto_send_ack(f.type);
      printer_feed_rows(20, s_cfg);          // 走 20 行 ≈ 2.5mm
      break;

    case CMD_FEED_TO_HEAD_LINE:
      proto_send_ack(f.type);
      printer_feed_rows(40, s_cfg);
      break;

    case CMD_TRANSFER_FW_INFO:         // 66：App 查蓝牙芯片
      proto_send_ack(f.type);
      proto_send_frame(67, (const uint8_t *)MCU_TAG, strlen(MCU_TAG));
      break;

    case 127:
      proto_send_ack(f.type);
      proto_send_frame(128, FW_TAG, sizeof(FW_TAG));
      break;

    case 129:                          // 板型/硬件信息
      proto_send_ack(f.type);
      proto_send_frame(130, (const uint8_t *)BOARD_TAG, strlen(BOARD_TAG));
      break;

    case CMD_SET_DENSITY_EXT:          // 64/65：老版本 App 的"确认"命令
      proto_send_ack(f.type);
      proto_send_frame(65, (const uint8_t *)"\x00", 1);
      break;

    case CMD_DISCONNECT_BT:
      proto_send_ack(f.type);
      Serial.println("[proto] app asked disconnect");
      bt_stop();
      break;

    case CMD_PRINT_DATA:
      proto_send_ack(f.type);          // s12 会换成真正的打印
      break;

    default:
      // 没实现的命令也必须 ACK，否则 App 认为设备掉线
      proto_send_ack(f.type);
      break;
  }
}
