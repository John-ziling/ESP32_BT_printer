// =====================================================
//  S11 · 握手：让公版 App 认为"这是一台喵喵机"
//  目标：App 连上后不再提示"连接失败"
//  验证：handshake 命令跑完整 10 步，每步都有 ACK + 对应应答
// =====================================================
#include <Arduino.h>
#include "config.h"
#include "bt.h"
#include "shell.h"
#include "frame.h"
#include "proto.h"
#include "printer.h"
#include "sensors.h"

static FrameParser s_parser;
static Frame       s_frame;

static void on_bt(uint8_t b) {
  int r = s_parser.feed(b, s_frame);
  if (r == 1)       proto_handle(s_frame);
  else if (r == -1) Serial.printf("[frame] bad, ok=%lu bad=%lu\n",
                                 (unsigned long)s_parser.ok_cnt,
                                 (unsigned long)s_parser.bad_cnt);
}

// 把一条"App 请求"喂进解析器，走完整链路
static void sim(uint8_t type, const uint8_t *pl = nullptr, uint16_t len = 0) {
  uint8_t buf[64];
  uint16_t n = frame_build(type, 0x00, pl, len, buf, sizeof(buf));
  Serial.printf("-> req type=%u len=%u\n", type, len);
  for (uint16_t i = 0; i < n; i++) s_parser.feed(buf[i], s_frame);
}

static void cmd_handshake(int, char **) {
  Serial.println("=== 10-step handshake (simulated app) ===");
  uint8_t key[4] = {0x21, 0x95, 0x76, 0x35};       // 0x35769521 小端
  uint8_t den[1] = {64};
  uint8_t dt[2]  = {0x10, 0x0E};                   // 3600 s
  sim(CMD_SET_CRC_KEY, key, 4);
  sim(CMD_GET_SN);
  sim(CMD_TRANSFER_FW_INFO);
  sim(127);
  sim(CMD_SET_HEAT_DENSITY, den, 1);
  sim(CMD_GET_DEV_NAME);
  sim(CMD_GET_BAT_STATUS);
  sim(CMD_SET_POWER_DOWN_TIME, dt, 2);
  sim(CMD_GET_VERSION);
  sim(CMD_SET_PAPER_TYPE, den, 1);
  Serial.println("=== handshake done; every step should show [tx] ===");
}

static void cmd_info(int, char **) {
  Serial.printf("crc_key=%08X density=%u powerdown=%lus\n",
                (unsigned)g_crc_key, g_density, (unsigned long)g_powerdown_s);
  Serial.printf("batt=%umV %u%%  head=%dC  paper=%d\n",
                batt_mv(), batt_percent(batt_mv()), head_celsius(), paper_present());
}

static void cmd_density(int argc, char **argv) {
  if (argc >= 2) g_density = (uint8_t)constrain(atoi(argv[1]), 0, 100);
  Serial.printf("density = %u\n", g_density);
}

static void cmd_ask(int argc, char **argv) {
  if (argc < 2) { Serial.println("usage: ask <type>"); return; }
  sim((uint8_t)strtoul(argv[1], nullptr, 0));
}

void setup() {
  Serial.begin(115200);
  delay(200);
  Serial.println();
  Serial.println("=== STAGE 11 · handshake ===");
  Serial.println("手机连上后若 App 不再报错，说明握手通了");

  printer_init();
  sensors_init();
  proto_init();
  s_parser.reset();
  bt_set_rx_hook(on_bt);
  bt_start();

  shell_init(Serial);
  shell_add("handshake", cmd_handshake, "run 10-step handshake locally");
  shell_add("info",      cmd_info,      "device state");
  shell_add("density",   cmd_density,   "density [0-100]");
  shell_add("ask",       cmd_ask,       "ask <type> : simulate one request");
  Serial.print("> ");
}

void loop() {
  bt_poll();
  shell_poll();
}
