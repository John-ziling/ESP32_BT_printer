// =====================================================
//  S07 · 位图与测试页：把"点"组织成"页面"
//  目标：一次画一整页，再整页打出来，得到一张能看的测试页
//  验证：文字可读、灰阶四档肉眼可分、边框闭合
// =====================================================
#include <Arduino.h>
#include "config.h"
#include "printer.h"
#include "printhead.h"
#include "motor.h"
#include "canvas.h"
#include "shell.h"

static PrintCfg s_cfg = {800, 500, 4};
static Canvas   s_page;

// ---------------- 画一张测试页 ----------------
static uint16_t build_test_page() {
  static const uint16_t PAGE_ROWS = 360;   // 360 行 ≈ 45mm
  if (!canvas_alloc(s_page, PAGE_ROWS)) {
    Serial.println("! canvas alloc failed");
    return 0;
  }
  canvas_clear(s_page);

  // 外框：闭合的方框最容易看出"行有没有对齐、列有没有错位"
  canvas_rect(s_page, 2, 2, ROW_DOTS - 4, PAGE_ROWS - 4, false);

  // 标题
  canvas_text(s_page, 8, 8,  "BLUETOOTH THERMAL PRINTER");
  canvas_text(s_page, 8, 28, "S07  TEST PAGE   384 DOTS");

  // 分隔线
  canvas_hline(s_page, 8, 48, ROW_DOTS - 16);

  // 四档灰阶：用棋盘格模拟 25% / 50% / 75% / 100%
  canvas_text(s_page, 8, 54, "GREY 25 50 75 100");
  for (int k = 0; k < 4; k++) {
    int x = 8 + k * 92;
    canvas_dither(s_page, x, 74, 84, 40, (uint8_t)(25 * (k + 1)));
  }

  // 细线组：检验 1 点宽的线能不能连续印出来
  canvas_text(s_page, 8, 122, "1-DOT LINES");
  for (int k = 0; k < 8; k++) canvas_hline(s_page, 8 + k * 47, 142, 44);
  for (int k = 0; k < 8; k++) canvas_vline(s_page, 12 + k * 47, 150, 28);

  // 棋盘：检验相邻点会不会"糊成一片"
  canvas_text(s_page, 8, 186, "CHECKER 1PX");
  for (int j = 0; j < 24; j++)
    for (int i = 0; i < 96; i++)
      if ((i + j) & 1) canvas_set(s_page, 8 + i, 206 + j);

  // 渐变条：同一图案、不同加热时间，是调 blackness 的标尺
  canvas_text(s_page, 8, 240, "HEAT RAMP 200-1200us");
  for (int k = 0; k < 8; k++) canvas_rect(s_page, 8 + k * 47, 260, 44, 24, true);

  // 页脚
  canvas_text(s_page, 8, 300, "ESP32-WROOM-32E  203DPI  48MM");
  canvas_text(s_page, 8, 320, "IF YOU CAN READ THIS, IT WORKS");
  canvas_hline(s_page, 8, 344, ROW_DOTS - 16);

  return PAGE_ROWS;
}

static void cmd_test(int argc, char **argv) {
  uint16_t rows = build_test_page();
  if (!rows) return;
  Serial.printf("printing test page: %u rows (%.1fmm)\n", rows, rows * 0.125f);
  uint32_t t0 = millis();
  canvas_print(s_page, 0, rows, s_cfg);
  Serial.printf("done in %lums\n", (unsigned long)(millis() - t0));
  canvas_free(s_page);
}

static void cmd_text(int argc, char **argv) {
  char line[200];
  line[0] = 0;
  for (int i = 1; i < argc && strlen(line) < 180; i++) {
    if (i > 1) strcat(line, " ");
    strncat(line, argv[i], 180 - strlen(line));
  }
  if (!line[0]) { Serial.println("usage: text <ascii>"); return; }
  int n = strlen(line);
  uint16_t rows = 24;
  if (!canvas_alloc(s_page, rows)) return;
  canvas_clear(s_page);
  canvas_text(s_page, 0, 4, line);
  canvas_print(s_page, 0, rows, s_cfg);
  canvas_free(s_page);
  Serial.printf("printed %d chars\n", n);
}

static void cmd_heat(int argc, char **argv) {
  if (argc >= 2) printer_set_heat(atoi(argv[1]));
  Serial.printf("heat_us = %lu\n", (unsigned long)printer_get_heat());
}

static void cmd_speed(int argc, char **argv) {
  if (argc >= 2) s_cfg.step_us = (uint32_t)atoi(argv[1]);
  if (argc >= 3) s_cfg.beats = (uint16_t)atoi(argv[2]);
  Serial.printf("step_us=%lu beats=%u\n", (unsigned long)s_cfg.step_us, s_cfg.beats);
}

void setup() {
  Serial.begin(115200);
  delay(200);
  Serial.println();
  Serial.println("=== STAGE 07 · bitmap & test page ===");
  Serial.println("先跑 test；打得淡就 heat 900，糊了就 heat 600");

  printer_init();

  shell_init(Serial);
  shell_add("test",  cmd_test,  "print the full test page");
  shell_add("text",  cmd_text,  "text <ascii string>");
  shell_add("heat",  cmd_heat,  "heat [us]");
  shell_add("speed", cmd_speed, "speed [step_us] [beats]");
  Serial.print("> ");
}

void loop() {
  shell_poll();
}
