#pragma once
// =====================================================
//  config.h —— 硬件说明书（第 03 级：接入打印头）
//  与原理图一一对应，改板子只改这里
// =====================================================

// ---------- LED / 按键 ----------
#define PIN_LED 18
#define PIN_BTN 5

// ---------- 打印头 SPI ----------
#define PIN_DI   13     // 数据输入（MOSI）
#define PIN_CLK  15     // 移位时钟

// ---------- 打印头控制 ----------
#define PIN_LAT   17    // 锁存
#define PIN_VHEN  28    // 加热电源使能（高 = 开）

// STB1..STB6：每段 64 点，顺序不能错
#define PIN_STB1  14
#define PIN_STB2  27
#define PIN_STB3  26
#define PIN_STB4  25
#define PIN_STB5  33
#define PIN_STB6  32
