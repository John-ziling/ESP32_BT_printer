// =====================================================
//  S03 · 打印头移位：48 字节怎么走出去
//  目标：把 384 点数据送进打印头并锁存（先不加热！）
//  验证：逻辑分析仪/示波器看 CLK 48 个脉冲、DI 数据、LAT 脉冲
//        没有仪器也能验收：本程序会自己做时序自检并报数
// =====================================================
#include <Arduino.h>
#include "config.h"
#include "shell.h"
#include "printhead.h"

static uint8_t s_row[HEAD_BYTES];
static uint32_t s_last_send_us = 0;

// ---------------- 图案 ----------------
static void pattern_fill(uint8_t v) { memset(s_row, v, sizeof(s_row)); }

static void pattern_checker() {          // 黑白相间：最容易看出错位
  for (int i = 0; i < HEAD_BYTES; i++) s_row[i] = (i & 1) ? 0x55 : 0xAA;
}

static void pattern_one_dot(int dot) {   // 单个点，用来数位置
  pattern_fill(0x00);
  if (dot < 0 || dot >= HEAD_DOTS) return;
  s_row[dot >> 3] = 0x80 >> (dot & 7);
}

// ---------------- 命令 ----------------
static void cmd_pat(int argc, char **argv) {
  if (argc < 2) { Serial.println("usage: pat fill <hex> | pat checker | pat dot <0-383>"); return; }
  if (strcmp(argv[1], "fill") == 0) {
    uint8_t v = (argc >= 3) ? (uint8_t)strtoul(argv[2], nullptr, 16) : 0xFF;
    pattern_fill(v);
    Serial.printf("pattern = fill 0x%02X\r\n", v);
  } else if (strcmp(argv[1], "checker") == 0) {
    pattern_checker();
    Serial.println("pattern = checker");
  } else if (strcmp(argv[1], "dot") == 0) {
    int d = (argc >= 3) ? atoi(argv[2]) : 0;
    pattern_one_dot(d);
    Serial.printf("pattern = single dot %d -> byte[%d] = 0x%02X\r\n",
                  d, d >> 3, s_row[d >> 3]);
  }
}

static void cmd_send(int argc, char **argv) {
  int n = (argc >= 2) ? atoi(argv[1]) : 1;
  if (n <= 0) n = 1;
  uint32_t t0 = micros();
  for (int i = 0; i < n; i++) printhead_send(s_row);
  uint32_t dt = micros() - t0;
  s_last_send_us = dt;
  Serial.printf("send x%d : total %luus, %.1fus/row (%.0f kbit/s)\r\n",
                n, (unsigned long)dt, (double)dt / n,
                (double)HEAD_BYTES * 8 * n / dt * 1000.0);
}

static void cmd_dump(int argc, char **argv) {
  Serial.println("row[48] =");
  for (int i = 0; i < HEAD_BYTES; i++) {
    Serial.printf("%02X%s", s_row[i], ((i & 15) == 15) ? "\r\n" : " ");
  }
}

static void cmd_lat(int argc, char **argv) {   // 只打 LAT，方便测脉宽
  int n = (argc >= 2) ? atoi(argv[1]) : 1;
  for (int i = 0; i < n; i++) {
    digitalWrite(PIN_LAT, LOW);
    delayMicroseconds(1);
    digitalWrite(PIN_LAT, HIGH);
    delayMicroseconds(100);
  }
  Serial.printf("lat pulse x%d\r\n", n);
}

static void cmd_vh(int argc, char **argv) {
  if (argc < 2) { Serial.println("usage: vh on|off"); return; }
  bool on = (strcmp(argv[1], "on") == 0);
  printhead_vh(on);
  Serial.printf("VH %s (GPIO%d=%d)\r\n", on ? "ON" : "OFF", PIN_VHEN, digitalRead(PIN_VHEN));
}

static void cmd_wire(int argc, char **argv) {
  Serial.println("FPC pin     gpio   role");
  Serial.printf("DI          %-6d data in (MOSI)\r\n", PIN_DI);
  Serial.printf("CLK         %-6d shift clock\r\n", PIN_CLK);
  Serial.printf("LAT         %-6d latch\r\n", PIN_LAT);
  Serial.printf("STB1..6     %d,%d,%d,%d,%d,%d  heat strobe\r\n",
                PIN_STB1, PIN_STB2, PIN_STB3, PIN_STB4, PIN_STB5, PIN_STB6);
  Serial.printf("VH_EN       %-6d heat power enable\r\n", PIN_VHEN);
  Serial.println("NOTE: STB 必须保持低电平，本阶段不加热");
}

// ---------------- 主流程 ----------------
void setup() {
  Serial.begin(115200);
  delay(200);
  Serial.println();
  Serial.println("=== STAGE 03 · printhead shift ===");

  printhead_init();          // 里面已经把 STB / VH 拉低
  pattern_checker();

  shell_init(Serial);
  shell_add("pat",  cmd_pat,  "pat fill <hex> | pat checker | pat dot <n>");
  shell_add("send", cmd_send, "send [n] : push row n times");
  shell_add("dump", cmd_dump, "dump current row bytes");
  shell_add("lat",  cmd_lat,  "lat [n] : pulse LAT only");
  shell_add("vh",   cmd_vh,   "vh on|off");
  shell_add("wire", cmd_wire, "pin table");

  Serial.print("> ");
}

void loop() {
  shell_poll();
}
