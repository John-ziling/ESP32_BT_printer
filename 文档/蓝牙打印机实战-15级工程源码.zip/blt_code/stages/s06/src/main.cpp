// =====================================================
//  S06 · 打印第一行：热与走的配合
//  目标：连续打出 20 行，得到一条实心黑条；再打一条细线
//  验证：黑条实心、边缘齐、宽 48mm；细线约 0.1mm 高
//  调参：heat 决定黑度，speed 决定走纸速度，两者要匹配
// =====================================================
#include <Arduino.h>
#include "config.h"
#include "printer.h"
#include "printhead.h"
#include "motor.h"
#include "shell.h"

static PrintCfg s_cfg = {800, 500, 4};   // 加热 800us / 半步 500us / 每行 4 半步
static uint8_t  s_row[ROW_BYTES];

static void row_pattern(uint8_t v) { memset(s_row, v, sizeof(s_row)); }

static void row_stripes() {
  for (int i = 0; i < ROW_BYTES; i++) s_row[i] = (i & 1) ? 0xF0 : 0x0F;
}

// ---------------- 命令 ----------------
static void cmd_bar(int argc, char **argv) {        // 实心黑条
  int n = (argc >= 2) ? atoi(argv[1]) : 20;
  if (n <= 0 || n > 400) { Serial.println("usage: bar <1-400>"); return; }
  row_pattern(0xFF);
  uint32_t t0 = millis();
  for (int i = 0; i < n; i++) printer_row(s_row, s_cfg);   // 同一图案重复 n 行
  Serial.printf("bar %d rows : %lums (%.2fms/row)\n", n,
                (unsigned long)(millis() - t0), (double)(millis() - t0) / n);
}

static void cmd_line(int argc, char **argv) {       // 一条细线 + 空走
  printer_row(s_row, s_cfg);
  printer_feed_rows(8, s_cfg);
  Serial.println("line printed (8 rows blank after)");
}

static void cmd_heat(int argc, char **argv) {
  if (argc >= 2) { printer_set_heat(atoi(argv[1])); }
  Serial.printf("heat_us = %lu\n", (unsigned long)printer_get_heat());
}

static void cmd_speed(int argc, char **argv) {
  if (argc >= 2) s_cfg.step_us = (uint32_t)atoi(argv[1]);
  if (argc >= 3) s_cfg.beats = (uint16_t)atoi(argv[2]);
  Serial.printf("step_us=%lu beats=%u  row=%luus\n",
                (unsigned long)s_cfg.step_us, s_cfg.beats,
                (unsigned long)(s_cfg.heat_us + s_cfg.step_us * s_cfg.beats));
}

static void cmd_feed(int argc, char **argv) {
  float mm = (argc >= 2) ? atof(argv[1]) : 10.0f;
  printer_feed_mm(mm, s_cfg.step_us);
  Serial.printf("feed %.1fmm\n", mm);
}

static void cmd_stripe(int argc, char **argv) {     // 条纹：检查段与段之间有没有缝
  int n = (argc >= 2) ? atoi(argv[1]) : 30;
  row_stripes();
  for (int i = 0; i < n; i++) printer_row(s_row, s_cfg);
  Serial.printf("stripes %d rows\n", n);
}

static void cmd_ramp(int argc, char **argv) {       // 灰度梯度：8 档加热时间
  Serial.println("ramp: 8 blocks, heat 200..1200us");
  for (int k = 0; k < 8; k++) {
    uint32_t h = 200 + k * 140;
    PrintCfg c = s_cfg;
    c.heat_us = h;
    row_pattern(0xFF);
    for (int i = 0; i < 12; i++) printer_row(s_row, c);
    printer_feed_rows(4, c);
    Serial.printf("  block %d heat=%luus\n", k, (unsigned long)h);
  }
  s_cfg.heat_us = 800;
}

void setup() {
  Serial.begin(115200);
  delay(200);
  Serial.println();
  Serial.println("=== STAGE 06 · print the first line ===");
  Serial.println("依次试：bar 20 / line / stripe 30 / ramp");
  Serial.println("黑度不够 -> heat 调大；糊成一片 -> heat 调小或提速");

  printer_init();
  row_pattern(0xFF);

  shell_init(Serial);
  shell_add("bar",    cmd_bar,    "bar [rows] : solid black bar");
  shell_add("line",   cmd_line,   "one thin line + feed");
  shell_add("stripe", cmd_stripe, "stripe [rows]");
  shell_add("ramp",   cmd_ramp,   "grey ramp 8 blocks");
  shell_add("heat",   cmd_heat,   "heat [us]");
  shell_add("speed",  cmd_speed,  "speed [step_us] [beats]");
  shell_add("feed",   cmd_feed,   "feed <mm>");

  Serial.print("> ");
}

void loop() {
  shell_poll();
}
