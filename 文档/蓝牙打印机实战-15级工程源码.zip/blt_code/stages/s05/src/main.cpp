// =====================================================
//  S05 · 步进电机：让纸先会走
//  目标：八拍驱动，走纸 1mm / 10mm / 100mm，精度可复现
//  验证：用尺子量 100mm 指令实际走了多少（标定写回 cal）
//  安全：任何一段运动结束后都必须释放线圈
// =====================================================
#include <Arduino.h>
#include "config.h"
#include "motor.h"
#include "shell.h"
#include "printhead.h"

static uint32_t s_step_us = 500;     // 每拍 500us：1 整步 = 8 拍 = 4ms → 约 4mm/s
static float    s_steps_per_mm = STEPS_PER_MM_DEFAULT;

static void cmd_step(int argc, char **argv) {
  int n = (argc >= 2) ? atoi(argv[1]) : 8;
  uint32_t us = (argc >= 3) ? (uint32_t)atoi(argv[2]) : s_step_us;
  if (n <= 0) { Serial.println("usage: step <n> [us_per_step]"); return; }
  uint32_t t0 = millis();
  motor_move(n, us, true);
  Serial.printf("forward %d steps @%luus : %lums\n", n, (unsigned long)us,
                (unsigned long)(millis() - t0));
}

static void cmd_back(int argc, char **argv) {
  int n = (argc >= 2) ? atoi(argv[1]) : 8;
  uint32_t us = (argc >= 3) ? (uint32_t)atoi(argv[2]) : s_step_us;
  motor_move(n, us, false);
  Serial.printf("backward %d steps\n", n);
}

static void cmd_feed(int argc, char **argv) {
  float mm = (argc >= 2) ? atof(argv[1]) : 10.0f;
  uint32_t t0 = millis();
  motor_advance_mm(mm, s_step_us);
  Serial.printf("feed %.1fmm (=%d steps) : %lums\n", mm,
                (int)(mm * motor_get_steps_per_mm() + 0.5f),
                (unsigned long)(millis() - t0));
}

static void cmd_cal(int argc, char **argv) {
  if (argc < 2) { Serial.printf("steps_per_mm = %.2f\n", motor_get_steps_per_mm()); return; }
  motor_set_steps_per_mm(atof(argv[1]));
  Serial.printf("steps_per_mm -> %.2f\n", motor_get_steps_per_mm());
}

static void cmd_speed(int argc, char **argv) {
  if (argc < 2) { Serial.printf("step_us = %lu\n", (unsigned long)s_step_us); return; }
  s_step_us = (uint32_t)atoi(argv[1]);
  Serial.printf("step_us -> %lu (1 整步 = 8 拍 = %luus)\n",
                (unsigned long)s_step_us, (unsigned long)s_step_us * 8);
}

static void cmd_rel(int argc, char **argv) {
  motor_release();
  Serial.println("coils released");
}

void setup() {
  Serial.begin(115200);
  delay(200);
  Serial.println();
  Serial.println("=== STAGE 05 · stepper motor ===");
  Serial.println("先 step 8 看电机动不动；不动就换线序或加大 us");

  printhead_init();     // 打印头引脚也初始化成"安全态"
  motor_init();

  shell_init(Serial);
  shell_add("step",  cmd_step,  "step <n> [us] : forward n steps");
  shell_add("back",  cmd_back,  "back <n> [us]");
  shell_add("feed",  cmd_feed,  "feed <mm>");
  shell_add("cal",   cmd_cal,   "cal [steps_per_mm] : print/set calibration");
  shell_add("speed", cmd_speed, "speed [us] : us per step");
  shell_add("rel",   cmd_rel,   "release coils");

  Serial.print("> ");
}

void loop() {
  shell_poll();
}
