// =====================================================
//  S10 · 协议帧：把一串字节变成"一条命令"
//  目标：手机发来的原始字节流，能稳定切成一帧一帧，并校验 CRC
//  验证：inject 一帧合法数据 → 打印 type/len/crc OK；
//        inject 改一个字节 → 打印 CRC BAD 并丢弃
// =====================================================
#include <Arduino.h>
#include "config.h"
#include "bt.h"
#include "shell.h"
#include "crc32.h"
#include "frame.h"

static FrameParser s_parser;
static Frame       s_frame;
static bool        s_listen = true;
static bool        s_autoack = true;

static void report(const Frame &f) {
  Serial.printf("FRAME type=%-3u idx=%u len=%-4u crc=%08X %s\n",
                f.type, f.index, f.len, f.crc_calc,
                f.crc_ok ? "OK" : "BAD");
  if (f.len <= 32) { Serial.print("  payload: "); hexdump(f.payload, f.len); }
}

static void send_ack(uint8_t type) {
  uint8_t buf[ACK_LEN];
  uint16_t n = ack_build(type, buf);
  Serial.print("  ack -> "); hexdump(buf, n);
  bt_write(buf, n);
}

static void on_bt(uint8_t b) {
  if (!s_listen) return;
  int r = s_parser.feed(b, s_frame);
  if (r == 1) {
    report(s_frame);
    if (s_autoack) send_ack(s_frame.type);
  } else if (r == -1) {
    Serial.printf("FRAME dropped (bad), ok=%lu bad=%lu\n",
                  (unsigned long)s_parser.ok_cnt, (unsigned long)s_parser.bad_cnt);
  }
}

static int hexval(char c) {
  if (c >= '0' && c <= '9') return c - '0';
  if (c >= 'a' && c <= 'f') return c - 'a' + 10;
  if (c >= 'A' && c <= 'F') return c - 'A' + 10;
  return -1;
}

static void cmd_crc(int argc, char **argv) {
  char text[128] = {0};
  for (int i = 1; i < argc && strlen(text) < 120; i++) {
    if (i > 1) strncat(text, " ", sizeof(text) - strlen(text) - 1);
    strncat(text, argv[i], sizeof(text) - strlen(text) - 1);
  }
  uint32_t c = crc32_calc((const uint8_t *)text, strlen(text));
  Serial.printf("crc32(\"%s\") = %08X\n", text, c);
}

static void cmd_ack(int argc, char **argv) {
  uint8_t type = (argc >= 2) ? (uint8_t)strtoul(argv[1], nullptr, 0) : 4;
  send_ack(type);
}

static void cmd_inject(int argc, char **argv) {
  uint8_t buf[FRAME_MAX_PAYLOAD + 16];
  int n = 0;
  for (int i = 1; i < argc && n < (int)sizeof(buf); i++) {
    const char *s = argv[i];
    while (*s && n < (int)sizeof(buf)) {
      int hi = hexval(*s++);
      if (hi < 0) continue;
      int lo = hexval(*s++);
      if (lo < 0) { buf[n++] = (uint8_t)hi; break; }
      buf[n++] = (uint8_t)((hi << 4) | lo);
    }
  }
  if (!n) { Serial.println("usage: inject 02 04 00 00 00 00 00 00 00 03"); return; }
  Serial.printf("inject %d bytes\n", n);
  for (int i = 0; i < n; i++) {
    int r = s_parser.feed(buf[i], s_frame);
    if (r == 1) report(s_frame);
    else if (r == -1) Serial.println("  -> rejected");
  }
}

static void cmd_listen(int argc, char **argv) {
  if (argc >= 2) s_listen = atoi(argv[1]) != 0;
  else s_listen = !s_listen;
  Serial.printf("listen = %d\n", s_listen);
}

static void cmd_stats(int, char **) {
  Serial.printf("bytes=%lu ok=%lu bad=%lu autoack=%d listen=%d\n",
                (unsigned long)s_parser.byte_cnt, (unsigned long)s_parser.ok_cnt,
                (unsigned long)s_parser.bad_cnt, s_autoack, s_listen);
}

static void cmd_autoack(int argc, char **argv) {
  s_autoack = (argc >= 2) ? (atoi(argv[1]) != 0) : !s_autoack;
  Serial.printf("autoack = %d\n", s_autoack);
}

// 自检：三条已知答案，任何一条不对就说明底层实现错了
static void cmd_selftest(int, char **) {
  int pass = 0, total = 0;

  total++;
  uint32_t c = crc32_calc((const uint8_t *)"123456789", 9);
  bool ok1 = (c == 0xCBF43926);
  Serial.printf("[%s] crc32(\"123456789\") = %08X (expect CBF43926)\n",
                ok1 ? "PASS" : "FAIL", c);
  pass += ok1;

  // 一帧 GET_VERSION：02 04 00 00 00 | 00 00 00 00 | 03
  static const uint8_t req[] = {0x02, 0x04, 0x00, 0x00, 0x00,
                                0x00, 0x00, 0x00, 0x00, 0x03};
  total++;
  FrameParser p; Frame f; int got = 0;
  for (unsigned i = 0; i < sizeof(req); i++) {
    int r = p.feed(req[i], f);
    if (r == 1) { got = 1; }
  }
  bool ok2 = got && f.type == 4 && f.len == 0 && f.crc_ok;
  Serial.printf("[%s] parse GET_VERSION: type=%u len=%u crc=%s\n",
                ok2 ? "PASS" : "FAIL", f.type, f.len, f.crc_ok ? "ok" : "bad");
  pass += ok2;

  // ACK 帧的 CRC 覆盖前 6 字节：02 04 00 01 00 00 -> 5F CC 48 08
  total++;
  uint8_t ack[ACK_LEN];
  ack_build(4, ack);
  bool ok3 = ack[6] == 0x5F && ack[7] == 0xCC && ack[8] == 0x48 && ack[9] == 0x08;
  Serial.printf("[%s] ack(4) = ", ok3 ? "PASS" : "FAIL");
  hexdump(ack, ACK_LEN);
  pass += ok3;

  Serial.printf("selftest: %d/%d\n", pass, total);
}

void setup() {
  Serial.begin(115200);
  delay(200);
  Serial.println();
  Serial.println("=== STAGE 10 · frame parser + crc32 ===");
  Serial.println("先 crc 123456789 应得 CBF43926，再 inject 整帧试解析");

  s_parser.reset();
  bt_set_rx_hook(on_bt);
  bt_start();

  shell_init(Serial);
  shell_add("crc",     cmd_crc,     "crc <text>");
  shell_add("ack",     cmd_ack,     "ack <type> : build+send ACK");
  shell_add("inject",  cmd_inject,  "inject <hex...> : feed parser");
  shell_add("listen",  cmd_listen,  "listen [0|1]");
  shell_add("autoack", cmd_autoack, "autoack [0|1]");
  shell_add("stats",   cmd_stats,   "parser statistics");
  shell_add("selftest",cmd_selftest,"known-answer self test");
  Serial.print("> ");
}

void loop() {
  bt_poll();
  shell_poll();
}
