// =====================================================
//  S12 · 打印数据通路：App 发图，机器出纸
//  目标：公版 App 里点"打印"，纸真的出来
//  验证：page 命令本地打一页测试图；再从 App 打印一段文字
// =====================================================
#include <Arduino.h>
#include "config.h"
#include "bt.h"
#include "shell.h"
#include "frame.h"
#include "proto.h"
#include "printer.h"
#include "printhead.h"
#include "printpipe.h"
#include "canvas.h"
#include "sensors.h"

static FrameParser s_parser;
static Frame       s_frame;
static PrintCfg    s_cfg = {800, 500, 4};

static void on_bt(uint8_t b) {
  int r = s_parser.feed(b, s_frame);
  if (r == 1) proto_handle(s_frame);
}

// 本地生成一页测试图，直接走 pipe（不经过蓝牙）
static void cmd_page(int, char **) {
  if (!paper_present()) { Serial.println("no paper"); return; }
  const uint16_t rows = 300;
  Canvas c;
  if (!canvas_alloc(c, rows)) { Serial.println("alloc failed"); return; }
  canvas_clear(c);
  canvas_rect(c, 2, 2, 380, rows - 4, false);
  canvas_text(c, 8, 8,  "S12 PRINT DATA PATH");
  canvas_text(c, 8, 26, "384 dots / 48 bytes per row");
  canvas_hline(c, 8, 42, 368);
  canvas_text(c, 8, 52, "gray 25/50/75/100:");
  canvas_dither(c, 8, 68, 80, 24, 25);
  canvas_dither(c, 96, 68, 80, 24, 50);
  canvas_dither(c, 184, 68, 80, 24, 75);
  canvas_dither(c, 272, 68, 80, 24, 100);
  for (int i = 0; i < 8; i++) canvas_rect(c, 8 + i * 46, 100, 40, 20, true);
  canvas_text(c, 8, rows - 28, "END OF PAGE");

  pipe_init();
  printhead_vh(true);
  uint32_t t0 = millis();
  pipe_push(c.buf, rows * ROW_BYTES);
  pipe_flush();
  uint32_t ms = millis() - t0;
  Serial.printf("page: %u rows in %lu ms -> %.1f mm/s\n",
                rows, (unsigned long)ms,
                ms ? (rows * 0.125f * 1000.0f / (float)ms) : 0.0f);
  canvas_free(c);
}

static void cmd_stats(int, char **) {
  Serial.printf("pipe: %lu bytes, %u rows, busy=%d\n",
                (unsigned long)pipe_bytes(), pipe_rows(), (int)pipe_busy());
  Serial.printf("bt: %s  paper=%d\n", bt_connected() ? "UP" : "down",
                (int)paper_present());
}

static void cmd_heat(int argc, char **argv) {
  if (argc >= 2) s_cfg.heat_us = (uint32_t)constrain(atol(argv[1]), 200, 3000);
  Serial.printf("heat = %lu us\n", (unsigned long)s_cfg.heat_us);
}

void setup() {
  Serial.begin(115200);
  delay(200);
  Serial.println();
  Serial.println("=== STAGE 12 · print data path ===");
  Serial.println("先 page 看本地出纸，再用手机 App 打印文字");

  printer_init();
  sensors_init();
  pipe_init();
  proto_init();
  s_parser.reset();
  bt_set_rx_hook(on_bt);
  bt_start();

  shell_init(Serial);
  shell_add("page",  cmd_page,  "print a local test page");
  shell_add("stats", cmd_stats, "pipe + bt state");
  shell_add("heat",  cmd_heat,  "heat <us>");
  Serial.print("> ");
}

void loop() {
  bt_poll();
  shell_poll();

  // 缺纸时立即停加热，保护打印头
  static bool last_paper = true;
  bool p = paper_present();
  if (p != last_paper) {
    last_paper = p;
    if (!p) {
      printhead_vh(false);
      Serial.println("[safety] paper out -> VH off");
    }
  }
}
