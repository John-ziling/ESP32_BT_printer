#pragma once
// =====================================================
//  button.h —— 一个"不用 delay、不用中断"的按键模块
//  思路照搬 STM32 上常见的"定时扫描 + 状态机"写法，
//  只是把定时器换成了 millis()
// =====================================================
#include <Arduino.h>

enum BtnEvent : uint8_t {
  BTN_NONE = 0,
  BTN_SHORT,   // 按下不足 1s 就松开
  BTN_LONG,    // 按住满 1s（只报一次）
  BTN_HOLD     // 长按之后每 200ms 报一次（用于连续走纸）
};

void     button_init(uint8_t pin);
BtnEvent button_poll();      // 每 5~10ms 调用一次，非阻塞
bool     button_is_down();
uint32_t button_held_ms();
