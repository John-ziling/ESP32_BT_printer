// =====================================================
//  button.cpp —— 消抖 + 短按 / 长按 / 连发
// =====================================================
#include "button.h"

static uint8_t  s_pin        = 0;
static bool     s_stable     = false;   // 消抖后的稳定状态：true = 按下
static bool     s_raw_last   = false;
static uint32_t s_raw_change = 0;       // 原始电平最后一次变化的时刻
static uint32_t s_press_at   = 0;       // 稳定按下的时刻
static bool     s_long_sent  = false;
static uint32_t s_hold_at    = 0;

static const uint32_t T_DEBOUNCE = 20;    // 消抖窗口 20ms
static const uint32_t T_LONG     = 1000;  // 长按阈值 1s
static const uint32_t T_HOLD     = 200;   // 连发间隔 200ms

void button_init(uint8_t pin) {
  s_pin = pin;
  pinMode(pin, INPUT_PULLUP);   // 按下接地 → 读到 LOW
}

bool button_is_down() { return s_stable; }

uint32_t button_held_ms() {
  return s_stable ? (millis() - s_press_at) : 0;
}

BtnEvent button_poll() {
  uint32_t now = millis();
  bool raw = (digitalRead(s_pin) == LOW);   // 低电平 = 按下

  // ---- 第 1 步：消抖。电平变化后必须稳定 20ms 才承认 ----
  if (raw != s_raw_last) {
    s_raw_last = raw;
    s_raw_change = now;
  }
  if (now - s_raw_change < T_DEBOUNCE) {
    return BTN_NONE;            // 还在抖动窗口里，什么都不报
  }

  // ---- 第 2 步：稳定状态发生变化 ----
  if (raw != s_stable) {
    s_stable = raw;
    if (s_stable) {             // 刚按下
      s_press_at  = now;
      s_long_sent = false;
      s_hold_at   = now + T_LONG + T_HOLD;
    } else {                    // 刚松开
      uint32_t held = now - s_press_at;
      if (held < T_LONG) return BTN_SHORT;
    }
    return BTN_NONE;
  }

  // ---- 第 3 步：按住不放时的长按 / 连发 ----
  if (s_stable) {
    uint32_t held = now - s_press_at;
    if (!s_long_sent && held >= T_LONG) {
      s_long_sent = true;
      return BTN_LONG;
    }
    if (s_long_sent && now >= s_hold_at) {
      s_hold_at = now + T_HOLD;
      return BTN_HOLD;
    }
  }
  return BTN_NONE;
}
