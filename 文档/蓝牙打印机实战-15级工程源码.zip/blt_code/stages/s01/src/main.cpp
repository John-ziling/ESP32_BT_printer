// =====================================================
//  S01 · 按键：短按 / 长按 / 连发，一次都不许抖
//  目标：串口能分清三种事件，LED 提示当前状态
//  验证：短按打 SHORT，按住 1s 打 LONG，继续按住每 200ms 打 HOLD
// =====================================================
#include <Arduino.h>
#include "config.h"
#include "button.h"

static uint32_t t_tick   = 0;     // 调度节拍
static uint32_t t_blink  = 0;
static bool     led_on   = false;

void setup() {
  pinMode(PIN_LED, OUTPUT);
  digitalWrite(PIN_LED, HIGH);

  Serial.begin(115200);
  delay(200);
  Serial.println();
  Serial.println("=== STAGE 01 · button ===");
  Serial.println("short press -> SHORT | hold 1s -> LONG | keep holding -> HOLD");

  button_init(PIN_BTN);
}

void loop() {
  // ---------- 5ms 调度节拍 ----------
  // 所有"该定时干活"的任务都挂在这个节拍上，不用 delay
  uint32_t now = millis();
  if (now - t_tick >= 5) {
    t_tick = now;

    BtnEvent e = button_poll();
    switch (e) {
      case BTN_SHORT:
        Serial.println("SHORT");
        break;
      case BTN_LONG:
        Serial.println("LONG  (start)");
        break;
      case BTN_HOLD:
        Serial.printf("HOLD  held=%lums\n", (unsigned long)button_held_ms());
        break;
      default:
        break;
    }
  }

  // ---------- LED：按住时常亮，松开恢复心跳 ----------
  if (button_is_down()) {
    digitalWrite(PIN_LED, LOW);          // 亮
    t_blink = now;                       // 保持计时器最新，松手后不会立刻闪
  } else if (now - t_blink >= 500) {
    t_blink = now;
    led_on = !led_on;
    digitalWrite(PIN_LED, led_on ? LOW : HIGH);
  }
}
