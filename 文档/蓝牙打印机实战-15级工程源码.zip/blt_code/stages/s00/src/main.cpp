// =====================================================
//  S00 · 让板子活过来：串口说话 + LED 心跳
//  目标：串口打印芯片信息，LED 每 500ms 翻转一次
//  验证：串口看到启动横幅，LED 匀速闪
// =====================================================
#include <Arduino.h>
#include "config.h"

// millis() 是 uint32_t，约 49.7 天回绕一次，所以这里用 unsigned long
static uint32_t t_last_blink = 0;
static bool led_on = false;

void setup() {
  // 1) 先把 LED 关掉，避免上电瞬间乱闪
  pinMode(PIN_LED, OUTPUT);
  digitalWrite(PIN_LED, HIGH);          // 高电平 = 灭（低电平点亮）

  // 2) 串口：115200 是最常用的调试速率
  Serial.begin(115200);
  delay(200);                            // 等 USB-串口芯片稳定，打印首行才不丢

  // 3) 打印启动横幅
  Serial.println();
  Serial.println("========================================");
  Serial.println("  BT Thermal Printer Firmware");
  Serial.println("  STAGE 00 - hello, chip!");
  Serial.println("========================================");
  Serial.printf("chip      : %s\n", ESP.getChipModel());
  Serial.printf("revision  : %d\n", ESP.getChipRevision());
  Serial.printf("cores     : %d\n", ESP.getChipCores());
  Serial.printf("cpu freq  : %d MHz\n", ESP.getCpuFreqMHz());
  Serial.printf("flash size: %d KB\n", ESP.getFlashChipSize() / 1024);
  Serial.printf("free heap : %d bytes\n", (int)ESP.getFreeHeap());
  // MAC 不用 WiFi 库也能读：从 eFuse 里直接取，64 位
  uint64_t mac = ESP.getEfuseMac();
  Serial.printf("chip mac  : %04X%08X\n", (uint16_t)(mac >> 32), (uint32_t)mac);
  Serial.println("----------------------------------------");
  Serial.println("boot ok");
}

void loop() {
  // 非阻塞式闪烁：不要用 delay(500)，否则后面加重任何任务都会卡
  uint32_t now = millis();
  if (now - t_last_blink >= 500) {
    t_last_blink = now;
    led_on = !led_on;
    digitalWrite(PIN_LED, led_on ? LOW : HIGH);
  }
}
