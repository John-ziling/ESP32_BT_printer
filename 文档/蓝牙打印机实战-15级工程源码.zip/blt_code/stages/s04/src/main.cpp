// =====================================================
//  S04 · 第一次加热：让纸上出现你的第一道黑
//  目标：VH 打开 → 送一行数据 → 拉高 STB → 等 → 关 STB → 关 VH
//  验证：纸上出现一条 48mm 宽、约 0.1mm 高的黑线
//  安全：本程序强制"先 arm 才能加热"，单次上限 3000us
// =====================================================
#include <Arduino.h>
#include "config.h"
#include "shell.h"
#include "printhead.h"

// 加热参数：一次最多 3000us，超过就可能烧头
#define HEAT_MAX_US   3000
#define HEAT_DEFAULT  800

static bool     s_armed   = false;   // 安全锁：必须显式 arm
static uint32_t s_heat_us = HEAT_DEFAULT;
static uint32_t s_shots   = 0;       // 累计加热次数

static uint8_t s_row[HEAD_BYTES];

static void row_fill(uint8_t v) { memset(s_row, v, sizeof(s_row)); }

static void row_dot(int dot) {
  row_fill(0x00);
  if (dot >= 0 && dot < HEAD_DOTS) s_row[dot >> 3] = 0x80 >> (dot & 7);
}

// 核心动作：送数据 → 开 VH → 加热 → 关 STB → 关 VH
static void heat_once(uint32_t us) {
  if (!s_armed) { Serial.println("! locked: type 'arm' first"); return; }
  if (us > HEAT_MAX_US) {
    Serial.printf("! %luus exceeds limit %d, clamped\n", (unsigned long)us, HEAT_MAX_US);
    us = HEAT_MAX_US;
  }

  printhead_send(s_row);          // 1. 384 位进锁存器
  printhead_vh(true);             // 2. 打开 8.4V
  delayMicroseconds(50);          //    让 VH 稳住（电源有上升沿）
  printhead_stb(0x3F);            // 3. 六段同时加热
  delayMicroseconds(us);          //    这一行就是"曝光时间"
  printhead_stb(0x00);            // 4. 立刻关！顺序错了就是烧头
  printhead_vh(false);            // 5. 关 VH

  s_shots++;
  Serial.printf("heat #%lu : %luus, dots=%d\n", (unsigned long)s_shots,
                (unsigned long)us, HEAD_DOTS);
  Serial.println("   -> 现在手动把纸往下拉一点，看有没有一条黑线");
}

// ---------------- 命令 ----------------
static void cmd_arm(int argc, char **argv) {
  s_armed = true;
  Serial.println("ARMED. heat 命令现在可用（单次上限 3000us）");
}

static void cmd_disarm(int argc, char **argv) {
  s_armed = false;
  printhead_stb(0x00);
  printhead_vh(false);
  Serial.println("DISARMED, STB/VH 全部关闭");
}

static void cmd_heat(int argc, char **argv) {
  uint32_t us = (argc >= 2) ? (uint32_t)atoi(argv[1]) : s_heat_us;
  heat_once(us);
}

static void cmd_bar(int argc, char **argv) {     // 全黑一行
  row_fill(0xFF);
  heat_once((argc >= 2) ? atoi(argv[1]) : s_heat_us);
}

static void cmd_dot(int argc, char **argv) {     // 单点
  if (argc < 2) { Serial.println("usage: dot <0-383> [us]"); return; }
  int d = atoi(argv[1]);
  if (d < 0 || d >= HEAD_DOTS) { Serial.println("! dot out of range 0..383"); return; }
  row_dot(d);
  Serial.printf("dot %d -> byte[%d]=0x%02X\n", d, d >> 3, s_row[d >> 3]);
  heat_once((argc >= 3) ? atoi(argv[2]) : s_heat_us);
}

static void cmd_scan(int argc, char **argv) {    // 扫描：一行亮、下一行灭
  row_fill(0x00);
  for (int i = 0; i < HEAD_BYTES; i++) s_row[i] = (i & 1) ? 0xF0 : 0x0F;
  heat_once((argc >= 2) ? atoi(argv[1]) : s_heat_us);
}

static void cmd_vh(int argc, char **argv) {
  bool on = (argc >= 2 && strcmp(argv[1], "on") == 0);
  printhead_vh(on);
  Serial.printf("VH %s\n", on ? "ON" : "OFF");
}

static void cmd_state(int argc, char **argv) {
  Serial.printf("armed=%d heat=%luus shots=%lu\n", s_armed,
                (unsigned long)s_heat_us, (unsigned long)s_shots);
  Serial.printf("VH pin=%d  STB pins: %d %d %d %d %d %d\n",
                digitalRead(PIN_VHEN), PIN_STB1, PIN_STB2, PIN_STB3,
                PIN_STB4, PIN_STB5, PIN_STB6);
}

void setup() {
  Serial.begin(115200);
  delay(200);
  Serial.println();
  Serial.println("=== STAGE 04 · first heat ===");
  Serial.println("顺序很重要：arm -> bar -> 手动拉纸 -> 看黑线");
  Serial.println("若纸没黑但 GPIO 都对：先查 VH 是否真的升到 8.4V");

  printhead_init();
  row_fill(0xFF);

  shell_init(Serial);
  shell_add("arm",   cmd_arm,   "unlock heating");
  shell_add("disarm",cmd_disarm,"lock + all off");
  shell_add("heat",  cmd_heat,  "heat [us] with current row");
  shell_add("bar",   cmd_bar,   "bar [us] : full black line");
  shell_add("dot",   cmd_dot,   "dot <0-383> [us]");
  shell_add("scan",  cmd_scan,  "scan [us] : alternating stripes");
  shell_add("vh",    cmd_vh,    "vh on|off");
  shell_add("state", cmd_state, "safety state");

  Serial.print("> ");
}

void loop() {
  shell_poll();
}
