// =====================================================
//  S09 · 经典蓝牙 SPP：手机能"看见"并连上
//  目标：手机蓝牙列表里出现 MaoPaperang，连上后能互发文字
//  验证：手机发 "hello" → 串口监视器看到 hello；send hi → 手机收到 hi
// =====================================================
#include <Arduino.h>
#include "config.h"
#include "bt.h"
#include "shell.h"

static uint32_t s_rx_bytes = 0;

// 手机发来的每个字节都会进这里：先原样回显，确认链路通
static void on_bt_byte(uint8_t b) {
  s_rx_bytes++;
  Serial.write(b);
}

static void cmd_bt(int, char **) {
  Serial.printf("bt: %s  connected=%d  rx=%lu bytes\n",
                bt_connected() ? "UP" : "down", bt_connected(),
                (unsigned long)s_rx_bytes);
}

static void cmd_name(int argc, char **argv) {
  if (argc < 2) { Serial.printf("name = %s\n", BT_DEFAULT_NAME); return; }
  bt_start(argv[1]);
}

static void cmd_send(int argc, char **argv) {
  char line[160] = {0};
  for (int i = 1; i < argc && strlen(line) < 150; i++) {
    if (i > 1) strncat(line, " ", sizeof(line) - strlen(line) - 1);
    strncat(line, argv[i], sizeof(line) - strlen(line) - 1);
  }
  size_t n = bt_write((const uint8_t *)line, strlen(line));
  Serial.printf("sent %u/%u bytes\n", (unsigned)n, (unsigned)strlen(line));
}

void setup() {
  Serial.begin(115200);
  delay(200);
  Serial.println();
  Serial.println("=== STAGE 09 · classic bluetooth SPP ===");
  Serial.println("手机搜 MaoPaperang 配对；没有就用名字命令改一个");

  bt_set_rx_hook(on_bt_byte);
  bt_start();

  shell_init(Serial);
  shell_add("bt",   cmd_bt,   "bluetooth status + rx counter");
  shell_add("name", cmd_name, "name <new name> : restart with new name");
  shell_add("send", cmd_send, "send <text> : write to phone");
  Serial.print("> ");
}

void loop() {
  bt_poll();      // 把手机发来的字节取出来（不阻塞）
  shell_poll();
}
