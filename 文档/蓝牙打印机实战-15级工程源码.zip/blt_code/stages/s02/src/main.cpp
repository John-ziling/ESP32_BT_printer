// =====================================================
//  S02 · 串口命令行：让板子能"回答问题"
//  目标：输入 help / ver / pins / led on 都有回应
//  验证：敲 help 列出命令；led on 点亮；pins 打印引脚表
// =====================================================
#include <Arduino.h>
#include "config.h"
#include "shell.h"

// ---------------- 命令实现 ----------------
static void cmd_help(int argc, char **argv) { shell_print_help(); }

static void cmd_ver(int argc, char **argv) {
  Serial.printf("stage   : 02\r\n");
  Serial.printf("build   : %s %s\r\n", __DATE__, __TIME__);
  Serial.printf("chip    : %s rev%d\r\n", ESP.getChipModel(), ESP.getChipRevision());
  Serial.printf("arduino : %d.%d.%d (idf %s)\r\n",
                ESP_ARDUINO_VERSION_MAJOR, ESP_ARDUINO_VERSION_MINOR,
                ESP_ARDUINO_VERSION_PATCH, ESP.getSdkVersion());
  Serial.printf("cpu     : %d MHz  cores=%d\r\n", ESP.getCpuFreqMHz(), ESP.getChipCores());
}

static void cmd_pins(int argc, char **argv) {
  Serial.println("pin        gpio   mode      note");
  Serial.printf("LED        %-6d OUTPUT    低电平点亮\r\n", PIN_LED);
  Serial.printf("BTN        %-6d INPUT_PU  按下为低\r\n", PIN_BTN);
}

static void cmd_led(int argc, char **argv) {
  if (argc < 2) { Serial.println("usage: led on|off"); return; }
  if (strcmp(argv[1], "on") == 0)       { digitalWrite(PIN_LED, LOW);  Serial.println("led on");  }
  else if (strcmp(argv[1], "off") == 0) { digitalWrite(PIN_LED, HIGH); Serial.println("led off"); }
  else                                   Serial.println("usage: led on|off");
}

static void cmd_echo(int argc, char **argv) {
  Serial.print("echo:");
  for (int i = 1; i < argc; i++) Serial.printf(" [%s]", argv[i]);
  Serial.println();
}

static void cmd_free(int argc, char **argv) {
  Serial.printf("heap free=%d  min=%d  largest=%d\r\n",
                (int)ESP.getFreeHeap(), (int)ESP.getMinFreeHeap(),
                (int)ESP.getMaxAllocHeap());
}

static void cmd_reboot(int argc, char **argv) {
  Serial.println("rebooting...");
  Serial.flush();
  delay(50);
  ESP.restart();
}

// ---------------- 主流程 ----------------
void setup() {
  pinMode(PIN_LED, OUTPUT);
  digitalWrite(PIN_LED, HIGH);

  Serial.begin(115200);
  delay(200);
  Serial.println();
  Serial.println("=== STAGE 02 · shell ===");
  Serial.println("type 'help' for commands");

  shell_init(Serial);
  shell_add("help",  cmd_help,  "list commands");
  shell_add("ver",   cmd_ver,   "firmware / chip version");
  shell_add("pins",  cmd_pins,  "pin table");
  shell_add("led",   cmd_led,   "led on|off");
  shell_add("echo",  cmd_echo,  "echo args back");
  shell_add("free",  cmd_free,  "heap usage");
  shell_add("reboot",cmd_reboot,"restart chip");

  Serial.print("> ");
}

void loop() {
  shell_poll();      // 唯一的输入入口，后面所有功能都从这里加命令
}
