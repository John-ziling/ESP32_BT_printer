import io, os, re, glob

BASE = r"C:\Users\31796\Desktop\blt_code"
MD = os.path.join(BASE, "md")
OUT = os.path.join(BASE, "build", "蓝牙打印机实战-手把手敲代码.md")

inc_re = re.compile(r"^<<<(.+?)>>>\s*$")

parts = []
for f in sorted(glob.glob(os.path.join(MD, "p*.md")), key=lambda x: int(re.search(r"p(\d+)\.md$", x).group(1))):
    lines = io.open(f, encoding="utf-8").read().split("\n")
    buf = []
    for ln in lines:
        m = inc_re.match(ln.strip())
        if m:
            rel = m.group(1).strip()
            path = os.path.join(BASE, rel)
            if os.path.exists(path):
                ext = os.path.splitext(path)[1].lstrip(".") or "c"
                buf.append("```" + ext)
                buf.append(io.open(path, encoding="utf-8").read().rstrip())
                buf.append("```")
            else:
                buf.append("```")
                buf.append("[缺文件: " + rel + "]")
                buf.append("```")
            continue
        buf.append(ln)
    text = "\n".join(buf).replace("[[PB]]", "\n---\n")
    parts.append(text)

out = "\n\n".join(parts)
io.open(OUT, "w", encoding="utf-8").write(out)
print("chars", len(out), "->", OUT)
