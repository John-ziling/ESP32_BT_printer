# -*- coding: utf-8 -*-
"""为 blt_code/stages/s00..s14 生成统一的 platformio.ini"""
import os

BASE = r"C:\Users\31796\Desktop\blt_code\stages"
TITLES = {
    "s00": "点灯与串口：确认工具链活着",
    "s01": "按键：消抖、短按、长按",
    "s02": "自建命令行：给板子一张嘴",
    "s03": "打印头移位：48 字节走出去",
    "s04": "第一次加热：纸上出现第一道黑",
    "s05": "步进电机：八拍走起来",
    "s06": "打印第一行：热与走的配合",
    "s07": "位图与测试页：把点变成画",
    "s08": "传感器：缺纸、电池、温度",
    "s09": "蓝牙 SPP：手机能连上并回显",
    "s10": "协议帧：解析、CRC、ACK",
    "s11": "握手：让 App 认为你是喵喵机",
    "s12": "打印数据通路：把图打出来",
    "s13": "可靠性与省电：看门狗、自动关机",
    "s14": "整机自检与性能调优",
}

TPL = """; =====================================================
;  手把手教你写蓝牙热敏打印机固件 · 第 {num} 级
;  {title}
;  平台：ESP32 Dev Module（ESP32-WROOM-32E，4MB Flash）
; =====================================================
[env:esp32dev]
platform = espressif32@8.0.0      ; Arduino-ESP32 3.3.12，已含 BluetoothSerial
board = esp32dev
framework = arduino

monitor_speed = 115200
upload_speed = 460800
board_build.flash_mode = dio
board_build.partitions = huge_app.csv   ; 3MB 应用区，蓝牙+打印余量充足
build_flags = -DCORE_DEBUG_LEVEL=0
"""

for i in range(15):
    key = "s%02d" % i
    d = os.path.join(BASE, key)
    os.makedirs(os.path.join(d, "src"), exist_ok=True)
    os.makedirs(os.path.join(d, "include"), exist_ok=True)
    with open(os.path.join(d, "platformio.ini"), "w", encoding="utf-8", newline="\r\n") as f:
        f.write(TPL.format(num="%02d" % i, title=TITLES[key]))
    print("ok", key, TITLES[key])
