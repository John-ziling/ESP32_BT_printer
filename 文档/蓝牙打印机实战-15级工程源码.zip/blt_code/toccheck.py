import glob, os, io
import pymupdf

d = r"C:\Users\31796\Desktop\blt_code\build"
pdf = glob.glob(os.path.join(d, "*.pdf"))[0]
doc = pymupdf.open(pdf)

# find TOC entries text and actual heading pages (skip TOC pages 2..4)
toc_txt = "\n".join(doc[i].get_text() for i in range(1, 4))
targets = ["前 言", "第 1 章", "第 5 章", "第 9 章", "第 13 章", "第 14 章", "第 17 章", "第 18 章", "附录 A", "附录 D"]
lines = []
for t in targets:
    # find actual page after TOC
    real = -1
    for i in range(4, doc.page_count):
        txt = doc[i].get_text()
        if t in txt:
            real = i + 1
            break
    # find TOC line
    toc_no = "?"
    for ln in toc_txt.splitlines():
        if t.replace(" ", "") and t in ln and "." in ln:
            parts = ln.rsplit(".", 1)
            tail = parts[-1].strip()
            if tail.isdigit():
                toc_no = tail
            break
    lines.append(f"{t:8s} toc={toc_no:>4s}  pdf_page={real:>3d}  footer={(real-1) if real>0 else -1}")

io.open(os.path.join(d, "toccheck.txt"), "w", encoding="utf-8").write("\n".join(lines))
print("\n".join(x.encode("ascii", "replace").decode() for x in lines))
