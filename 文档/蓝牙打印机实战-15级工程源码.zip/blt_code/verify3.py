import glob, os, io
import pymupdf

d = r"C:\Users\31796\Desktop\blt_code\build"
pdf = glob.glob(os.path.join(d, "*.pdf"))[0]
doc = pymupdf.open(pdf)
out = []
out.append(f"PAGES {doc.page_count}")

imgs = sum(len(p.get_images(full=True)) for p in doc)
out.append(f"IMAGES {imgs}")
empty = [i + 1 for i, p in enumerate(doc) if len(p.get_text().strip()) < 12]
out.append(f"NEAR-EMPTY {empty}")

def first_page(needle, start=0):
    for i in range(start, doc.page_count):
        if needle in doc[i].get_text():
            return i + 1
    return -1

for s in ["前言", "第 1 章", "第 5 章", "第 13 章", "第 18 章", "附录 A", "附录 D"]:
    out.append(f"first-page[{s}] = {first_page(s, 4)}")

toc = doc[1].get_text() + doc[2].get_text() + doc[3].get_text()
out.append("---- TOC TEXT ----")
out.append(toc)
out.append("---- LAST PAGE ----")
out.append(doc[-1].get_text()[:600])

io.open(os.path.join(d, "verify.txt"), "w", encoding="utf-8").write("\n".join(out))
print("ok")
