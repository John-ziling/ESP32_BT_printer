import glob, os, io
import pymupdf

d = r"C:\Users\31796\Desktop\blt_code\build"
pdf = glob.glob(os.path.join(d, "*.pdf"))[0]
doc = pymupdf.open(pdf)
out = []
for i in (0, 64, 65):
    out.append(f"===== pdf page {i+1} =====")
    out.append(doc[i].get_text()[:700])
io.open(os.path.join(d, "peek2.txt"), "w", encoding="utf-8").write("\n".join(out))
print("ok")
