# -*- coding: utf-8 -*-
"""挑一个能在 8x16 格子里画满的字体"""
import os
from PIL import Image, ImageDraw, ImageFont

CANDS = [
    (r"C:\Windows\Fonts\simsun.ttc", 16, 0),
    (r"C:\Windows\Fonts\simsun.ttc", 12, 0),
    (r"C:\Windows\Fonts\msyh.ttc", 14, 1),
    (r"C:\Windows\Fonts\consola.ttf", 17, 0),
    (r"C:\Windows\Fonts\cour.ttf", 17, 0),
    (r"C:\Windows\Fonts\lucon.ttf", 16, 0),
]

def probe(path, size, idx):
    if not os.path.exists(path):
        print("missing", path); return
    try:
        font = ImageFont.truetype(path, size, index=idx)
    except Exception as e:
        print("fail", path, e); return
    try:
        asc, desc = font.getmetrics()
    except Exception:
        asc, desc = size, 4
    print("==", os.path.basename(path), size, "ascent", asc, "descent", desc,
          "len", font.getlength("A"), font.getlength("MM"))
    for ch in "Ag0W":
        img = Image.new("L", (8, 16), 0)
        ImageDraw.Draw(img).text((0, 13 - asc), ch, font=font, fill=255)
        px = img.load()
        print("   ", ch)
        for y in range(16):
            print("    |" + "".join("#" if px[x, y] > 90 else "." for x in range(8)) + "|")

for p, s, i in CANDS:
    probe(p, s, i)
