#pragma once
// =====================================================
//  printhead.h —— 打印头底层：移位、锁存、加热、电源
//  384 点 = 48 字节，6 段（每段 64 点 = 8 字节）
// =====================================================
#include <Arduino.h>

#define HEAD_BYTES   48      // 一行 384 点 / 8
#define HEAD_DOTS    384
#define HEAD_STB_NUM 6

void printhead_init();                       // 配置引脚 + SPI，STB 全部拉低
void printhead_vh(bool on);                  // 打印头加热电源（8.4V）开关
void printhead_send(const uint8_t row[HEAD_BYTES]);   // 48 字节 + LAT 锁存
void printhead_stb(uint8_t mask);            // bit0..bit5 = STB1..STB6
void printhead_heat_all(uint32_t us);        // 6 段同时加热 us 微秒
void printhead_heat_mask(uint8_t mask, uint32_t us);
void printhead_clear();                      // 清空锁存的数据（全 0）
