#pragma once
// =====================================================
//  canvas.h —— 一整页的位图画布
//  384 点宽 = 48 字节/行；高由你定（一页 40mm ≈ 320 行）
//  画完交给 canvas_print() 逐行打出去
// =====================================================
#include <Arduino.h>
#include "printer.h"

struct Canvas {
  uint16_t rows;     // 行数
  uint8_t *buf;      // rows * ROW_BYTES，1 = 黑点
};

bool canvas_alloc(Canvas &c, uint16_t rows);
void canvas_free(Canvas &c);
void canvas_clear(Canvas &c);

void canvas_set(Canvas &c, int x, int y);                 // 置黑
void canvas_clr(Canvas &c, int x, int y);                 // 擦白
void canvas_hline(Canvas &c, int x, int y, int w);
void canvas_vline(Canvas &c, int x, int y, int h);
void canvas_rect(Canvas &c, int x, int y, int w, int h, bool fill);
void canvas_char(Canvas &c, int x, int y, char ch);       // x 需 8 对齐
void canvas_text(Canvas &c, int x, int y, const char *s);
void canvas_dither(Canvas &c, int x, int y, int w, int h, uint8_t level);  // 0~100% 黑

void canvas_print(const Canvas &c, int y0, int n, const PrintCfg &cfg);
