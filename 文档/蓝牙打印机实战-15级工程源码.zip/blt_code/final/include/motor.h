#pragma once
// =====================================================
//  motor.h —— 两相四线步进电机：八拍
//  线圈 A+/A-/B+/B- 由 TC1508S 的 INA..IND 驱动
// =====================================================
#include <Arduino.h>

#define STEPS_PER_MM_DEFAULT 32.0f   // 半步/mm：整步 0.0625mm，半步 0.03125mm，须实测标定

void motor_init();
void motor_release();                                   // 四相全关（防发热）
void motor_one_step(bool forward, uint32_t us);         // 走一拍
void motor_move(int32_t steps, uint32_t us, bool forward);
void motor_advance_mm(float mm, uint32_t us);           // 走纸 mm
void  motor_set_steps_per_mm(float v);                  // 标定
float motor_get_steps_per_mm();
