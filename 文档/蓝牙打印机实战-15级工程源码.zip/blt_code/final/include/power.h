#pragma once
// =====================================================
//  power.h —— 可靠性四件事：看门狗、自动关机、低压保护、过热降速
//  板子装电池才有意义，插 USB 调试时建议关掉自动关机
// =====================================================
#include <Arduino.h>

#define POWER_LOW_MV      3400      // 低于此电压禁止打印
#define HEAD_HOT_C       60         // 打印头超过此温度降速
#define WDT_TIMEOUT_S     8         // 任务看门狗超时

void     power_init(uint32_t idle_timeout_s);
void     power_touch();             // 每次收发数据/按键调用
void     power_tick();             // loop 里周期性调用
void     power_set_timeout(uint32_t s);
uint32_t power_idle_s();
bool     power_low_batt();
void     power_sleep();             // 进入 deep sleep（EN 键唤醒）
void     wdt_begin();
void     wdt_feed();
