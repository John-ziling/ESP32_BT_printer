#pragma once
// =====================================================
//  bt.h —— 经典蓝牙 SPP（串口透传）
//  ESP32 的 BluetoothSerial 就是"无线串口"：读写方式和 Serial 一样
//  注意：一个 ESP32 同时只能有一种蓝牙角色，别和 BLE 混用
// =====================================================
#include <Arduino.h>
#include <BluetoothSerial.h>

#define BT_DEFAULT_NAME "MaoPaperang"

extern BluetoothSerial SerialBT;

bool   bt_start(const char *name = BT_DEFAULT_NAME);
void   bt_stop();
bool   bt_connected();
void   bt_poll();                        // 收字节 → 转给 USB 串口（调试用）
size_t bt_write(const uint8_t *d, size_t n);
void   bt_set_rx_hook(void (*hook)(uint8_t));   // 协议层接管收字节
