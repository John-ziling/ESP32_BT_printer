#pragma once
// =====================================================
//  frame.h —— 打印协议的一帧
//
//   0      1      2       3     4      5..        n-4..n-1   n
//  +------+------+------+------+------+-----------+---------+------+
//  | 0x02 | type | idx  | lenL | lenH |  payload  |  CRC32  | 0x03 |
//  +------+------+------+------+------+-----------+---------+------+
//   CRC32 小端存放，覆盖范围：普通帧只算 payload，ACK 帧算前 6 字节
// =====================================================
#include <stdint.h>
#include <stddef.h>

#define FRAME_START   0x02
#define FRAME_END     0x03
#define FRAME_HDR_LEN 5          // 02 + type + idx + lenL + lenH
#define FRAME_TAIL    5          // 4 字节 CRC + 03
#define FRAME_MAX_PAYLOAD 1024   // 单帧载荷上限（协议规定 ≤1920，这里先用 1KB）
#define ACK_LEN       11

struct Frame {
  uint8_t  type;
  uint8_t  index;
  uint16_t len;
  uint8_t  payload[FRAME_MAX_PAYLOAD];
  uint32_t crc_recv;
  uint32_t crc_calc;
  bool     crc_ok;
};

class FrameParser {
 public:
  void reset();
  // 喂一个字节：返回 1 = 完整帧，0 = 继续等，-1 = 出错（已自动复位）
  int feed(uint8_t b, Frame &out);

  uint32_t ok_cnt = 0, bad_cnt = 0, byte_cnt = 0;

 private:
  enum St : uint8_t { S_START, S_TYPE, S_INDEX, S_LENL, S_LENH, S_DATA, S_CRC, S_END };
  St       st = S_START;
  uint8_t  type = 0, index = 0;
  uint16_t len = 0, pos = 0;
  uint32_t crc = 0;
  uint8_t  crc_pos = 0;
};

// 组一帧（返回整帧字节数；cap 不够返回 0）
uint16_t frame_build(uint8_t type, uint8_t index, const uint8_t *payload,
                     uint16_t len, uint8_t *out, uint16_t cap);
// 组一个 ACK（11 字节，固定格式）
uint16_t ack_build(uint8_t type, uint8_t *out);
void     hexdump(const uint8_t *d, size_t n);
