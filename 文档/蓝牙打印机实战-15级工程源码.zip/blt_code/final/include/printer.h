#pragma once
// =====================================================
//  printer.h —— 把"加热"和"走纸"合成一次打印
//  一行 = 送 48 字节 + 加热 + 走纸 0.125mm
// =====================================================
#include <Arduino.h>

#define ROW_BYTES   48
#define ROW_DOTS    384

struct PrintCfg {
  uint32_t heat_us;     // 每行加热时间
  uint32_t step_us;     // 每个半步的保持时间
  uint16_t beats;       // 每行走几个半步（0.125mm ≈ 4 个半步）
};

void printer_init();
void printer_set_heat(uint32_t us);
uint32_t printer_get_heat();
void printer_row(const uint8_t row[ROW_BYTES], const PrintCfg &cfg);
void printer_rows(const uint8_t *rows, int n, const PrintCfg &cfg);   // rows 连续排列
void printer_feed_rows(int n, const PrintCfg &cfg);                    // 空走 n 行
void printer_feed_mm(float mm, uint32_t step_us);
