#pragma once
// =====================================================
//  crc32.h —— 标准 CRC-32（和 zlib / PNG 用的一模一样）
//  多项式 0xEDB88320（反射写法），初值 0xFFFFFFFF，末尾取反
//  喵喵机协议里那个 "crcKey 0x35769521" 是厂商密钥，不参与算法本身
// =====================================================
#include <stdint.h>
#include <stddef.h>

uint32_t crc32_update(uint32_t crc, const uint8_t *data, size_t len);
uint32_t crc32_calc(const uint8_t *data, size_t len);   // 一次算完
