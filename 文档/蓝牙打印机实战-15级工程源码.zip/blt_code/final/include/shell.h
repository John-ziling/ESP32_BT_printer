#pragma once
// =====================================================
//  shell.h —— 你自己的一条串口命令行
//  为什么值得写：后面 12 级的所有功能都要靠它来单独验证，
//  没有它，你只能靠"整机跑起来看结果"，出问题只能猜。
// =====================================================
#include <Arduino.h>

typedef void (*ShellCmdFn)(int argc, char **argv);

void shell_init(Stream &s);                       // 绑定一个流（串口或蓝牙）
void shell_add(const char *name, ShellCmdFn fn, const char *help);
void shell_poll();                                // 主循环里反复调用
void shell_exec_line(char *line);                 // 直接执行一整行（调试用）
void shell_print_help();
