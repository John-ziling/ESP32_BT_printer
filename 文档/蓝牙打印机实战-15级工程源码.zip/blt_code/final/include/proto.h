#pragma once
// =====================================================
//  proto.h —— 喵喵机协议的"业务层"
//  收到一帧 → 看 type → 回 ACK + 回数据
//  这一层不碰引脚，只调 printer_* / sensors_* / bt_*
// =====================================================
#include <stdint.h>
#include "frame.h"

// ---- 指令号（与原资料/公版 App 一致，只列本项目用到的）----
#define CMD_PRINT_DATA          0    // 打印数据（0x00）
#define CMD_GET_VERSION         4    // App 问：你的协议版本？
#define CMD_SENT_VERSION        5    // 设备答
#define CMD_GET_MODEL           6
#define CMD_SENT_MODEL          7
#define CMD_GET_SN              10
#define CMD_SENT_SN             11
#define CMD_GET_BAT_STATUS      16
#define CMD_SENT_BAT_STATUS     17
#define CMD_GET_TEMP            18
#define CMD_SENT_TEMP           19
#define CMD_SET_CRC_KEY         24
#define CMD_SET_HEAT_DENSITY    25
#define CMD_FEED_LINE           26   // 走纸（也是"开始打印"信号）
#define CMD_GET_HEAT_DENSITY    28
#define CMD_SENT_HEAT_DENSITY   29
#define CMD_SET_POWER_DOWN_TIME 30
#define CMD_GET_POWER_DOWN_TIME 31
#define CMD_SENT_POWER_DOWN_TIME 32
#define CMD_FEED_TO_HEAD_LINE   33
#define CMD_TRANSFER_FW_INFO    37   // 厂商私有（示例代码用 66/67 的同一含义）
#define CMD_TRANSFER_FW_INFO_ACK 38
#define CMD_GET_PAPER_TYPE      42
#define CMD_SENT_PAPER_TYPE     43
#define CMD_SET_PAPER_TYPE      44
#define CMD_GET_COUNTRY_NAME    45
#define CMD_SENT_COUNTRY_NAME   46
#define CMD_DISCONNECT_BT       47
#define CMD_GET_DEV_NAME        48
#define CMD_SENT_DEV_NAME       49
#define CMD_SET_DENSITY_EXT     64

void proto_init();
void proto_handle(const Frame &f);                 // 主入口
void proto_send_frame(uint8_t type, const uint8_t *payload, uint16_t len);
void proto_send_ack(uint8_t type);

// 供 shell / 其它模块读取的状态
extern uint32_t g_crc_key;      // App 下发的密钥（协议 2.0 起会发，仅存档）
extern uint8_t  g_density;      // 热密度 0~100
extern uint32_t g_powerdown_s;  // 自动关机时间（秒）
