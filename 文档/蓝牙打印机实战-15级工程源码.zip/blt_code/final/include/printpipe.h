#pragma once
// =====================================================
//  printpipe.h —— 把"网上来的一串字节"变成"一行一行打出去"
//
//  App 发来的是连续的行数据流：每 48 字节 = 一行（384 点）。
//  蓝牙分包长度和"行"没有任何关系，所以必须有缓冲区攒够 48 字节。
// =====================================================
#include <stdint.h>

void     pipe_init();
void     pipe_push(const uint8_t *data, uint16_t len);   // 任意长度，内部凑行
void     pipe_flush();                                  // 收尾：补 0、走纸、关电源
uint32_t pipe_bytes();
uint16_t pipe_rows();
bool     pipe_busy();
