#pragma once
// =====================================================
//  sensors.h —— 三个"环境感知"：缺纸、电池、打印头温度
//  · 缺纸：光电对管，有纸 = LOW，缺纸 = HIGH（板上已有上拉）
//  · 电池：1:1 分压进 ADC，满电 4.2V，3.3V 以下必须保护
//  · 温度：打印头里贴的 NTC，用来在过热时降速/停机
// =====================================================
#include <Arduino.h>

#define PIN_PHINT   35     // 缺纸检测（只输入脚）
#define PIN_BATT    34     // 电池分压（只输入脚）
#define PIN_TEMP    36     // 打印头 NTC（只输入脚，SENSOR_VP）

// 电池分压比：Vbat = Vadc × (R1+R2)/R2。板上按 1:1 设计，即 ×2
#define BATT_DIV    2.0f
// NTC 参数（不同批次不同，务必用 cal 命令现场校）
#define NTC_R25     10000.0f
#define NTC_B       3950.0f
#define NTC_R_PULL  10000.0f   // 上拉电阻
#define NTC_T0_K    298.15f

void     sensors_init();
bool     paper_present();        // true = 有纸
uint16_t batt_mv();              // 毫伏（已乘分压比）
uint8_t  batt_percent(uint16_t mv);
float    head_celsius();         // 打印头温度
int      temp_raw();

void     sensors_cal_batt(uint16_t real_mv);   // 用万用表读数校准
void     sensors_cal_ntc(float real_c);
