#pragma once
// =====================================================
//  config.h —— 硬件说明书（第 05 级：加入步进电机）
//  与原理图一一对应，改板子只改这里
// =====================================================

// ---------- LED / 按键 ----------
#define PIN_LED 18
#define PIN_BTN 5

// ---------- 打印头 SPI ----------
#define PIN_DI   13     // 数据输入（MOSI）
#define PIN_CLK  15     // 移位时钟

// ---------- 打印头控制 ----------
#define PIN_LAT   17    // 锁存
#define PIN_VHEN  28    // 加热电源使能（高 = 开）

// STB1..STB6：每段 64 点，顺序不能错
#define PIN_STB1  14
#define PIN_STB2  27
#define PIN_STB3  26
#define PIN_STB4  25
#define PIN_STB5  33
#define PIN_STB6  32

// ---------- 步进电机（TC1508S）----------
// 线圈顺序按"两相四线"：A+ A- B+ B-
#define PIN_MOTOR_AP 22     // A+
#define PIN_MOTOR_AM 23     // A-
#define PIN_MOTOR_BP 19     // B+
#define PIN_MOTOR_BM 21     // B-
