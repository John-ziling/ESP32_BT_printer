// =====================================================
//  S14 · 整机自检：出厂前打一页"体检报告"
//  目标：一页纸能看出机器是不是好的
//  验证：selftest 打出的页面包含 版本/MAC/电池/温度/走纸刻度
//        bench 给出当前机器的真实速度（ms/行、mm/s）
// =====================================================
#include <Arduino.h>
#include "config.h"
#include "bt.h"
#include "shell.h"
#include "frame.h"
#include "proto.h"
#include "printer.h"
#include "printhead.h"
#include "printpipe.h"
#include "canvas.h"
#include "sensors.h"
#include "power.h"

static FrameParser s_parser;
static Frame       s_frame;

static void on_bt(uint8_t b) {
  power_touch();
  int r = s_parser.feed(b, s_frame);
  if (r == 1) proto_handle(s_frame);
}

// 一页体检报告
static void print_report() {
  const uint16_t rows = 340;
  Canvas c;
  if (!canvas_alloc(c, rows)) { Serial.println("alloc failed"); return; }
  canvas_clear(c);
  canvas_rect(c, 2, 2, 380, rows - 4, false);

  canvas_text(c, 8, 8,  "SELF TEST");
  canvas_hline(c, 8, 24, 368);

  char line[64];
  uint64_t mac = ESP.getEfuseMac();
  snprintf(line, sizeof(line), "MAC  %04X%08X",
           (uint16_t)(mac >> 32), (uint32_t)mac);
  canvas_text(c, 8, 32, line);
  snprintf(line, sizeof(line), "FW   %d.%d.%d  SDK %s",
           ESP_ARDUINO_VERSION_MAJOR, ESP_ARDUINO_VERSION_MINOR,
           ESP_ARDUINO_VERSION_PATCH, ESP.getSdkVersion());
  canvas_text(c, 8, 48, line);
  snprintf(line, sizeof(line), "BATT %umV  %u%%",
           batt_mv(), batt_percent(batt_mv()));
  canvas_text(c, 8, 64, line);
  snprintf(line, sizeof(line), "HEAD %dC  PAPER %s",
           head_celsius(), paper_present() ? "OK" : "OUT");
  canvas_text(c, 8, 80, line);
  snprintf(line, sizeof(line), "HEAP %u",
           (unsigned)ESP.getFreeHeap());
  canvas_text(c, 8, 96, line);

  // 走纸刻度：每 10mm 一条长刻度（10mm = 80 行）
  canvas_hline(c, 8, 120, 368);
  for (int i = 0; i <= 10; i++) {
    int y = 120 + i * 10;         // 10 行 ≈ 1.25mm，这里示意
    canvas_vline(c, 8, y, (i % 4 == 0) ? 8 : 4);
  }
  // 384 点满宽黑条：检查是否有断点
  canvas_rect(c, 8, 140, 368, 8, true);
  // 单点阵：检查加热一致性
  for (int y = 0; y < 20; y++)
    for (int x = 0; x < 384; x += 8)
      canvas_set(c, x, 160 + y);
  canvas_text(c, 8, rows - 28, "IF YOU CAN READ THIS, IT WORKS");

  pipe_init();
  printhead_vh(true);
  uint32_t t0 = millis();
  pipe_push(c.buf, rows * ROW_BYTES);
  pipe_flush();
  Serial.printf("report: %u rows in %lu ms\n", rows,
                (unsigned long)(millis() - t0));
  canvas_free(c);
}

static void cmd_selftest(int, char **) {
  if (!paper_present()) { Serial.println("no paper"); return; }
  print_report();
}

static void cmd_bench(int, char **) {
  if (!paper_present()) { Serial.println("no paper"); return; }
  const int rows = 100;
  uint8_t row[ROW_BYTES] = {0};
  for (int x = 0; x < 384; x += 4) row[x >> 3] |= 0x80 >> (x & 7);

  PrintCfg cfg = {800, 500, 4};
  printhead_vh(true);
  uint32_t t0 = micros();
  for (int i = 0; i < rows; i++) printer_row(row, cfg);
  uint32_t dt = micros() - t0;
  printhead_vh(false);

  float us_row = dt / (float)rows;
  Serial.printf("bench: %ld us total, %.1f us/row, %.2f mm/s, %.1f pages/min(200mm)\n",
                (long)dt, us_row, 125000.0f / us_row,
                60000000.0f / (us_row * 1600.0f));
}

static void cmd_info(int, char **) {
  Serial.printf("chip: %s rev%d %d cores @%uMHz\n", ESP.getChipModel(),
                (int)ESP.getChipRevision(), (int)ESP.getChipCores(),
                (unsigned)ESP.getCpuFreqMHz());
  Serial.printf("flash: %u KB  heap: %u  psram: %u\n",
                (unsigned)(ESP.getFlashChipSize() / 1024),
                (unsigned)ESP.getFreeHeap(), (unsigned)ESP.getFreePsram());
  Serial.printf("paper=%d batt=%umV head=%dC bt=%s\n", (int)paper_present(),
                batt_mv(), head_celsius(), bt_connected() ? "UP" : "down");
}

static void cmd_factory(int, char **) {
  Serial.println("factory test: paper, battery, head, bluetooth, print");
  Serial.printf("  paper  : %s\n", paper_present() ? "PASS" : "FAIL");
  Serial.printf("  battery: %umV %s\n", batt_mv(),
                power_low_batt() ? "FAIL(low)" : "PASS");
  int t = head_celsius();
  Serial.printf("  head   : %dC %s\n", t, (t < 0 || t > 80) ? "CHECK" : "PASS");
  Serial.printf("  bt     : %s\n", bt_start() ? "PASS" : "FAIL");
  if (paper_present()) print_report();
}

void setup() {
  Serial.begin(115200);
  delay(200);
  Serial.println();
  Serial.println("=== STAGE 14 · whole machine selftest ===");
  Serial.printf("reset reason = %d\n", (int)esp_reset_reason());

  printer_init();
  sensors_init();
  pipe_init();
  proto_init();
  s_parser.reset();
  bt_set_rx_hook(on_bt);
  bt_start();
  wdt_begin();
  power_init(0);            // 自检时不自动关机

  shell_init(Serial);
  shell_add("selftest", cmd_selftest, "print self test page");
  shell_add("bench",    cmd_bench,    "measure real speed");
  shell_add("info",     cmd_info,     "chip / memory info");
  shell_add("factory",  cmd_factory,  "factory check sequence");
  shell_add("page",     cmd_selftest, "alias of selftest");
  Serial.print("> ");
}

void loop() {
  bt_poll();
  shell_poll();
  power_tick();
  wdt_feed();
}
