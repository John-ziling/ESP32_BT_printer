// =====================================================
//  power.cpp
//  经验：自动关机是"电池机"必备功能，但它最容易被调试打断——
//        插 USB 调试时把 timeout 设 0 关掉。
//  看门狗：loop 里卡死（比如 while(available()) 等蓝牙）8 秒后
//        会自动复位，比人拔电池靠谱。
// =====================================================
#include "power.h"
#include "sensors.h"
#include "bt.h"
#include "printhead.h"
#include <esp_task_wdt.h>

static uint32_t s_timeout_s = 3600;
static uint32_t s_last_ms = 0;
static bool     s_wdt_on = false;

void wdt_begin() {
  // Arduino-ESP32 3.x：用配置结构体初始化（旧的两参数版本已废弃）
  esp_task_wdt_config_t cfg = {};
  cfg.timeout_ms = WDT_TIMEOUT_S * 1000;
  cfg.idle_core_mask = 0;
  cfg.trigger_panic = false;
  esp_err_t err = esp_task_wdt_init(&cfg);
  if (err == ESP_ERR_INVALID_STATE) {
    esp_task_wdt_reconfigure(&cfg);      // 已经被 Arduino 初始化过
    err = ESP_OK;
  }
  if (err == ESP_OK) {
    esp_task_wdt_add(NULL);              // 监视当前任务（loop 所在任务）
    s_wdt_on = true;
    Serial.printf("[wdt] on, %d s\n", WDT_TIMEOUT_S);
  } else {
    Serial.printf("[wdt] init failed %d\n", (int)err);
  }
}

void wdt_feed() {
  if (s_wdt_on) esp_task_wdt_reset();
}

void power_init(uint32_t idle_timeout_s) {
  s_timeout_s = idle_timeout_s;
  s_last_ms = millis();
}

void power_set_timeout(uint32_t s) { s_timeout_s = s; s_last_ms = millis(); }

void power_touch() { s_last_ms = millis(); }

uint32_t power_idle_s() { return (millis() - s_last_ms) / 1000; }

bool power_low_batt() { return batt_mv() < POWER_LOW_MV; }

void power_sleep() {
  Serial.println("[power] deep sleep now (press EN to wake)");
  Serial.flush();
  printhead_vh(false);
  bt_stop();
  delay(50);
  esp_deep_sleep_start();      // 之后 setup() 会重新跑一遍
}

void power_tick() {
  // 正在连着手机就视为"在使用"，不关机
  if (bt_connected()) { power_touch(); return; }

  if (s_timeout_s && power_idle_s() >= s_timeout_s) {
    power_sleep();
  }
}
