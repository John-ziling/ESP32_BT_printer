// =====================================================
//  shell.cpp —— 极简命令行：组行、分词、查表、调用
// =====================================================
#include "shell.h"

#define SHELL_MAX_CMD   24
#define SHELL_LINE_MAX  96
#define SHELL_ARGC_MAX  8

struct ShellCmd {
  const char *name;
  ShellCmdFn  fn;
  const char *help;
};

static ShellCmd s_cmds[SHELL_MAX_CMD];
static int      s_cmd_count = 0;
static Stream  *s_io        = nullptr;

static char     s_line[SHELL_LINE_MAX];
static int      s_len = 0;
static bool     s_overflow = false;

void shell_init(Stream &s) { s_io = &s; }

void shell_add(const char *name, ShellCmdFn fn, const char *help) {
  if (s_cmd_count >= SHELL_MAX_CMD) {
    if (s_io) s_io->println("! shell table full");
    return;
  }
  s_cmds[s_cmd_count++] = {name, fn, help};
}

void shell_print_help() {
  if (!s_io) return;
  s_io->println("--- commands ---");
  for (int i = 0; i < s_cmd_count; i++) {
    char buf[64];
    snprintf(buf, sizeof(buf), "  %-10s %s", s_cmds[i].name,
             s_cmds[i].help ? s_cmds[i].help : "");
    s_io->println(buf);
  }
}

void shell_exec_line(char *line) {
  if (!s_io) return;

  // 去掉行尾的 \r 和空行
  int n = strlen(line);
  while (n > 0 && (line[n - 1] == '\r' || line[n - 1] == '\n' || line[n - 1] == ' '))
    line[--n] = 0;
  if (n == 0) return;

  // 分词：argv 直接指向 line 内部，不额外拷贝
  char *argv[SHELL_ARGC_MAX];
  int   argc = 0;
  char *p = line;
  while (*p && argc < SHELL_ARGC_MAX) {
    while (*p == ' ') p++;
    if (!*p) break;
    argv[argc++] = p;
    while (*p && *p != ' ') p++;
    if (*p) *p++ = 0;
  }
  if (argc == 0) return;

  for (int i = 0; i < s_cmd_count; i++) {
    if (strcmp(argv[0], s_cmds[i].name) == 0) {
      s_cmds[i].fn(argc, argv);
      return;
    }
  }
  s_io->printf("? unknown command: %s  (try 'help')\r\n", argv[0]);
}

void shell_poll() {
  if (!s_io) return;
  while (s_io->available()) {
    int c = s_io->read();
    if (c < 0) break;

    if (c == '\r' || c == '\n') {
      s_io->print("\r\n");
      if (s_overflow) {
        s_io->println("! line too long, discarded");
        s_overflow = false;
        s_len = 0;
        continue;
      }
      s_line[s_len] = 0;
      s_len = 0;
      shell_exec_line(s_line);
      s_io->print("> ");            // 重新提示符
    } else if (c == 8 || c == 127) {  // 退格
      if (s_len > 0) {
        s_len--;
        s_io->print("\b \b");
      }
    } else if (c >= 32) {
      if (s_len < SHELL_LINE_MAX - 1) {
        s_line[s_len++] = (char)c;
        s_io->write((uint8_t)c);      // 回显
      } else {
        s_overflow = true;
      }
    }
  }
}
