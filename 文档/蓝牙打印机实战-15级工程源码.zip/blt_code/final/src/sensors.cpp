// =====================================================
//  sensors.cpp —— 缺纸 / 电池 / NTC 温度
//  三个 ADC 脚都只能输入（34/35/36），没有内部上拉，也没有输出能力
// =====================================================
#include "sensors.h"

static float    s_batt_gain = 1.0f;     // 校准系数
static float    s_ntc_offset = 0.0f;    // 温度偏移

static uint16_t adc_avg(int pin, int n) {
  uint32_t sum = 0;
  for (int i = 0; i < n; i++) sum += analogRead(pin);
  return (uint16_t)(sum / n);
}

void sensors_init() {
  pinMode(PIN_PHINT, INPUT);            // 板上已有外部上拉
  pinMode(PIN_BATT, INPUT);
  pinMode(PIN_TEMP, INPUT);

  analogReadResolution(12);             // 0..4095
  // 3.3V 量程；电池分压后最高 2.1V，11dB 挡最合适
  analogSetPinAttenuation(PIN_BATT, ADC_11db);
  analogSetPinAttenuation(PIN_TEMP, ADC_11db);

  Serial.printf("sensors: PHINT=%d BATT=%d TEMP=%d\n",
                digitalRead(PIN_PHINT), analogRead(PIN_BATT), analogRead(PIN_TEMP));
}

bool paper_present() {
  // 光电对管被纸挡住时输出低；连续两次一致才算数，避免纸边抖动
  static int last = -1;
  int now = digitalRead(PIN_PHINT);
  if (now == last) return now == LOW;
  last = now;
  return now == LOW;
}

uint16_t batt_mv() {
  uint16_t raw = adc_avg(PIN_BATT, 16);
  // 分压 1:1 → 电池电压是 ADC 读数的 2 倍；3.3V/4095 每格 ≈ 0.806mV
  float mv = raw * (3300.0f / 4095.0f) * BATT_DIV * s_batt_gain;
  return (uint16_t)mv;
}

uint8_t batt_percent(uint16_t mv) {
  // 18650 的放电曲线不是直线：4.20 满 / 3.70 大约 20% / 3.30 空
  static const uint16_t tbl[][2] = {
    {4200, 100}, {4100, 90}, {4000, 80}, {3900, 70}, {3800, 60},
    {3700, 45},  {3650, 35}, {3600, 25}, {3500, 15}, {3400, 8}, {3300, 0},
  };
  const int N = sizeof(tbl) / sizeof(tbl[0]);
  if (mv >= tbl[0][0]) return 100;
  for (int i = 1; i < N; i++) {
    if (mv >= tbl[i][0]) {
      // 线性插值，别让电量数字一跳 10%
      uint16_t v1 = tbl[i - 1][0], v0 = tbl[i][0];
      uint8_t  p1 = tbl[i - 1][1], p0 = tbl[i][1];
      return (uint8_t)(p0 + (int32_t)(mv - v0) * (p1 - p0) / (v1 - v0));
    }
  }
  return 0;
}

int temp_raw() { return adc_avg(PIN_TEMP, 8); }

float head_celsius() {
  int raw = temp_raw();
  if (raw <= 8 || raw >= 4087) return -99.0f;      // 开路/短路
  // NTC 在下、上拉到 3V3：R_ntc = R_pull × raw / (4095 - raw)
  float r = NTC_R_PULL * (float)raw / (4095.0f - (float)raw);
  float t_k = 1.0f / (1.0f / NTC_T0_K + logf(r / NTC_R25) / NTC_B);
  return t_k - 273.15f + s_ntc_offset;
}

void sensors_cal_batt(uint16_t real_mv) {
  uint16_t now = batt_mv();
  if (now == 0) return;
  s_batt_gain *= (float)real_mv / (float)now;
  Serial.printf("batt cal: gain=%.4f -> %umV\n", s_batt_gain, batt_mv());
}

void sensors_cal_ntc(float real_c) {
  float now = head_celsius();
  if (now < -50) return;
  s_ntc_offset += real_c - now;
  Serial.printf("ntc cal: offset=%.2f -> %.1fC\n", s_ntc_offset, head_celsius());
}
