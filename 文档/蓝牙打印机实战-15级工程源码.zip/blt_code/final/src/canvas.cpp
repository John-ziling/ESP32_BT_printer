// =====================================================
//  canvas.cpp —— 位图画布的像素操作
//  坐标：x 0..383 从左到右，y 0..rows-1 从上到下
// =====================================================
#include "canvas.h"
#include "font8x16.h"

bool canvas_alloc(Canvas &c, uint16_t rows) {
  c.rows = rows;
  c.buf = (uint8_t *)malloc((size_t)rows * ROW_BYTES);
  if (!c.buf) { c.rows = 0; return false; }
  canvas_clear(c);
  return true;
}

void canvas_free(Canvas &c) {
  if (c.buf) free(c.buf);
  c.buf = nullptr;
  c.rows = 0;
}

void canvas_clear(Canvas &c) {
  if (c.buf) memset(c.buf, 0, (size_t)c.rows * ROW_BYTES);
}

// 一行 48 字节，每字节 bit7 是最左边的点
void canvas_set(Canvas &c, int x, int y) {
  if (x < 0 || x >= ROW_DOTS || y < 0 || y >= c.rows) return;
  c.buf[(size_t)y * ROW_BYTES + (x >> 3)] |= (0x80 >> (x & 7));
}

void canvas_clr(Canvas &c, int x, int y) {
  if (x < 0 || x >= ROW_DOTS || y < 0 || y >= c.rows) return;
  c.buf[(size_t)y * ROW_BYTES + (x >> 3)] &= ~(0x80 >> (x & 7));
}

void canvas_hline(Canvas &c, int x, int y, int w) {
  for (int i = 0; i < w; i++) canvas_set(c, x + i, y);
}

void canvas_vline(Canvas &c, int x, int y, int h) {
  for (int i = 0; i < h; i++) canvas_set(c, x, y + i);
}

void canvas_rect(Canvas &c, int x, int y, int w, int h, bool fill) {
  if (fill) {
    for (int j = 0; j < h; j++)
      for (int i = 0; i < w; i++) canvas_set(c, x + i, y + j);
  } else {
    canvas_hline(c, x, y, w);
    canvas_hline(c, x, y + h - 1, w);
    canvas_vline(c, x, y, h);
    canvas_vline(c, x + w - 1, y, h);
  }
}

// 贴一个 8x16 字符：每行一个字节，正好整字节对齐
void canvas_char(Canvas &c, int x, int y, char ch) {
  if (x < 0 || (x & 7) || x + 8 > ROW_DOTS) return;
  uint8_t u = (uint8_t)ch;
  if (u < FONT8X16_FIRST || u > FONT8X16_LAST) u = '?';
  const uint8_t *g = FONT8X16[u - FONT8X16_FIRST];
  int col = x >> 3;
  for (int r = 0; r < 16; r++) {
    int yy = y + r;
    if (yy < 0 || yy >= c.rows) continue;
    c.buf[(size_t)yy * ROW_BYTES + col] = g[r];   // 直接整字节覆盖
  }
}

void canvas_text(Canvas &c, int x, int y, const char *s) {
  int cx = x;
  for (const char *p = s; *p; p++) {
    canvas_char(c, cx, y, *p);
    cx += 8;
    if (cx + 8 > ROW_DOTS) break;
  }
}

// 用棋盘格做"灰度"：level 0=全白 100=全黑
void canvas_dither(Canvas &c, int x, int y, int w, int h, uint8_t level) {
  if (level > 100) level = 100;
  for (int j = 0; j < h; j++) {
    for (int i = 0; i < w; i++) {
      int t = ((i & 1) + (j & 1) * 2) * 25;      // 0/25/50/75
      bool on = (level >= 100) || (t < level);
      if (on) canvas_set(c, x + i, y + j);
    }
  }
}

void canvas_print(const Canvas &c, int y0, int n, const PrintCfg &cfg) {
  for (int i = 0; i < n; i++) {
    int y = y0 + i;
    if (y < 0 || y >= c.rows) break;
    printer_row(&c.buf[(size_t)y * ROW_BYTES], cfg);
  }
}
