// =====================================================
//  frame.cpp —— 逐字节状态机 + 组帧
//  为什么不用"等收满一包再解析"：蓝牙一次可能只来 3 个字节，
//  也可能一次来 500 个，只有状态机才对两种都稳。
// =====================================================
#include "frame.h"
#include "crc32.h"
#include <Arduino.h>

void FrameParser::reset() {
  st = S_START;
  type = index = 0;
  len = pos = 0;
  crc = 0;
  crc_pos = 0;
}

int FrameParser::feed(uint8_t b, Frame &out) {
  byte_cnt++;
  switch (st) {
    case S_START:
      if (b == FRAME_START) st = S_TYPE;      // 不是 02 就继续找，丢掉杂字节
      break;

    case S_TYPE:
      type = b;
      st = S_INDEX;
      break;

    case S_INDEX:
      index = b;
      st = S_LENL;
      break;

    case S_LENL:
      len = b;
      st = S_LENH;
      break;

    case S_LENH:
      len |= (uint16_t)b << 8;
      if (len > FRAME_MAX_PAYLOAD) {          // 长度离谱：直接丢掉这一帧
        bad_cnt++;
        reset();
        return -1;
      }
      pos = 0;
      st = (len == 0) ? S_CRC : S_DATA;
      break;

    case S_DATA:
      out.payload[pos++] = b;
      if (pos >= len) st = S_CRC;
      break;

    case S_CRC:
      crc |= (uint32_t)b << (8 * crc_pos);    // 小端
      crc_pos++;
      if (crc_pos >= 4) st = S_END;
      break;

    case S_END:
      if (b != FRAME_END) {                    // 结尾不对：整帧作废
        bad_cnt++;
        reset();
        return -1;
      }
      out.type = type;
      out.index = index;
      out.len = len;
      out.crc_recv = crc;
      out.crc_calc = crc32_calc(out.payload, len);
      out.crc_ok = (out.crc_recv == out.crc_calc);
      if (out.crc_ok) ok_cnt++; else bad_cnt++;
      reset();
      return out.crc_ok ? 1 : -1;

    default:
      reset();
      break;
  }
  return 0;
}

uint16_t frame_build(uint8_t type, uint8_t index, const uint8_t *payload,
                     uint16_t len, uint8_t *out, uint16_t cap) {
  uint16_t total = FRAME_HDR_LEN + len + FRAME_TAIL;
  if (total > cap) return 0;
  uint16_t i = 0;
  out[i++] = FRAME_START;
  out[i++] = type;
  out[i++] = index;
  out[i++] = (uint8_t)(len & 0xFF);
  out[i++] = (uint8_t)(len >> 8);
  if (len && payload) { memcpy(out + i, payload, len); i += len; }
  uint32_t c = crc32_calc(payload, len);
  out[i++] = (uint8_t)(c & 0xFF);
  out[i++] = (uint8_t)((c >> 8) & 0xFF);
  out[i++] = (uint8_t)((c >> 16) & 0xFF);
  out[i++] = (uint8_t)((c >> 24) & 0xFF);
  out[i++] = FRAME_END;
  return i;
}

// ACK 是特例：11 字节固定格式，CRC 算前 6 字节（含长度字段）
uint16_t ack_build(uint8_t type, uint8_t *out) {
  out[0] = FRAME_START;
  out[1] = type;
  out[2] = 0x00;
  out[3] = 0x01;      // len = 1
  out[4] = 0x00;
  out[5] = 0x00;      // 载荷固定 0x00
  uint32_t c = crc32_calc(out, 6);
  out[6] = (uint8_t)(c & 0xFF);
  out[7] = (uint8_t)((c >> 8) & 0xFF);
  out[8] = (uint8_t)((c >> 16) & 0xFF);
  out[9] = (uint8_t)((c >> 24) & 0xFF);
  out[10] = FRAME_END;
  return ACK_LEN;
}

void hexdump(const uint8_t *d, size_t n) {
  for (size_t i = 0; i < n; i++) {
    Serial.printf("%02X ", d[i]);
    if ((i & 15) == 15) Serial.println();
  }
  if (n & 15) Serial.println();
}
