// =====================================================
//  printer.cpp —— 一行纸是怎么被"打"出来的
//
//  时序（顺序版，最容易理解）：
//     送 48 字节 ──> LAT 锁存 ──> VH 开 ──> STB 拉高 us ──> STB 拉低
//                                   └─> 走纸 beats 个半步 ──> 下一行
//
//  注意两个顺序上的死规矩：
//   1) STB 必须在 VH 之后开、在 VH 之前关；
//   2) 换行数据前必须先把 STB 全部拉低，否则会把旧数据再烫一遍。
// =====================================================
#include <Arduino.h>
#include "config.h"
#include "printer.h"
#include "printhead.h"
#include "motor.h"

static uint32_t s_heat_us = 800;

void printer_init() {
  printhead_init();
  motor_init();
  printhead_vh(false);
  printhead_stb(0x00);
}

void printer_set_heat(uint32_t us) { if (us >= 200 && us <= 3000) s_heat_us = us; }
uint32_t printer_get_heat() { return s_heat_us; }

void printer_row(const uint8_t row[ROW_BYTES], const PrintCfg &cfg) {
  printhead_send(row);                  // 1. 384 位进移位寄存器
  printhead_vh(true);                   // 2. 开加热电源
  delayMicroseconds(50);
  printhead_stb(0x3F);                  // 3. 六段一起加热
  delayMicroseconds(cfg.heat_us);       //    热量 = 电压² × 时间
  printhead_stb(0x00);                  // 4. 立刻关断
  printhead_vh(false);                  // 5. 关电源（每行都关更安全）

  for (uint16_t i = 0; i < cfg.beats; i++)   // 6. 走纸 0.125mm
    motor_one_step(true, cfg.step_us);
  motor_release();                      // 7. 松开线圈
}

void printer_rows(const uint8_t *rows, int n, const PrintCfg &cfg) {
  for (int i = 0; i < n; i++)
    printer_row(rows + i * ROW_BYTES, cfg);
}

void printer_feed_rows(int n, const PrintCfg &cfg) {
  uint8_t blank[ROW_BYTES] = {0};
  for (int i = 0; i < n; i++) {
    // 空走：只送 0 数据、不加热，直接走纸
    printhead_send(blank);
    for (uint16_t k = 0; k < cfg.beats; k++) motor_one_step(true, cfg.step_us);
    motor_release();
  }
}

void printer_feed_mm(float mm, uint32_t step_us) {
  motor_advance_mm(mm, step_us);
}
