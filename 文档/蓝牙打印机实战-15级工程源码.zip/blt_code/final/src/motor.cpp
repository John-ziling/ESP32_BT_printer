// =====================================================
//  motor.cpp —— 八拍驱动
//  为什么不是四拍：八拍每次只动半步，力矩更均匀、噪音更小，
//  打印时的走纸精度也更稳（代价是同距离多花一倍时间）。
// =====================================================
#include <Arduino.h>
#include "config.h"
#include "motor.h"

// 线圈顺序：A+ A- B+ B-
static const uint8_t COIL_PINS[4] = {
  PIN_MOTOR_AP, PIN_MOTOR_AM, PIN_MOTOR_BP, PIN_MOTOR_BM
};

// 八拍真值表（1 = 该线圈通电）
static const uint8_t SEQ[8][4] = {
  {1, 0, 0, 0},
  {1, 0, 1, 0},
  {0, 0, 1, 0},
  {0, 1, 1, 0},
  {0, 1, 0, 0},
  {0, 1, 0, 1},
  {0, 0, 0, 1},
  {1, 0, 0, 1},
};

static uint8_t  s_phase = 0;      // 当前处在第几拍（保持相位连续性）
static float    s_steps_per_mm = STEPS_PER_MM_DEFAULT;

void motor_init() {
  for (int i = 0; i < 4; i++) {
    pinMode(COIL_PINS[i], OUTPUT);
    digitalWrite(COIL_PINS[i], LOW);
  }
  motor_release();
}

void motor_release() {
  // 停在最后一拍不动时，线圈必须断电：
  // 否则 8.4V 一直灌进线圈，几分钟就烫手，还会拖累电池
  for (int i = 0; i < 4; i++) digitalWrite(COIL_PINS[i], LOW);
}

static void apply_phase(uint8_t p) {
  for (int i = 0; i < 4; i++)
    digitalWrite(COIL_PINS[i], SEQ[p][i] ? HIGH : LOW);
}

void motor_one_step(bool forward, uint32_t us) {
  s_phase = forward ? (uint8_t)((s_phase + 1) & 7) : (uint8_t)((s_phase + 7) & 7);
  apply_phase(s_phase);
  delayMicroseconds(us);          // 这一拍保持多久 = 速度
}

void motor_move(int32_t steps, uint32_t us, bool forward) {
  if (steps <= 0) return;
  for (int32_t i = 0; i < steps; i++) motor_one_step(forward, us);
  motor_release();
}

void motor_advance_mm(float mm, uint32_t us) {
  int32_t steps = (int32_t)(mm * s_steps_per_mm + 0.5f);
  motor_move(steps, us, true);
}

void  motor_set_steps_per_mm(float v) { if (v > 1.0f && v < 200.0f) s_steps_per_mm = v; }
float motor_get_steps_per_mm()        { return s_steps_per_mm; }
