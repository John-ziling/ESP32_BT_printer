// =====================================================
//  printhead.cpp —— 打印头的三根线 + 六根选通
//  CLK/DI 走硬件 SPI，LAT 与 STB 用 GPIO
// =====================================================
#include <Arduino.h>
#include <SPI.h>
#include "config.h"
#include "printhead.h"

// STB1..6 对应 GPIO14, 27, 26, 25, 33, 32（顺序必须与 FPC 一致！）
static const uint8_t STB_PINS[HEAD_STB_NUM] = {
  PIN_STB1, PIN_STB2, PIN_STB3, PIN_STB4, PIN_STB5, PIN_STB6
};

// 1MHz：先慢速保证波形干净，稳定后再提到 4~8MHz
static SPISettings HEAD_SPI(1000000, MSBFIRST, SPI_MODE0);

void printhead_init() {
  pinMode(PIN_LAT, OUTPUT);
  digitalWrite(PIN_LAT, LOW);
  pinMode(PIN_VHEN, OUTPUT);
  digitalWrite(PIN_VHEN, LOW);          // 上电先关 VH，防止误加热

  for (int i = 0; i < HEAD_STB_NUM; i++) {
    pinMode(STB_PINS[i], OUTPUT);
    digitalWrite(STB_PINS[i], LOW);     // 关键：STB 低 = 不加热
  }

  // ESP32 的 VSPI 默认引脚：SCLK=18, MISO=19, MOSI=23, SS=5
  // 这里只用到时钟与 MOSI，所以把 MISO/SS 设成 -1 让库跳过
  SPI.begin(PIN_CLK, -1, PIN_DI, -1);
}

void printhead_vh(bool on) {
  digitalWrite(PIN_VHEN, on ? HIGH : LOW);
}

void printhead_send(const uint8_t row[HEAD_BYTES]) {
  SPI.beginTransaction(HEAD_SPI);
  for (int i = 0; i < HEAD_BYTES; i++) SPI.transfer(row[i]);
  SPI.endTransaction();

  // LAT：低 → 高，把移位寄存器里的 384 位搬到锁存器
  digitalWrite(PIN_LAT, LOW);
  delayMicroseconds(1);
  digitalWrite(PIN_LAT, HIGH);
}

void printhead_stb(uint8_t mask) {
  for (int i = 0; i < HEAD_STB_NUM; i++)
    digitalWrite(STB_PINS[i], (mask & (1 << i)) ? HIGH : LOW);
}

void printhead_heat_mask(uint8_t mask, uint32_t us) {
  printhead_stb(mask);
  delayMicroseconds(us);
  printhead_stb(0x00);                  // 无论如何都要关，这是保命动作
}

void printhead_heat_all(uint32_t us) { printhead_heat_mask(0x3F, us); }

void printhead_clear() {
  uint8_t zero[HEAD_BYTES] = {0};
  printhead_send(zero);
}
