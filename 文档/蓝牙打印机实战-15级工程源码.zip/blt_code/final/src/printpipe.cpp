// =====================================================
//  printpipe.cpp —— 行缓冲 + 边收边打
//  为什么"边收边打"：一页 45mm ≈ 360 行 ≈ 17KB，
//  全攒下来要 17KB RAM 且第一行要等 1.3s；
//  攒够一行就打，延迟只有一个字节的时间。
// =====================================================
#include "printpipe.h"
#include "printer.h"
#include "printhead.h"
#include <Arduino.h>

static uint8_t  s_row[ROW_BYTES];
static uint8_t  s_fill = 0;
static uint32_t s_bytes = 0;
static uint16_t s_rows = 0;
static uint16_t s_since_pause = 0;
static PrintCfg s_cfg = {800, 500, 4};

static void emit_row() {
  printer_row(s_row, s_cfg);
  memset(s_row, 0, ROW_BYTES);
  s_fill = 0;
  s_rows++;

  // 热保护：连续打 1 页（约 360 行）休息 20ms，避免打印头积热
  if (++s_since_pause >= 360) {
    s_since_pause = 0;
    printhead_vh(false);
    delay(20);
    printhead_vh(true);
  }
}

void pipe_init() {
  memset(s_row, 0, ROW_BYTES);
  s_fill = 0;
  s_bytes = 0;
  s_rows = 0;
  s_since_pause = 0;
}

void pipe_push(const uint8_t *data, uint16_t len) {
  s_bytes += len;
  for (uint16_t i = 0; i < len; i++) {
    s_row[s_fill++] = data[i];
    if (s_fill >= ROW_BYTES) emit_row();
  }
}

void pipe_flush() {
  if (s_fill) emit_row();          // 末尾不满一行：补 0 打出去
  printer_feed_rows(24, s_cfg);    // 吐纸 3mm，方便撕
  printhead_vh(false);
}

uint32_t pipe_bytes() { return s_bytes; }
uint16_t pipe_rows()  { return s_rows; }
bool     pipe_busy()  { return s_fill != 0; }
