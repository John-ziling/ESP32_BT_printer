// =====================================================
//  bt.cpp —— 经典蓝牙 SPP 的一层薄封装
//  事件回调运行在蓝牙栈的任务里，**绝对不能在里面做耗时操作**
// =====================================================
#include "bt.h"

BluetoothSerial SerialBT;

static bool s_started = false;
static bool s_connected = false;
static void (*s_hook)(uint8_t) = nullptr;
static char s_name[32] = BT_DEFAULT_NAME;

static void bt_event(esp_spp_cb_event_t event, esp_spp_cb_param_t *param) {
  switch (event) {
    case ESP_SPP_INIT_EVT:
      Serial.println("[bt] stack ready");
      break;
    case ESP_SPP_SRV_OPEN_EVT:
    case ESP_SPP_OPEN_EVT:
      s_connected = true;
      Serial.println("[bt] connected");
      break;
    case ESP_SPP_CLOSE_EVT:
      s_connected = false;
      Serial.println("[bt] disconnected");
      break;
    case ESP_SPP_DATA_IND_EVT:
      // 这里只打印长度，真正收数据交给 bt_poll()
      Serial.printf("[bt] rx %d bytes\n", param->data_ind.len);
      break;
    case ESP_SPP_WRITE_EVT:
      break;
    default:
      break;
  }
}

bool bt_start(const char *name) {
  if (name && *name) {
    strncpy(s_name, name, sizeof(s_name) - 1);
    s_name[sizeof(s_name) - 1] = 0;
  }
  if (s_started) bt_stop();
  SerialBT.register_callback(bt_event);
  if (!SerialBT.begin(s_name)) {         // 名字就是手机里看到的设备名
    Serial.println("[bt] begin failed");
    return false;
  }
  s_started = true;
  Serial.printf("[bt] advertising as \"%s\"\n", s_name);
  return true;
}

void bt_stop() {
  if (!s_started) return;
  SerialBT.end();
  s_started = false;
  s_connected = false;
}

bool bt_connected() { return s_connected && SerialBT.hasClient(); }

void bt_set_rx_hook(void (*hook)(uint8_t)) { s_hook = hook; }

void bt_poll() {
  while (SerialBT.available()) {
    uint8_t b = (uint8_t)SerialBT.read();
    if (s_hook) s_hook(b);
    else        Serial.write(b);          // 没挂协议层时当透传调试
  }
}

size_t bt_write(const uint8_t *d, size_t n) {
  if (!bt_connected()) return 0;
  return SerialBT.write(d, n);
}
