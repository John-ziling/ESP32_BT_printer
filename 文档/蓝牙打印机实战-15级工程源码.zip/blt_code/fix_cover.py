import io, re

p = r"C:\Users\31796\Desktop\blt_code\build2.py"
s = io.open(p, encoding="utf-8").read()
lines = s.split("\n")
for i, ln in enumerate(lines):
    if "本教程基于项目资料中的示例代码" in ln:
        lines[i] = ('    r = p.add_run("15 个分级工程均在本机实测编译通过，\\n'
                    '书中的 RAM / Flash 占用与耗时都是真实构建结果，可直接对照。")')
        print("patched line", i + 1)
io.open(p, "w", encoding="utf-8").write("\n".join(lines))
