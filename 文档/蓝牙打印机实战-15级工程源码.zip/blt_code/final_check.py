import glob, os, io
import pymupdf

d = r"C:\Users\31796\Desktop\blt_code\build"
pdf = glob.glob(os.path.join(d, "*.pdf"))[0]
md = glob.glob(os.path.join(d, "*.md"))[0]
doc = pymupdf.open(pdf)
txt = "".join(p.get_text() for p in doc)
mdt = io.open(md, encoding="utf-8").read()

lines = [
    f"PDF pages      : {doc.page_count}",
    f"PDF images     : {sum(len(p.get_images(full=True)) for p in doc)}",
    f"near-empty     : {[i+1 for i,p in enumerate(doc) if len(p.get_text().strip())<12]}",
    f"md chars       : {len(mdt)}",
    f"缺文件 marker  : {mdt.count('[缺文件')}",
    f"PDF 缺文件     : {txt.count('缺文件')}",
    f"pdf 图 13-1    : {'图 13-1' in txt}",
    f"pdf 图 0-1     : {'图 0-1' in txt}",
    f"pdf 附录 D     : {'附录 D' in txt}",
]
for key in ["FrameParser", "crc32_calc", "pipe_push", "esp_task_wdt_init", "MaoPaperang", "print_report", "heat_mask"]:
    lines.append(f"count {key:18s}: pdf={txt.count(key):3d} md={mdt.count(key):3d}")
io.open(os.path.join(d, "final_check.txt"), "w", encoding="utf-8").write("\n".join(lines))
print("\n".join(x.encode("ascii", "replace").decode() for x in lines))
