import os, zipfile

BASE = r"C:\Users\31796\Desktop\blt_code"
OUT = r"C:\Users\31796\Desktop\蓝牙打印机实战-15级工程源码.zip"

SKIP_DIRS = {".pio", ".vscode", "__pycache__"}
count = 0
with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED) as z:
    for root, dirs, files in os.walk(BASE):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        rel = os.path.relpath(root, BASE)
        if rel.startswith("build") or rel.startswith("md") or rel.startswith("figs"):
            continue
        for f in files:
            if f.endswith((".pyc", ".zip")):
                continue
            full = os.path.join(root, f)
            arc = os.path.join("blt_code", os.path.relpath(full, BASE))
            z.write(full, arc)
            count += 1
print("files", count, "size", os.path.getsize(OUT))
